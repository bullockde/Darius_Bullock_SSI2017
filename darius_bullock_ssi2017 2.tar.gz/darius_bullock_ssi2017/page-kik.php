<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
get_header('kik'); 

?>



		<?php 
			
			$events = get_posts(array(  'post_type' => 'ssi_events' , 'posts_per_page' => -1 )); 
			$models = get_posts(array(  'post_type' => 'ssi_models' , 'posts_per_page' => -1 , 'orderby' => 'modified', 'order' => 'asc' , 'post_status' => 'publish' , 'category_name' => 'top-thot' ));
			$projects = get_posts(array(  'post_type' => 'ssi_projects' , 'posts_per_page' => -1 ));
			$photos = get_posts(array(  'post_type' => 'ssi_photos' , 'posts_per_page' => -1 ));
			$videos = get_posts(array( 'post_type' => 'ssi_videos' , 'posts_per_page' => -1 ));
			$thots = get_posts(array(  'post_type' => array('ssi_models', 'ssi_requests') , 'posts_per_page' => -1 , 'orderby' => 'modified', 'order' => 'asc' , 'post_status' => array('publish', 'pending') , 'category_name' => 'thots' ));
			
		?>
<style>
	.site-header {
		display: none;
	}
	legend {
		display: none;
	}
	input.buttons {
		margin: 1em;
	}
</style>
		
<div id="" class="">


					
    <div class='clearfix'></div>
					<?php	echo get_template_part( "content", "welcome-profile" ); ?>

	<div class='well col-sm-6 text-center col-sm-offset-3'>
		
		
		
	
	<div class='clearfix'></div>
		
		<?php if( is_user_logged_in() ){ ?>
		<div class='clearfix'></div>
					<?php //	echo get_template_part( "content", "welcome-profile" ); 
					?>

		<div class='clearfix'></div><br class="visible-xs visible-sm">
		
		<a href='/members' class='btn btn-block btn-primary btn-lg hidden1'>> All Members <</a>
		<hr>
		<?php 
				
				echo do_shortcode(" [wpmem_form login] "); ?>
	</div>
	
	
	            
				
				
		<?php }else{ ?>
				<h3>Member Login</h3><hr>
				
				<?php echo do_shortcode(" [wpmem_form login] "); ?>
		<?php } ?>



	</div>


<div class='clearfix'></div>

</div><!-- .content-area -->


	
	
	


	<div class='clearfix'></div>
<?php get_footer('preview'); ?>
