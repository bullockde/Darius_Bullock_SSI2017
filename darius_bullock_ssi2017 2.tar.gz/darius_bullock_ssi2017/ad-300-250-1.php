<div class='col-sm-6 col-md-12 ads ad-shift img-thumbnail'>
<div class='clearfix mb-5'></div>
	<center>
	<b> Featured Partner </b>
	<div class='clearfix mb-5'></div>
		<!-- JuicyAds v3.1 -->
		<script type="text/javascript" data-cfasync="false" async src="https://poweredby.jads.co/js/jads.js"></script>
		<ins id="640041" data-width="300" data-height="262"></ins>
		<script type="text/javascript" data-cfasync="false" async>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':640041});</script>
		<!--JuicyAds END-->
		
	</center>
	<div class='clearfix'></div>
</div>