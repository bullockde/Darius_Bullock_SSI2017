<div class='filters'>
<div class='col-xs-3 hidden'>
	&nbsp;
</div>
<div class='col-xs-4'>
	<a target="_blank" href='http://instaflixxx.com/category/straight-porn/' class='filter'>
Str8</a>
	
</div>
<div class='col-xs-4'>
	<a target="_blank" href='http://instaflixxx.com/category/gay/' class='filter'>
Gay</a>
</div>
<div class='col-xs-4'>
	<a target="_blank" href='http://instaflixxx.com/category/bisexual/' class='filter'>
Bi</a>
</div>
<div class='col-xs-2 hidden'>
	<a target="_blank" href='http://instaflixxx.com/category/transexual-porn/' class='filter'>
Trans</a>
</div>



<div class='clearfix'></div>
</div>