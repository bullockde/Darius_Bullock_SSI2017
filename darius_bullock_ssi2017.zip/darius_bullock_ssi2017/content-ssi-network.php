<div class='banner'></div>
<div class='leader' >
	<div class='container'>
	<div class='col-md-2'>
	
		<img class='img-responsive hidden-xs aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/08/2015-08-06-09.29.35.jpg'>
	
	</div>
	<div class='col-md-8 ' >
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- ShamanShawn_leaderboard_responsive -->
	<ins class="adsbygoogle"
	     style="display:block"
	     data-ad-client="ca-pub-3813829909026031"
	     data-ad-slot="1875140181"
	     data-ad-format="auto"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
	</div>
	<div class='col-md-2 hidden-xs hidden-sm '>
	
		<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/08/2015-08-06-09.29.35.jpg'>
	
	</div>
	<div class='clear'></div>
	</div><!-- #container -->
	<div class='clear'></div>
</div>
</div><div class='clear' ></div>
<div class='tagline text-center'>
	"Bridging the Gap between the HAVE's and the HAVE NOT's." -#SSI
</div>
	

<div class='clear'></div>
<section class='welcome text-center'  class='pad0 left50'>
		<h2> InstaGram Feed </h2>
			<?php echo do_shortcode('[instagram-feed]'); ?>
		<br>
	
<div class='clear'></div>

</section>