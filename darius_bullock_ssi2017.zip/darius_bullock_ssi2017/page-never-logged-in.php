<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

    <head>

        <meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php 
            if (is_home () ) {
                echo "InstaFliXXX | Connecting People and Porn to Keep you Cumming Back!";
            } elseif (is_attachment() ) {
                echo "InstaFliXXX | ";echo get_the_title($post -> post_parent).' &#124; '; wp_title('', true);
            } elseif (is_category() ) {
                echo "InstaFliXXX | "; single_cat_title();
            } elseif (is_single() || is_page() ) { 
                echo "InstaFliXXX | "; single_post_title();
            } elseif (is_search() ) { 
                echo "InstaFliXXX | "; echo esc_html($s);
            } else { 
                echo "InstaFliXXX | "; wp_title('',true); 
            }
        ?></title>
        <meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
		<meta name="msvalidate.01" content="456062FFEDF8BA0A8E1A597F6D226AEB" />
		<meta name="description" content="InstaFliXXX is most diverse Adult Social Network for Gay, Straight, and Transgender dating and hookups, FREE Porn, Adult Events and Sex Parties, Music Videos, Entertainment and more...">
		<meta name="keywords" content="music videos, news, entertainment, gay porn, straight porn, porn, bisexual, transexual porn, tranny, transgender, gay personals,online dating, homo , homosexual, homo sexual, FTM, MTF gay guys,International,  black man, gay pride, gratis,  group, web cam, chat rooms,  dating, gay chat,New York City, Los Angeles, Toronto, London, Philadelphia, Miami, Chicago, Montreal, Milan, Rome, Denver, Washington D.C., Atlanta, Seattle, Vancouver, San Diego, England, Florida, Baltimore, NYC, San Francisco, Bay Area, Boston, Berlin, Fort Lauderdale">
   
		<meta name="juicyads-site-verification" content="c9360451cb6a0750ab996c17e465832f" />
		
        <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
        <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        
        <?php wp_head(); ?>
        <script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
		<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
		 <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
        <script src="<?php bloginfo('template_directory'); ?>/js/jquery.tools.min.js" type="text/javascript"></script>

        <script src="<?php bloginfo('template_directory'); ?>/js/init.js" type="text/javascript"></script>
		 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
		





<script type="text/javascript">

// JK Pop up image viewer script- By JavaScriptKit.com
// Visit JavaScript Kit (http://javascriptkit.com)
// for free JavaScript tutorials and scripts
// This notice must stay intact for use

var popbackground="#EDEDEF" //specify backcolor or background image for pop window
var windowtitle="InstaFliXXX Image Window"  //pop window title

function detectexist(obj){
return (typeof obj !="undefined")
}

function jkpopimage(imgpath, popwidth, popheight, textdescription){

function getpos(){
leftpos=(detectexist(window.screenLeft))? screenLeft+document.body.clientWidth/2-popwidth/2 : detectexist(window.screenX)? screenX+innerWidth/2-popwidth/2 : 0
toppos=(detectexist(window.screenTop))? screenTop+document.body.clientHeight/2-popheight/2 : detectexist(window.screenY)? screenY+innerHeight/2-popheight/2 : 0
if (window.opera){
leftpos-=screenLeft
toppos-=screenTop
}
}

getpos()
var winattributes='width='+popwidth+',height='+popheight+',resizable=yes,left='+leftpos+',top='+toppos
var bodyattribute=(popbackground.indexOf(".")!=-1)? 'background="'+popbackground+'"' : 'bgcolor="'+popbackground+'"'
if (typeof jkpopwin=="undefined" || jkpopwin.closed)
jkpopwin=window.open("","",winattributes)
else{
//getpos() //uncomment these 2 lines if you wish subsequent popups to be centered too
//jkpopwin.moveTo(leftpos, toppos)
jkpopwin.resizeTo(popwidth, popheight+30)
}
jkpopwin.document.open()
jkpopwin.document.write('<html><title>'+windowtitle+'</title><body '+bodyattribute+'><img src="'+imgpath+'" style="max-width:600px;max-height:400px;margin-bottom: 0.5em; "><br />'+textdescription+'</body></html>')
jkpopwin.document.close()
jkpopwin.focus()
}

</script>
<script>
function iLoveCookies(){
   days=30; // number of days to keep the cookie
   myDate = new Date();
   myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
   document.cookie = 'family=1; expires=' + myDate.toGMTString();
}
function iHateCookies(){
   days=30; // number of days to keep the cookie
   myDate = new Date();
   myDate.setTime(myDate.getTime()-(days*24*60*60*1000));
   document.cookie = 'family=1; expires=' + myDate.toGMTString();
}
function insta_new_visit(){
   days=30; // number of days to keep the cookie
   myDate = new Date();
   myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
   document.cookie = 'new_visitor=1; expires=' + myDate.toGMTString();
   //iLoveCookies();
}


</script>


    </head>

    <body class='<?php if( $_GET['dev'] ) echo "dev-new" ; ?> dev'>
		
	
	<div class="row new-header">
		<div class='container'>


			<div class='col-left'>
					
				<!--<a href='/'>   
					<div><img class='porn ' src='http://instaflixxx.com/wp-content/uploads/2014/01/InstaFliXXX-Logo-transparent.png'></div>     

				</a> -->
			</div>
			<div class='col-mid'>
			
					<!--JuicyAds v2.0->
					<iframe border="0" frameborder="0" marginheight="0" marginwidth="0" width="476" height="68" scrolling="no" allowtransparency="true" src="http://adserver.juicyads.com/adshow.php?adzone=188534"></iframe>
					<!--JuicyAds END-->
		
				<!--<form method="post" action="<?php bloginfo('url'); ?>/">
					
					<input type="text" class="search-form" name="s"  value="Search" onblur="javascript: if(this.value == '') { this.value = 'Search';}" onfocus="javascript: if(this.value == 'Search') this.value = '';"/>
					<input type="submit" class="search-button" value="Search" />
				
				</form>-->
			
			</div>    	
			<div class='col-right'>	
				<?php //echo dispMailbox(); ?>
				
				<!--	<div class='filters-new porn '>

					<a href='http://instaflixxx.com/category/straight-porn/'><div class='filter'>
					Str8</div></a>
					<a  href='http://instaflixxx.com/category/gay/'><div class='filter'>
					Gay</div></a>
					<a  href='http://instaflixxx.com/category/bisexual/'><div class='filter'>
					Bi</div></a>
					<a  href='http://instaflixxx.com/category/transexual-porn/'><div class='filter'>
					Trans</div></a>
					</div>
				
						<div class='tagline porn'>Connecting <b>People</b> and <b>Porn</b> to Keep You <em>Cumming</em> Back!</div>
				-->		

			</div>   

		</div>
    
    </div>
	

	<div class="clear"></div>

	<div class="navigation action-title">
		
		<h2>ADMIN - Never Logged In</h2>
		 
	</div>


<div id='video-choice'></div>
    <div class="main admin">
    
        <div class="site-container">
			<div class='home-beta column left'>
			
				<?php include('admin-sidebar.php'); ?>
				
			</div>
            <div class="main-content">
            




				<div>

					<?php //include('members-search.php'); ?>
								
				</div>	
	
				
			
					<?php
					
				
						$args = array(
						
							'blog_id' => '1',
							'orderby' => 'registered',
							'order' => 'DESC',
							//'offset' => $paged ? ($paged * $number) : 0,
							//'number' => $number
						
						);
						
						$blogusers = get_users( $args );
						$count = 0;
						
						$never_logged = array();

						foreach ($blogusers as $user) {
								$last_login = (int) get_user_meta( $user->ID, 'when_last_login' , true );
								if($last_login){
										//do nothing
								}else{
										array_push( $never_logged , $user );
								}
						}
						$blogusers = $never_logged;
						
						$total_users = (count($blogusers));
					
						echo "<div class='results' style='text-align: left;'>Never Logged in:";
						echo "<span style='float: right;'>" . $total_users ." Results</span></div>";
						
						echo "<table>";
							echo "<tr><th>Username: </th><th> - Email: </th><th> - Joined: </th></tr>";
						foreach ($blogusers as $user) {
						
								echo "<tr><td>" . $user->user_login . "</td><td>" . $user->user_email . "</td><td>" . $user->user_registered . "</td></tr>";

						} //End For-each 
						echo "</table>";
		
					?>


            </div>
	
	
        </div>
		

		

        <?php //get_sidebar('right'); ?>
        
        <div class="clear"></div>
        
    </div>
    
<?php get_footer(); ?>
