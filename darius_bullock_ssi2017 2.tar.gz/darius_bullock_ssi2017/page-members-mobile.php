<?php 

// if( current_user_has_avatar() ){}else{
		
	//	$pg = "/photo-required"; wp_redirect($pg); exit;
// }

$current_user  = $user = wp_get_current_user(); 

get_header('mobile'); 

	//$cats = array( get_cat_ID('current-event') , get_cat_ID('playroom') );

//	$events = get_posts(array( 'post_type' => 'ssi_events', 'category' =>  $cats, 'posts_per_page' => 5 , 'order' => 'desc'));
	
//	$event = $events[0];
	
	//print_r( $events );
	
	//echo "<span class='alert alert-danger btn-block text-center'> Site Maintenance - Ends at 6AM!</span>";
	?>
<head>
    <style>
        #wppa_widget-5 img{
            
            max-width: 250px !important;
        }
    </style>
</head>
<div class="btn-group btn-group-justified">


    <a href="/profile" class="btn btn-default"> <small>PROFILE</small> </a>
	
		<a href="/photos" class="btn btn-default"> <small>PHOTOS</small> </a>
	<a href="/videos" class="btn btn-default"> <small>VIDEOS</small> </a>
	  <a type="button" class="btn btn-default 1btn-md hidden1" id="myBtn2" data-toggle="modal" data-target="#myModal2-menu" data-show="true">MENU</a>

	<!--
		<a href="/members-list/<?php echo $current_user->user_nicename; ?>/" class="btn btn-default"> <small>PROFILE</small> </a>
	<a href="/members-list/<?php echo $current_user->user_nicename; ?>/media/photos" class="btn btn-default"> <small>PHOTOS</small> </a>
	<a href="/members-list/<?php echo $current_user->user_nicename; ?>/media/videos" class="btn btn-default"> <small>VIDEOS</small> </a>
	
	<!--<a href="/menu" class="btn btn-default hidden"> <small>MENU</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=4" class="btn btn-default">Level 4 <br> <small>REQUEST</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=5" class="btn btn-default">Level 5 <br> <small>SESSION</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=6" class="btn btn-default">Level 6 <br> <small>THoT FILE</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=7" class="btn btn-default">Level 7</a>-->
	<!--<a href="http://dlfreakfest.org/levels/?level=8" class="btn btn-default">Level 8</a>-->
	<!--<a href="http://dlfreakfest.org/levels/?level=9" class="btn btn-default">Level 9</a>-->
	<!--<a href="http://dlfreakfest.org/levels/?level=10" class="btn btn-default">Level 10</a>-->
</div>
	<?php
		
		 //get_template_part( 'content', 'uc-events' ); 
		 //get_template_part( 'content', 'welcome' ); 
		 //
		 
		  
			echo dispMailbox(); 
			
			
			//	get_template_part( 'content', 'upcoming-events' ); 
			 //get_template_part( 'content', 'welcome-profile' ); 
			 //echo "<div class='mb-10'></div>";
			 //get_template_part( 'content', 'uc-events' ); 
		
	?>

		

	
	<div class='clearfix mb-0'></div>



<div id='primary1' class='container-fluid  '>
    <div class='row  '>
<div class='col-md-8  '>
<div class='row  '>
				
<?php	
    get_template_part('content', 'members-paged');
   
?>			
<div class='clear'></div>

 </div>
 
 
 
 <div class='clear'></div><br>
<?php if( !wp_is_mobile() ){  ?>
        <div class='clearfix mb-0'></div>
	
		<center>
		    <div class='col-md-6'><?php get_template_part('ad', '300-250-1'); ?></div>
		    <div class='col-md-6'><?php get_template_part('ad', '300-250-2'); ?></div>
        </center>
		<div class='clearfix mb-15'></div>
<?php }else{  ?>
    <center>
		    <div class=''><?php get_template_part('ad', '300-250-1'); ?></div>
		    
        </center>
    <div class='clearfix mb-15'></div>


<?php }  ?>




</div>

<div class='col-md-4  '>
    <div class='row  text-center'>
        <div class='clearfix'></div>
        
        <!--<br><br class='hidden-xs'><br class='hidden-xs'>-->
        	<?php 
		
			//get_template_part('content' , 'member-quicknav'); 

		//	get_template_part( 'content', 'sidebar-ads' ); 
			
		//	get_sidebar();
			
		//	get_template_part( 'content', 'sidebar-upcoming-events' );
			
			//get_template_part( 'ad', '300-250-1' );
		
		
		?>
        <!--<div class='clearfix'></div><br>-->
        <div class='well 1visible-xs mb-0'>
        	<?php 
		
			//get_template_part('content' , 'member-quicknav'); 

		//	get_template_part( 'content', 'sidebar-ads' ); 
			
		//	get_sidebar();
			
		//	get_template_part( 'content', 'sidebar-upcoming-events' );
			
		//	get_template_part( 'ad', '300-250-1' );
			dynamic_sidebar( 'content-bottom-2' );
		
		
		?>
        </div>
        
    </div>
</div>
 <div class='clearfix'></div>
 
</div>
</div>

 </div>

    <div class='clearfix mb-0'></div>
    
    
    
    <div class="btn-group btn-group-justified">

    
        <a href="/gallery" class="btn btn-default"><small>GALLERY</small></a>
    	
    		
    	
    	<a href="/members-list/<?php echo $current_user->user_nicename; ?>/media/" class="btn btn-default"><small>My UPLOADS</small></a>
    	
    	<a href="/photos-ratings" class="btn btn-default"><small>RATINGS</small></a>
    	<a href="/mailbox" class="btn btn-default hidden "><small>MAIL</small></a>
    	  <a type="button" class="btn btn-default 1btn-md hidden" id="myBtn2" data-toggle="modal" data-target="#myModal2-menu" data-show="true">MENU</a>
    
    	<!--
    		<a href="/members-list/<?php echo $current_user->user_nicename; ?>/" class="btn btn-default"> <small>PROFILE</small> </a>
    	<a href="/members-list/<?php echo $current_user->user_nicename; ?>/media/photos" class="btn btn-default"> <small>PHOTOS</small> </a>
    	<a href="/members-list/<?php echo $current_user->user_nicename; ?>/media/videos" class="btn btn-default"> <small>VIDEOS</small> </a>
    	
    	<!--<a href="/menu" class="btn btn-default hidden"> <small>MENU</small> </a>
    	<a href="http://dlfreakfest.org/levels/?level=4" class="btn btn-default">Level 4 <br> <small>REQUEST</small> </a>
    	<a href="http://dlfreakfest.org/levels/?level=5" class="btn btn-default">Level 5 <br> <small>SESSION</small> </a>
    	<a href="http://dlfreakfest.org/levels/?level=6" class="btn btn-default">Level 6 <br> <small>THoT FILE</small> </a>
    	<a href="http://dlfreakfest.org/levels/?level=7" class="btn btn-default">Level 7</a>-->
    	<!--<a href="http://dlfreakfest.org/levels/?level=8" class="btn btn-default">Level 8</a>-->
    	<!--<a href="http://dlfreakfest.org/levels/?level=9" class="btn btn-default">Level 9</a>-->
    	<!--<a href="http://dlfreakfest.org/levels/?level=10" class="btn btn-default">Level 10</a>-->
    </div>
</div>
<?php get_footer('mobile'); ?>

<script>
    
$('.filter-form input').change(function() {
    $(this).closest('form').submit();
});
</script>