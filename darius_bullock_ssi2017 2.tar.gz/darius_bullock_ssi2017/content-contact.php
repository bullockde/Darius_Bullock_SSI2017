<div class='clearfix'></div>

<section class='contact'>
	
	<div class='container'>
		<div class='row'>
			<div class='col-xs-6'>
				<h2>#SSIContact: </h2>
			</div>	
			<div class='col-xs-6'>
				<button id='contact' class='hidden btn btn-lg btn-default btn-section'>View / Hide</button>
			</div><div class='clearfix'></div>
			<hr>
		</div>
			
			
	<div id='contact' style=' display: block;'>

	
		<div class="col-sm-4">
				<h3>Testimonials</h3>
				
				<strong>We Accept, Read, and Appreciate all Feedback!!</strong>
				<?php echo do_shortcode('[gravityform id="2" name="Anonymous Feedback" title="false" description="false"]'); ?>
			
		</div>
		<br class='visible-xs'>
		<div class="col-sm-4">
				<h3>Contact Menu</h3>
				<a href='/jobs/' class='btn btn-lg btn-default btn-block'>Internship Opportunities</a><br>
				<a href='/jobs/' class='btn btn-lg btn-default btn-block'>View Odd Jobs</a><br>
				<a href='/testimonials/' class='btn btn-lg btn-default btn-block'>View All Testimonials</a><br>
				<a href='/contact/' class='btn btn-lg btn-default btn-block'>Contact Us Page</a><br>
			
		</div>
		<div class="col-sm-4">
				
				<h3>Contact Us</h3>
				
				<?php echo do_shortcode('[gravityform id="10" name="Simple Contact" title="false" description="false"]'); ?>
				
				
				

			
		</div>
	</div><!-- // #contact -->
	</div><!-- // #container -->
</section>

<div class='clearfix'></div>