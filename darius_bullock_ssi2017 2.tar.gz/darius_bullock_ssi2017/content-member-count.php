
	<div class='clearfix'></div>
				<?php //get_template_part( 'content' , 'member-area' ); 
				?>
				

		<section id='join' class='hidden1 <?php if( is_front_page() ){ echo "1hidden"; } ?>' >
		<center>
		
		
		<h1>
		<a href="/members">
		<u><?php $args = array(
						
							//'number' => -1,
							//'meta_key' => 'wp-last-login',
							//'orderby'  => 'meta_value_num',
							//'orderby'  => 'registered',
							'order' => 'DESC',
							//'date_query' => array( array( 'after' => '12/25/16' ) )  ,
							
						) ;
						
						$ordered_users =  new WP_User_Query( $args );

						
						$blogusers = $ordered_users->get_results();
						
						$total_results = count($blogusers);
						
						echo $total_results;
						
						?></u> MEMBERS ONLINE
						
						</a>
		</h1>
		<div class='clearfix mb-10'></div>
				<?php //get_template_part( 'content' , 'member-area' ); 
				?>
				
		
		
	</section>