<div class='clear'></div>

<div id='jumbo' class='text-center  page-pad '>

		<br><hr>
		<h2 class='entry-title'>My Lifestyle</h2><hr>
		
		<div class='container'>
		<br>
			<div class="col-md-4">
				
				<a href='http://shamanshawninc.com/' target='_blank'> <img class='img-responsive aligncenter' src='/wp-content/uploads/SSI-Collage-New.png'></a>
			</div>
			
			<div class="col-md-8">
				
				<a href='/projects/'><div class='btn col-xs-12'>My Work</div></a>
				<a href='/trips/'><div class='btn col-xs-12'>My Travel</div>	</a>
				<!--<a href='/coaching/'><div class='btn col-xs-12'>Coaching</div></a>-->
				<a href='/brands/'><div class='btn col-xs-12'>My Hobbies</div></a>					
				
			</div>
		</div>
	
	</div>

<div class='clear'></div><hr>