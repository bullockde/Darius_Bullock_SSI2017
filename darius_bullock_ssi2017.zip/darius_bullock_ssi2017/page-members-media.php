<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">
		<?php
		// Start the loop.
		while ( have_posts() ) :
			the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End the loop.
		endwhile;
		?>
		
		
		<?php
// Retrieve all media files
$args = array(
    'post_type'      => 'attachment',
    'post_mime_type' => 'image', // Adjust mime type if you want other media types
    'post_status'    => 'inherit',
    'posts_per_page' => 9,
);

$query = new WP_Query($args);

// Organize media files by month and year
$media_by_month = array();
while ($query->have_posts()) {
    $query->the_post();
    $attachment_id = get_the_ID();
    $attachment_date = get_the_time('F Y', $attachment_id);

    if (!isset($media_by_month[$attachment_date])) {
        $media_by_month[$attachment_date] = array();
    }

    $media_by_month[$attachment_date][] = $attachment_id;
}

// Display media files in a grid organized by month and year
foreach ($media_by_month as $month => $media_ids) {
    $num_items = count($media_ids);

    echo '<h2>' . $month . ' (' . $num_items . ' items)</h2>';
    echo '<div class="media-grid">';

    foreach ($media_ids as $media_id) {
        $image_url = wp_get_attachment_image_src($media_id, 'thumbnail')[0];
        $image_alt = get_post_meta($media_id, '_wp_attachment_image_alt', true);

        echo '<div class="media-item img-thumbnail col-xs-4">';
        //echo '<img src="' . $image_url . '" alt="' . $image_alt . '">';
        echo '<a href="' . get_attachment_link($media_id) . '"><img src="' . $image_url . '" alt="' . $image_alt . '"></a>';
   
        echo '</div>';
    }

    echo '</div>';
}

// Restore global post data
//wp_reset_postdata();
?>

<div id="media-container">
    <?php
    // Start the main loop
   /* if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            // Display the post content as desired
            echo '<div>' . get_the_title() . '</div>';
        }
    }*/
    ?>
</div>
<div class="clearfix mb-0"></div>
<br>
<div class="clearfix text-center">
<button id="load-more-button" class="btn btn-success ">Load More</button>
</div>




	</main><!-- .site-main -->

	<?php get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->

<?php get_sidebar(); ?>


<script>
jQuery(function($) {
    var page = 1;
    var loading = false;
    var $loadMoreButton = $('#load-more-button');
    var $postContainer = $('#media-container');

    $loadMoreButton.on('click', function() {
        if (!loading) {
            loading = true;
            $loadMoreButton.text('Loading...');

            var data = {
                action: 'load_more_posts',
                query: '<?php echo json_encode($args); ?>', // Pass the query parameters to the AJAX handler
                page: page
            };

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // URL to the AJAX handler
                data: data,
                type: 'POST',
                success: function(response) {
                    if (response) {
                        $postContainer.append(response);
                        page++;
                        loading = false;
                        $loadMoreButton.text('Load More');
                    } else {
                        $loadMoreButton.text('No more posts');
                    }
                }
            });
        }
    });
});
</script>

<?php get_footer(); ?>
