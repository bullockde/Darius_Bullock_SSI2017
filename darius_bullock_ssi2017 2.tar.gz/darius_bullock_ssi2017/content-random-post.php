				<div id='whatsnew' class='random well green' style='display: block; '>
		<?php
				query_posts(array(  'orderby' => 'rand', 'showposts' => 1 ));
				if (have_posts()) :
				while (have_posts()) : the_post(); 
		?>
				
				<div class='text-center'>
				
			

				<?php
					$format = get_post_format( get_the_ID() );

					if( $format == 'video' || in_category( 'music' , get_the_ID() ) || in_category( 'songs-that-touch-the-soul' , get_the_ID() ) ){
					//get_template_part( 'content', 'video' );
					}else{
						?>
						<a href="/blog">Featured FliXXX >></a><br><br>
						<!--<h3><?php the_title(); ?></h3>
						-->
						<center><?php //twentysixteen_post_thumbnail(); ?></center>
						<?php //the_post_thumbnail();

							//get_template_part( 'content', 'video' );

							the_content(); 
							
							
						?>
						
			
						
						<a  href='<?php the_permalink() ?>' class='btn btn-info btn-lg btn-block hidden1'>Watch Now >></a>
						
						
						
					<?php
					//get_template_part('template-parts/content' , 'page');
					//the_content(); 
					}
				?>
				</div>
				
				

	<?php endwhile;
		endif;

		wp_reset_query();
		?>
		
		</div>