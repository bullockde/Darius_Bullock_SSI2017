<section id='requests' class='text-center' style='color: #000;'>

	<div class='container'>
			<div class="page-header" id="feeback">
					<h3>Recent Requests</h3>
				</div>

<div class="clear"></div>
      
                <?php $args = array( 'post_type' => 'ssi_requests' , 'numberposts' => -1 );

                $rand_posts = get_posts( $args );

                foreach( $rand_posts as $post ){ ?>
            
                <div class="post well" id="post-<?php the_ID(); ?>">
				
				
				
							 <strong>Session Request</strong>

							<br><br>
				
				
				
				
							<div class='col-sm-6 well yellow'>
	
									
									
									
									
									
									<div class=" ">
											
												<div class="col-xs-5 col-md-4">
												
												
													<a target='_blank' href='/members-list/<?php echo $current_user->user_nicename; ?>/profile/change-avatar/' class=' '>
														<?php //echo do_shortcode("[bp_profile_gravatar]"); 
														
														
														
														?>
														
														
																<?php 
												
												echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>";
												
													$user = get_user_by('email', get_field( "MX_user_email", $post->ID ));
												
											
												
													if (  get_avatar($user->ID, 100)  ) {
														
														
									
														?>
														<center>
															<?php echo get_avatar($user->ID, 150); ?>
														</center>
														<?php 
													}else{
														?>
														<img src='http://www.gravatar.com/avatar/194803a51d4a564b26379aea65ac8fda?s=96&r=x&d=http%3A%2F%2Fdlfreakfest.org%2Fwp-content%2Fuploads%2F2019%2F11%2F5dde1c7720197-bpfull.jpg' class='img-responsive aligncenter' width='150'>
													
														<?php 
														
													}
										
												?>
												
												
														
														
													</a>
												
												
												
														

												</div>
												<div class="col-xs-7 col-md-8 text-center report">
												
													<b><?php echo "<h3>" . $post->post_title . '</h3>'; ?></b>
													<hr>
													
													<center>
													<?php	

															if( get_post_meta($post->ID, 'MX_user_age' , 1) ){
																		echo get_post_meta($post->ID, 'MX_user_age' , 1) . ' | ';
															}else{
																		echo '- | ';
															}
															if( get_post_meta($post->ID, 'MX_user_height' , 1) ){
																echo get_post_meta($post->ID, 'MX_user_height' , 1) . ' | ';
															}else if( get_post_meta($post->ID, 'MX_user_height_ft' , 1) ){
																		echo get_post_meta($post->ID, 'MX_user_height_ft' , 1) . "' " . get_post_meta($post->ID, 'MX_user_height_in' , 1) . '" | ' ;
															}else{
																		echo '- | ' ;
															}
															if( get_post_meta($post->ID, 'MX_user_weight' , 1) ){
																		echo get_post_meta($post->ID, 'MX_user_weight' , 1) . "<br>";
															}else{
																		echo '- <br>';
															}
																?>
													</center>
													
													<div class='clear'></div><br>
											
												<div class='text-center small'>
												Location<br>
												<b><?php 
												
													$closet = 0;
																if ( get_post_meta($post->ID, 'MX_user_city', 1 ) && get_post_meta($post->ID, 'MX_user_state', 1) ){

																										echo ' <span style="text-transform: capitalize;">' . get_post_meta($post->ID, 'MX_user_city', 1 ) . '</span>, ';
																										echo get_post_meta($post->ID, 'MX_user_state', 1) ;

																}
																else if ( get_post_meta($post->ID, 'MX_user_state', 1) ){
																	echo  get_post_meta($post->ID, 'MX_user_state', 1);
																}
																else{
																	$closet = 1;
																	echo '-';
																}				
																
											?></b>
											</div>
											<div class='clear'></div>
											
											

												</div>
										
												
												
												
															
									
												<div class='clear'></div>	
										<div class='well green hidden'>
													<h4>YungDADDY Requests<hr></h4>		
																
										<a  target='_blank' href='/cash' class='btn btn-success btn-block hidden1'> REQUEST Money >> </a>
										
										<a target='_blank' href='/bae?ID=<?php echo $Model_ID; ?>' class='btn btn-info btn-block hidden1'> REQUEST a DATE >> </a>
										
										<a target='_blank' href='/request' class='btn btn-info btn-block hidden1'> REQUEST a Meeting >> </a>
										
										
										
										</div>
												
													

											</div>
											
											
											
											<div class='clear'></div>	

									
									</div>	


                       
					
				<div class='col-md-6 well green'>
				<div class='clearfix mb-10'></div>
				
					<div class=' col-xs-6'>
					
						<u><b>Date</b></u> <br><?php echo get_post_meta($post->ID, 'request_date', true) ?>
					</div>
					<div class=' col-xs-6'>
					
						<u><b>Time</b></u> <br><?php echo get_post_meta($post->ID, 'request_time', true) ?>
					</div>
				<div class=' clear visible-xs'><br></div>
					<div class=' col-xs-6'>
					<br>
						<u><b>Length</b></u> <br><?php echo get_post_meta($post->ID, 'request_length', true) ?>
					</div>
					<div class=' col-xs-6'>
					<br>
						<u><b>Budget</b></u> <br>$<?php echo get_post_meta($post->ID, 'request_min_budget', true) ?> - $<?php echo get_post_meta($post->ID, 'request_max_budget', true) ?>
					</div>
                   </div>
					<div class=' clear'></div><br>
				<u>Requested Services</u> <br><?php $services = get_post_meta($post->ID, 'service_recieved');
						foreach($services as $service) echo $service . "<br>";
				?>
				
				<div class='clear'></div><br>
								
					<u>Desired Experience</u><br> 
                  <?php 
				  $my_postid = $post->ID;//This is page id or post id
					$content_post = get_post($my_postid);
					$content = $content_post->post_content;
					$content = apply_filters('the_content', $content);
					$content = str_replace(']]>', ']]&gt;', $content);
					//echo $content;
					echo "- PRIVATE -<br>" ;
				  ?> <br>
				  
				  
				<!-- <strong><u>STATUS</u></strong><br> Pending! -->
                    
					<?php if( is_user_logged_in() ){ ?> 	
						<div class='clear'></div>
						
						<div class="link"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
					
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail(array(240,180), array('alt' => get_the_title(), 'title' => '')); ?></a><br>
					
					<u>Age</u> <br><?php echo get_post_meta($post->ID, 'MX_user_age', true) ?><br>
					<u>Height</u> <br><?php echo get_post_meta($post->ID, 'MX_user_height', true) ?><br>
					<u>Weight</u> <br><?php echo get_post_meta($post->ID, 'MX_user_weight', true) ?><br>
					<u>Phone</u> <br><?php echo get_post_meta($post->ID, 'MX_user_phone', true) ?><br>
					
					<u>Email</u> <br><?php echo get_post_meta($post->ID, 'MX_user_email', true) ?><br>
						
					<?php } ?>
				
                </div>
				
				<?php } ?>
            
            <div class="clear"></div>
			<a target='_blank' href="/request" class="btn btn-lg btn-info btn-block">Request A Session >></a>
			<div class="clear"></div>
			
		</div>
</section>