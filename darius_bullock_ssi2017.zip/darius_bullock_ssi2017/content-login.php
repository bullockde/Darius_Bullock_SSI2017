
	<div  class="col-xs-12 col-sm-6 col-md-4 col-md-offset-4 col-sm-offset-3 text-center">
				    
			
				<?php // echo do_shortcode(" [wpmem_form register] "); 
				
				
				?>
				
				
			
        				
        				
        			<?php if ( !is_user_logged_in() ) { ?>	
        				<div class="well mb-10  blue">
        				<div id='login' style='display: block;' class='h5'>
        				<?php echo apply_shortcodes('[miniorange_social_login theme="default"]') ?>
        				<div class='clearfix mb-0'></div>
        				
        				
        				<button id='login' class='btn btn-success btn-lg 1btn-block'>Member Login</button>
        			
						
					
				</div>
				
				<div id='login' class='footer-login' style='display: none;'>
        				<?php 
        				
        				//echo do_shortcode("[wpmem_form login redirect_to='/edit']");
        				
        				get_template_part( "content" , "header-login" );
        				//wp_login_form();
        				
        				 ?>
        			</div>
					<div class='clearfix mb-0'></div>
						</div>

        				<?php } ?>	
    </div>
        			
        			
					<div class='clearfix mb-0'></div>
					
					
					
        			
				