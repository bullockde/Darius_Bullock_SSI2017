<div class='clear'></div>

		<img class='img-responsive aligncenter' title='Shaman Shawn Inc' src='/wp-content/uploads/2018/09/shaman-shawn-inc-header.png'>
			

		<div class='container text-center hidden1'>
			
			
			
			
			<div class="col-md-12 text-center">
			
			
				
				 
			<div class="">


		<div class='clear'> </div>
		<div class=''>	
		
		
		
			<div class="col-sm-4">
				<a href='/web'> 
			
				<div class=' circle-button btn btn-default btn-block btn-lg'>
					Website Design
			  </div>
			
				</a>
			</div>
			<div class="col-sm-4">
				<a href='/marketing'> 
			
				<div class=' circle-button btn btn-default btn-block btn-lg'>
					Marketing
 </div>
			 
			 
				</a>
			</div>
			
			<div class="col-sm-4">
				<a href='/marketing'> 
			 
				<div class=' circle-button btn btn-default btn-block btn-lg'>
					Brand Management
			  </div>
			  
			 
				</a>
			</div>

<div class='clear'> </div>

</div>
<div class='clear'></div>


				<div class="col-sm-4">
				<a href='/connect' target='_blank'> 
			
				<div class=' circle-button btn btn-default btn-block btn-lg'>
					Staffing
			  </div>
			
				</a>
			</div>
<div class="col-sm-4">
				<a href='/consulting'> 
			
				<div class=' circle-button btn btn-default btn-block btn-lg'>
					Consulting
 </div>
			 
			 
				</a>
			</div>
			<div class="col-sm-4">
				<a href='/help'> 
			
				<div class=' circle-button btn btn-default btn-block btn-lg'>
					Training / Help
			  </div>
			
				</a>
			</div>
				 <div class="clear"></div><br>
				 
				 <a href='http://shamanshawninc.com' target='_blank' class='btn  btn-lg btn-default btn-block hidden1'> Visit FULL Website >> </a>
				 <div class="clear"></div><br>
			</div>
<!--  #
			<div class="col-md-4">
				<h3>Paper Products</h3><hr>
				<ul>
					<li>Business Cards</li>
					<li>Promotional Flyers</li>
					<li>Event Advertising</li>
					<li>Invitations</li>
					<li>Thank You Cards</li><br>
					<a target='_blank' href='#' class='btn btn-default button-info btn-block'>View Paper Products >></a>
				</ul>
			</div>
			<div class="col-md-4">
				<h3>Web Products</h3><hr>
				<ul>
					<li>Website Creation</li>
					<li>Site Maintenance</li>
					<li>Web Updates & Edits</li>
					<li>SEO Management</li>
					<li>Server Management</li><br>
					<a target='_blank' href='#' class='btn btn-default button-info btn-block'>View Web Products >></a>
				</ul>
				
			</div>
			<div class="col-md-4">
				<h3>Brand Management</h3><hr>
				<ul>
					<li>Brand Creation</li>
					<li>Social Media Marketing</li>
					<li>Person 2 Person Ads</li>
					<li>Brand Consulting</li>
					<li>Customer Management</li><br>
					<a target='_blank' href='#' class='btn btn-default button-info btn-block'>Get Started >></a>
				</ul>
				
			</div>
  -->
		</div>
	
	</div><!--  #Marketing  -->

<div class='clear'></div><br>


<div class='clear'></div>

<section id='massage' class='services massage hidden1'>
		
		<div class='container'>
		<h2>Treat Yourself Massage & Wellness</h2><hr>
			<div class="col-md-6">
				
				<img class='img-responsive aligncenter' src='/wp-content/uploads/2016/04/tym-logo2.jpg'>

				
			</div>
			<div class="col-md-6">
				Professional Therapeutic Massage that comes to You!
<br><br>
				<strong> Specializing in: </strong>
				<ul>
					<li> Deep Tissue </li>
					<li> Sports Massage </li>
					<li> Myofascial Techniques</li>
					<li> Pregnancy Massage </li>
					<li> Relaxation Services </li>
					<li> Swedish Massage & More </li>
					<br>
					More info can be found at <a target='_blank' href='http://treatyourselfmassage.com' class='btn btn-md btn-success'>Treat Yourself Massage</a>
					
				</ul>
			</div>
		</div>
	
	</section><!--  #Massage  -->
	
	<div class='clear'> </div>
		


<div class='clear'></div>

<section id='computer' class=' services computer1 hidden'>
		
		<div class='container text-center'>
		<h2>TOTALLY WEB - Computer Services</h2><hr>
			
			<div class="col-md-6">
				
				
				<!--  #  
				- Speed up Slow Computers <br>(without deleting documents/photos/videos)<br>
				- Virus Detection & Removal<br>
				- Install & Configure Software<br>
				- Connect Printers to Network (normal/wifi)<br><br>
				-->

				- Website Creation <br>
				- Website Updates/Maintenance<br>
				- SEO (search engine optimization)<br>
				- Website Marketing<br>
				- &amp; much much more..<br><br>
				More info can be found at
									<a target='_blank' href='http://totally-web.com' class='btn btn-default btn-info'>TOTALLY-WEB</a>
				
			</div>
			<div class="col-md-6">
				
				<img class='img-responsive aligncenter' src='/wp-content/uploads/TOTALLY-WEB-facebook.jpg'>
				
				<!--  #
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/07/user52_pic198_1258236806.jpg'>
				-->

				
			</div>
		</div>
	
	</section><!--  #TOTALLY-WEB  -->

<section id='coaching' class='services coaching hidden1'>
		
		<div class='container'>
		<h2 class='text-center'>S.H.A.M.E - 2 - F.A.M..E Personal Coaching</h2><hr>
			<div class="col-md-6">
			
				<img class='img-responsive aligncenter' src='/wp-content/uploads/SHAME-results.png'> 
				
				<iframe width="100%" height="250" src="https://www.youtube.com/embed/ZjMvqfAOVyQ" frameborder="0" allowfullscreen></iframe>
				
				

				
			</div>
			<div class="col-md-6">
				
				
				My Life Coaching Program  that I refer to as "SHAME2FAME Coaching" is hand written and was developed and organized by me starting in 2015 and has evolved over time. The program is designed to Assist people in getting where "THEY Want To Go" as it relates to the  <br> <br> 

			<strong>8 Major Areas of Life:</strong>
&nbsp;
	
			<ul>
				<li>Home (Physical Environment)</li>
				<li>Career</li>
				<li>Money</li>
				<li>Health</li>
				<li>Romance</li>
				<li>Fun &amp; Leisure</li>
				<li>Friends &amp; Family</li>
				<li>Personal Growth</li>
			</ul>
					<br>
				More info can be found at 

					<a target='_blank' href='/coaching/' class='btn btn-md btn-warning'>SHAME 2 FAME</a>
					 
				
			</div>
		</div>
	
</section><!--  #Services  -->

<div class='clear'></div>


<div class='clear'></div>

<?php 

	//get_template_part( 'content', 'ssi-banner-ad' ); 
	//get_template_part( 'content', 'rentals' ); 
	//get_template_part( 'content', 'ssiauto' );

	
?>






<?php 
	
	
	//get_template_part( 'content-page-services', 'massage' );
	//get_template_part( 'content-page-services', 'coaching' );
	 
	
	// // get_template_part( 'content-page-services', 'marketing' );
	// // get_template_part( 'content-page-services', 'computer' );
	
	//get_template_part( 'content-page-services', 'maid' );
	//get_template_part( 'content-page-services', 'adult' );
	//get_template_part( 'content-page-services', 'consulting' );
	//get_template_part( 'content-page-services', 'events' );
	//get_template_part( 'content-page-services', 'makeup' );
		
	//get_template_part( 'content-page-services', 'more' );
	//get_template_part( 'content', 'wwss' );

	//get_template_part( 'content', 'services' );
?>
		