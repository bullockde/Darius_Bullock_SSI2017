<div class='col-md-6 col-md-offset-3' ><center><a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15807'> $1 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15808'> $5 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15809'> $25 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15810'> $50 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15811'> $60 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15812'> $70 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15813'> $80 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15814'> $90 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15815'> $100 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16730'> $105 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16731'> $110 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16732'> $115 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16733'> $120 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15822'> $125 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16728'> $130 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16729'> $135 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16734'> $140 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=16735'> $145 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15816'> $150 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15817'> $200 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15818'> $500 Donation </a>
<a class='btn btn-success btn-lg' href='https://ssi.memberful.com/checkout?plan=15819'> $1000 Donation </a></center></div>
<div class='clear'></div><br><br>