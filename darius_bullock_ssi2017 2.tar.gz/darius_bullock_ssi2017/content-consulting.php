<section id='consulting' class=' services consulting'>
		
		<div class='container'>
		<h2>Technical & Business Consulting</h2><hr>
			<div class="col-md-6">
				
<strong>Target Clients:</strong> Small to midsize Businesses.<br>
<br>
<strong>What I Offer:</strong><br>
- Honest Feedback from a Customer Standpoint<br>
- Review of all Marketing Material<br>
- Business Consulting<br>
- Technical Consulting<br>
- Website Creation (View our <a href="http://shamanshawn.com/packages/">Website Packages</a>)<br>
- Web Updates/Maintenance<br>
- SEO (search engine optimization)<br>
- Direct Person to Person Marketing<br>
- &amp; much much more..<br>
<br>


				<!--  <img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/09/2015-05-04-13.37.16.jpg'>  -->

				
			</div>
			<div class="col-md-6">
			<br>
<p style="text-align: center;"><strong>Call / Text</strong><br>
Shaman Shawn<br>
(267) 712 - 9124<br>
</p>
<a href="http://www.gofundme.com/TYMassage"><img class="aligncenter size-full wp-image-376" src="http://shamanshawn.com/wp-content/uploads/2015/07/donate.png" alt="donate" width="189" height="126" /></a>
			</div>
		</div>
	
	</section><!--  #Consulting  -->