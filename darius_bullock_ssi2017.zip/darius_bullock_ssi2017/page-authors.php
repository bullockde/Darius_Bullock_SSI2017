<?php
/**
 * 
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header('new-network'); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
	
	<?php wp_list_authors('show_fullname=1&optioncount=1&orderby=post_count&order=ASC&number=3'); ?>
	 
	 <hr>
		<?php
		
		
		$args = array(
						
							'blog_id' => '1',
							//'orderby' => 'registered',
							'order' => 'DESC',
							'meta_key' => 'when_last_login',
						'orderby'  => 'meta_value_num',
							'offset' => $paged ? ($paged * $number) : 0,
							'number' => $number
						
						);
						
		$blogusers = get_users( $args );
		
		foreach ($blogusers as $user) {
							
							$users = array($user->ID);


									$count = count_user_posts_by_type($user->ID, 'ssi_requests');
									
								
						
									$post_count = $count;
									
									if($post_count <= 0 ){ continue; }
									
									
									
									
									
							if ( $count < 500 ){
								if(1){
									
									?>
									<div class="col-md-3 text-center">
									

										<a href="/user-profile/?ID=<?php echo $user->ID; ?>">
									<?php 
									echo ++$author_count;
								//	echo '. Posts made by user: ' . $count;
									?>
									<br>
									<?php
									echo $user->display_name; ?>
									<br>
									<?php
										echo get_avatar($user->ID);
										
										 ?>
									<br>
									<?php
										//userphoto($user->ID, '', '', array(style => 'height: 96px; width:96px;') ) . "<br>";
										//echo "Member Since<br>" . mysql2date('M j, Y', $user->user_registered );
									$last_login = (int) get_user_meta( $user->ID, 'when_last_login' , true );
										if ( $last_login ) {
											$format = apply_filters( 'wpll_date_format', get_option( 'date_format' ) );
											$value  = date_i18n( $format, $last_login );
											echo "Last Logged In<br>" . $value;
										}else{
											echo "Last Logged In<br> Never";
										}
										
										?>
								
									<?php	
									$count++;
									
									?></a>
									</div>
									<div class="col-md-3">
									

								<br>Requests: <a target='_blank' href='/requests'>	
								<?php	echo " " . $requests_count = count_user_posts_by_type($user->ID, 'ssi_requests'); ?>
								</a>
								<br>G Photos: <a  target='_blank' href='/gallery'>
								<?php	echo "" . $photo_count = count_user_posts_by_type($user->ID, 'g_galleries'); ?>
								</a>
								<br>X Photos: <a  target='_blank' href='/photos'>
								<?php	echo "" . $photo_count = count_user_posts_by_type($user->ID, 'ssi_photos'); ?>
								</a>
								<br>Videos: <a  target='_blank' href='/videos'>
								<?php	echo "" . $video_count = count_user_posts_by_type($user->ID, 'ssi_videos'); ?>
								</a>
								<br>Events: <a  target='_blank' href='/events'>
								<?php	echo "" . $events_count = count_user_posts_by_type($user->ID, 'ssi_events'); ?>
								</a>
								<br>Blogs: <a  target='_blank' href='/blog'>
								<?php	echo "" . $blog_count = count_user_posts_by_type( $user->ID , 'post'); ?>
								</a>
								
									
								<?php	$total_count = $requests_count + $photo_count +  $video_count  + $events_count + $blog_count; 
									
									echo "<br><br>Total Posts: " . $total_count; ?>
								
									
									
									</a></div>
									<div class='clear'></div><hr>
									<?php
									
								}else if ( 1 /*validate_gravatar($user->user_email )*/ ){
									echo '<div id="user">' ;
										echo '<div class="link"> <a href="/user-profile/?ID=' . $user->ID . '">' . substr($user->display_name, 0, 10) . "</div>";
										echo get_avatar($user->ID, 96) . "</a><br>";
										//echo "Member Since<br>" . mysql2date('M j, Y', $user->user_registered );
										$last_login = (int) get_user_meta( $user->ID , 'when_last_login' , true );
										if ( $last_login ) {
											$format = apply_filters( 'wpll_date_format', get_option( 'date_format' ) );
											$value  = date_i18n( $format, $last_login );
											echo "Last Logged In<br>" . $value;
										}else{
											echo "Last Logged In<br> Never";
										}
									
									echo '</div><hr>';
									$count++;
								}else{}
								
							
									
							}else break;
						 
						}
		$userID = get_field( 'MX_user_id', $lead->ID );
		$users = array($userID);


		$counts = count_many_users_posts($users);
		//echo 'Posts made by user: ' . $counts[$userID];
		
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );
			
			//the_content();
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>

	</main><!-- .site-main -->



</div><!-- .content-area -->
<div class='clear'></div>	
<?php 

	echo "<hr>" . --$total_count . "<hr>";
?>
<?php get_footer('preview'); ?>
