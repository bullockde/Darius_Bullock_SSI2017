<div id='under-vid' > 

									<div class="clear"></div>
									
			<div class='pull-right' style='margin-right: 15px;'>
				<?php /*wpfp_link(); */ ?>	
			</div>
									
									
									<div class="cat btn cat-btn">Show Categories</div>
									<div class="tag btn tag-btn">Show Tags</div>
									<div class="fav btn"><a href='/favorites'>My Favorites</a></div>
										<div class="clear"></div>
										<div class="video-category hide">
						<br>&nbsp;&nbsp;&nbsp;
						Categories: <?php the_category(" ") ?>
											<button id="inline1" style='background: #ee0000;' title='Suggest a Category'> + </button>
											<div id="inline1" style='display: none;'>
												<?php echo do_shortcode('[gravityform id="3" name="Select Categories"]'); ?>
											</div>

										</div>

										<div class="video-tags hide">
<br>&nbsp;&nbsp;&nbsp;
						Tags: <?php the_tags('', " ") ?>
											
											<button id="inline2" style='background: #ee0000;'  title='Add Tags'> + </button>
											<div id="inline2" style='display: none;'> 
												<?php echo do_shortcode('[gravityform id="4" name="Add Tags"]'); ?>
											</div>
										</div>
										
										
										
		
</div>


	<div id='under-vid'> 
		<center>Posted by <?php the_author(); echo " | Added: "; the_time('F j, Y');  ?> <?php if ( get_post_meta($post->ID, 'duration', true) ) : ?> | Duration: <?php echo get_post_meta($post->ID, 'duration', true) ?> mins<?php endif; ?> | Updated: <?php echo get_the_modified_date( '', $post ); ?> by <?php echo get_post_meta( $post->ID, 'MX_modified_user', 1); ?>
		</center>

	</div>