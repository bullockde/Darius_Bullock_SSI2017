<div class='clear'></div>

<section id='events' class='services events'>
		
		<div class='container text-center'>
		<h2>Event Planning</h2><hr>
			<div class="col-md-offset-1 col-md-10">
				
				  <img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/11/Event-Planning-Splash.jpe'>  
				  <div class='col-md-6'>
				  		<a class='btn btn-block btn-lg btn-warning' href="/events/" target="_blank">> Upcoming Events! <</a>
	
				  </div>
				  <div class='col-md-6'>
						<a class='btn btn-block btn-lg btn-success' href="/events/" target="_blank">> Plan Your Event! <</a>
				  </div>
				

				
			
			</div>
		</div>
	
	</section>

<div class='clear'></div>