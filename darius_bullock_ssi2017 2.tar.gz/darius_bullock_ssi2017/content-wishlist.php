<section id='requests' class='bg-alt text-center'>

	<div class=''>
	
			
			<div class="page-header">
					<h2>Our Wish List</h2>
				</div>

<div class="clear"></div>
      
                <?php $args = array( 'post_type' => array( 'ssi_wishlist', 'ssi_fantasies' )  ,'post_status' => array( 'pending' , 'publish'),'numberposts' => -1 );

                $rand_posts = get_posts( $args );

                foreach( $rand_posts as $post ){ ?>
            
                <div class="post well" id="post-<?php the_ID(); ?>">

				<div class=' clear'></div>
					
				<div class=' clear'></div><br>
					<div class='col-md-3 col-xs-6'>
						
						<div class='circle'>
							<?php echo get_the_post_thumbnail( $post->ID , 'thumbnail' ); ?>
						</div>
						
						
						
					</div>
					<div class='col-md-6 col-xs-6'>
					
					
					
								
					<u>The WISH</u><br> 
                  <?php 
				  $my_postid = $post->ID;//This is page id or post id
					$content_post = get_post($my_postid);
					$content = $content_post->post_content;
					$content = apply_filters('the_content', $content);
					$content = str_replace(']]>', ']]&gt;', $content);
					
					
					
					echo $content; 
					
					
					if( get_post_meta($post->ID, 'wish_public', true ) == "YES" ){ 
					
						echo $content; 
						
					}else{ //echo "- PRIVATE -<br>" ; 
					
					}
					
					
				  ?> <br><div class='clear'></div><br>
					
				  
		
                    
					
					</div>
				<div class=' clear visible-xs'><br></div>
					<div class='col-md-3 col-xs-6'>
						<u>Date</u> <br><?php echo get_post_meta($post->ID, 'service_date', true) ?>
						<br>
							<u>Time</u> <br><?php echo get_post_meta($post->ID, 'service_time', true) ?>
							<br>
						<u>Length</u> <br><?php echo get_post_meta($post->ID, 'service_length', true) ?>
						
						
						
						<u>Budget</u> <br>$<?php echo get_post_meta($post->ID, 'service_max_budget', true) ?>
					</div>
					
                    
					
				<div class='clear'></div><br>
				
				<div class='clear'></div><br>
					
				  
				  
				 <strong><u>STATUS</u></strong><br> Pending!
                    
				
				
                </div>
				
				<?php } ?>
            
            <div class="clear"></div>
			<a target='_blank' href="/fantasy" class="btn btn-lg btn-info btn-block">Make A Wish >></a>
			<div class="clear"></div><br>
			
		</div>
</section>