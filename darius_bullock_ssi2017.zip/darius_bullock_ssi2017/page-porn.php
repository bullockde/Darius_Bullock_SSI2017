<?php get_header(); ?>
  <?php //include(''); 
  ?>
  
  
       <div class="container-fluid 1porn 1posts">
			

            <div class="row">
			
		 
            <?php 
			
			wp_reset_query();
			
			$number = 16;
			
			$paged = get_query_var('paged');
			
		
				$args = array(
					'post_type' => 'ssi_porn',
					'posts_per_page'   => $number,
					'offset'           => $paged * $number,
					'orderby'	=>	'modified'
				); 
			
			

			query_posts( $args );
			
			
			
			if(have_posts()) { ?>
                    
                    <?php while (have_posts()) : the_post(); ?>   
                    
					
		<div class="col-xs-6 col-md-3">
			<?php get_template_part( 'content', 'post' ); ?>
		</div>
                
                    <?php endwhile; ?>




					
					<?php //include('tumblr-wals.php'); 
					?>
					<div class="clear"></div>
					
					<br><br>
                    <div class="paginator">
                    
                        <?php if (function_exists("pagination")) {
								$num = $additional_loop->max_num_pages;
								
                                pagination( $num );
                            
                            } ?>

                    </div>
                    
                    <div class="clear"></div><br><br>
                    <?php //include('filters.php');
                     ?>
                <?php }
        
                else { ?>
        
                    <h2>Sorry, no posts matched your criteria</h2>
        
                <?php } ?>
        
            </div>
            
      </div> 
            


    
<?php get_footer(); ?>