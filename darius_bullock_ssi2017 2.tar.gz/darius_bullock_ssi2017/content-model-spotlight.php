<div class=' col-md-12 col-md-offset2-1 well'>
					<div class='col-sm-6 spot'>
				
						<h2>Model Spotlight</h2>
						
						
									<div class=' video'>
				
			
			<?php
					//the_post_thumbnail( get_the_ID() );
			
				$args = array( 'numberposts' => 1, 'post_type' => 'ssi_models'  , 'orderby' => 'rand' );
				$recent_posts = wp_get_recent_posts( $args );
				
				//print_r($recent_posts);
				
				foreach( $recent_posts as $recent ){
				
					//print_r($recent);
					?> 
					<a href='/book'> <div style='max-height: <?php echo $height; ?>;'>
					<?php
					echo get_the_post_thumbnail( $recent["ID"] , 'medium'  );
					
					?>
					<div class='clearfix'></div>
					<?php //echo $recent["post_content"];
					?> </div>
					</a>
					
					<?php
					
						echo '<a href="' . get_permalink($recent["ID"]) . '">' .   $recent["post_title"].'</a>';
						
					echo '<br><br>';	
		/*				

		if( get_user_meta($recent["ID"], 'MX_user_age' , 1) ){
					echo get_user_meta($recent["ID"], 'MX_user_age' , 1) . ' | ';
		}else{
					echo '- | ';
		}
		if( get_user_meta($recent["ID"], 'MX_user_height_ft' , 1) ){
					echo get_user_meta($recent["ID"], 'MX_user_height_ft' , 1) . "' " . get_user_meta($recent["ID"], 'MX_user_height_in' , 1) . '" | ' ;
		}else{
					echo '- | ' ;
		}
		if( get_user_meta($recent["ID"], 'MX_user_weight' , 1) ){
					echo get_user_meta($recent["ID"], 'MX_user_weight' , 1) . "<br><br>";
		}else{
					echo '- <br><br>';
					
					
		}
			*/			
				}
				wp_reset_query();
			?>
			</div>
			
			
<?php						
							
		
								if ( get_field('MX_user_city', "user_" . $recent["ID"] ) && get_field('MX_user_state', "user_" . $recent["ID"] ) ){

																		echo ' <span style="text-transform: capitalize;">' . get_field('MX_user_city', "user_" . $recent["ID"] ) . '</span>, ';
																		echo get_field('MX_user_state', "user_" . $recent["ID"] ) ;

								}
								else if ( get_field('MX_user_state', "user_" . $recent["ID"] ) ){
									echo  get_field('MX_user_state', "user_" . $recent["ID"] );
								}
								else{
									$closet = 1;
									echo '<b>Location</b><br>- Login ro View -';
									}
									
					/*				
									echo '<br>';
							if( get_user_meta($recent["ID"], 'MX_user_request_count' , 1) ){
											 echo get_user_meta($recent["ID"], 'MX_user_request_count' , 1) . '';
								}

								echo ' Requests ';
								
								*/
						?>


						<div class='clearfix'></div>


						<?php
/*
$last_login = (int) get_user_meta( $recent["ID"], 'when_last_login' , true );
											if ( $last_login ) {
												$format = apply_filters( 'wpll_date_format', get_option( 'date_format' ) );
												$value  = date_i18n( $format, $last_login );
												echo "Last Here <span style='float: right;'>" . $value . "</span>";
												echo "<br><br>Joined <span style='float: right;'>" . mysql2date('M j, Y', $user->user_registered ) . "</span>";
											}else{
												echo "<br>Joined <span style='float: right;'>" . mysql2date('M j, Y', $user->user_registered ) . "</span>";
											}
*/
						?>

						<div class='clearfix'></div>
						
						<a href='http://instaflixxx.com/user-profile/?ID=1078'><div class=' hidden button'>View Full Profile</div></a>
						<a href='http://instaflixxx.com/register/'><div class=' hidden button'>Become A Member</div></a>
					
					
				</div>
					<div class='col-sm-6 ad text-center'>
						<br><br>
						
						<h4>Advertisemnet</h4>
						<?php get_template_part( 'ad' , '300-250-1' ); ?>
						<br>
					
						<!--
<script type="text/javascript">
ad_idzone = "601057";
ad_width = "300";
ad_height = "250";
</script>
<script type="text/javascript" src="https://ads.exoclick.com/ads.js"></script>
<noscript><a href="http://main.exoclick.com/img-click.php?idzone=601057" target="_blank"><img src="https://syndication.exoclick.com/ads-iframe-display.php?idzone=601057&output=img&type=300x250" width="300" height="250"></a></noscript>

-->


						<!--<form name='state-filter' action='http://instaflixxx.com/people'>
							 
							<b>State:</b>
							
							<select name='state' >
								<option value="<?php echo $_GET['state']; ?>"> Choose a State </option>
								<option value="Alabama">Alabama</option><option value="Alaska">Alaska</option><option value="Arizona">Arizona</option><option value="Arkansas">Arkansas</option><option value="California">California</option><option value="Colorado">Colorado</option><option value="Connecticut">Connecticut</option><option value="DC">DC</option><option value="Delaware">Delaware</option><option value="Florida">Florida</option><option value="Georgia">Georgia</option><option value="Hawaii">Hawaii</option><option value="Idaho">Idaho</option><option value="Illinois">Illinois</option><option value="Indiana">Indiana</option><option value="Iowa">Iowa</option><option value="Kansas">Kansas</option><option value="Kentucky">Kentucky</option><option value="Louisiana">Louisiana</option><option value="Maine">Maine</option><option value="Maryland">Maryland</option><option value="Massachusetts">Massachusetts</option><option value="Michigan">Michigan</option><option value="Minnesota">Minnesota</option><option value="Mississippi">Mississippi</option><option value="Missouri">Missouri</option><option value="Montana">Montana</option><option value="Nebraska">Nebraska</option><option value="Nevada">Nevada</option><option value="New Hampshire">New Hampshire</option><option value="New Jersey">New Jersey</option><option value="New Mexico">New Mexico</option><option value="New York">New York</option><option value="North Carolina">North Carolina</option><option value="North Dakota">North Dakota</option><option value="Ohio">Ohio</option><option value="Oklahoma">Oklahoma</option><option value="Oregon">Oregon</option><option value="Pennsylvania">Pennsylvania</option><option value="Rhode Island">Rhode Island</option><option value="South Carolina">South Carolina</option><option value="South Dakota">South Dakota</option><option value="Tennessee">Tennessee</option><option value="Texas">Texas</option><option value="Utah">Utah</option><option value="Vermont">Vermont</option><option value="Virginia">Virginia</option><option value="Washington">Washington</option><option value="West Virginia">West Virginia</option><option value="Wisconsin">Wisconsin</option><option value="Wyoming">Wyoming</option>
							<select>
							<br><br>
							<b>Only Members w/</b> <input type='checkbox' name='photo' value='1'>Pics <input type='checkbox' name='no_social' value='1'>Social
							<br><br>
							<input type='text' name='user' placeholder=' Username Search' >
							<br><br>
							<input type='submit' value='Search'>
							
								
							
					</form>-->

					</div>
				
					<div class="clear"></div>
					
	</div>				