<center>
<!-- JuicyAds v3.0 -->
	<script async src="//adserver.juicyads.com/js/jads.js"></script>
	<ins id="640068" data-width="160" data-height="612"></ins>
	<script>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':640068});</script>
<!--JuicyAds END-->
</center>