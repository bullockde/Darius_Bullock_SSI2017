<?php
/**
*
*
 */

get_header('network'); ?>

<div id="primary" class="">

		
<div class=' '>


			
	<div class='col-md-8 col-md-offset-2 text-center'>

	
		
				<?php

			

				$requests = get_posts( 
				
					array(	
						'category_name' => 'invited',
						'posts_per_page'   => -1,  
						'post_status'                => 'publish',
						//'date_query' => array(  'before' => '1 month ago'  ) 
					) 
				);
			

			
						//print_r( $folks );
						// Start the loop.
						$count = 1;
						
						//$folks = (array)$query;
						foreach( $requests as $request ){
							
					
							if( get_field( "request_status", $request->ID  ) == 'Invited' ){

								echo $count++ . ". ";
								
								echo '<h1>' . $lead->post_title . '</h1>';
								
								echo "<hr>";
							}
						}
						
						?>
			
			
				<a href='/request/' class='btn btn-default btn-lg h1'>Request a Session >></a>
				

				<br><br>
		

	</div>
			
			<div class='clearfix'></div>

	<div class='col-md-10'>
			
			<?php //get_template_part( 'content', 'request-page' ); ?>
			<?php get_template_part( 'content', 'requests' ); ?>
			
			
	</div>
	
	<div class='col-md-2 text-center'>Ad
		
		<?php get_template_part( 'ad', '160-600' ); ?>
	</div>
		
				<div class='clearfix'></div>
</div>	
		
		

	
</div><!-- .content-area -->
<?php 
	get_footer(); 
?>