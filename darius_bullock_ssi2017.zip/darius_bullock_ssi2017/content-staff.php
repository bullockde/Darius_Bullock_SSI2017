


<div class="clear"></div><div class="clear"></div>

<!-- #SSINotes - Displays all Staff Members in a Grid -->

<div class="clear"></div><div class="clear"></div>


	
	
	
<?php
		echo "<br><hr>";
		
		
		$args = array( 'post_type' => 'ssi_' . $post->post_name  , 'posts_per_page' => -1 , 'order' => 'asc');
		$leads = get_posts( $args );
		
		foreach( $leads as $lead ){
			
			//echo ++$count . ". " . $lead->post_title;
			
			//if($is_admin ){ }else if( ($user->ID != $lead->post_author)  ){ continue; }
		
		//	echo "<br>";
			
			?>
			
			<div class="col-md-6 well yellow staff">
				<div class="col-sm-4">
				
				
				
				
					
						<center>
					
					<u>
					<?php 
							$Private = get_field( 'ssi_private', $lead->ID );
							
							if( $Private == "Yes" ){ echo "Private"; }else{ echo "Public";}
						?>
					</u>
					<br><br>
					</center>
					<center>
					
					<?php
						if(get_field('youtube_id', $lead->ID)){
					?>
								<img src='http://img.youtube.com/vi/<?php echo get_field('youtube_id'); ?>/default.jpg' alt='Youtube Image'  class='circle'>
							<?php
							
							
						}else if( get_field('MX_user_id' ,$lead->ID) ){ //the post does not have featured image, use a default image
							
							echo get_avatar( get_field('MX_user_id' ,$lead->ID) );
							
						
							
						}else if( has_post_thumbnail( $lead->ID ) ) { //the post does not have featured image, use a default image
							$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $lead->ID ), 'thumbnail' );

							?>
								<img src='<?php echo esc_attr( $thumbnail_src[0] ) ; ?>' alt='Youtube Image'  class='circle'>
							<?php
							echo '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
						}else{
							echo get_avatar();
						}

					?>
					
					
					
					
					
					
					
			<!--		
					
					
					<?php
					
						if( has_post_thumbnail( $lead->ID ) ) { //the post does not have featured image, use a default image
							$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $lead->ID ), 'thumbnail' );

							?>
								<img src='<?php echo esc_attr( $thumbnail_src[0] ) ; ?>' alt='avatar'  class='circle'>
							<?php
							echo '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
						}else{
							?>
							
							<img src='http://1.gravatar.com/avatar/1e5da67ce11e9f05b8c383735c54dbc9?s=32&d=mm&r=g&forcedefault=1' alt='avatar'  class='circle img-responsive' width='150' height='150'>
							
					<?php		
						}
					?>
					
					-->
					</center>
				</div>
				<div class="col-sm-8 text-center1">
					<center>
					<h4><?php  echo $lead->post_title; ?></h4> [ <?php echo get_field( 'MX_user_job_title', $lead->ID ); ?> ]<br>
					<br>
					</center>
					<strong>Hometown:</strong> <?php echo get_field( 'MX_user_hometown', $lead->ID ); ?><br>
<!--
					<strong>Email:</strong> <a href="mailto:shamanshawn@shamanshawn.com">shamanshawn@shamanshawn.com</a><br>
-->
					<strong>Favorite Food:</strong> <?php echo get_field( 'MX_user_favorite_food', $lead->ID ); ?><br>
				
					<div class='clear'></div><br>
					<a href='/user-profile/?ID=<?php echo get_field( 'MX_user_id', $lead->ID ); ?>'><button class='btn btn-default'>View Profile</button></a>
			
				</div>
					
			
			</div>
			
			



			<div class="col-md-8 well hidden staff stats">
				
				
		
			<a target='_blank' href='/<?php echo $post->post_name; ?>/<?php echo $lead->post_name; ?>'>
			
				<div class='col-xs-3 text-center'>
				
				
					<center>
					
					<u>
					<?php 
							$Private = get_field( 'ssi_private', $lead->ID );
							
							if( $Private == "Yes" ){ echo "Private"; }else{ echo "Public";}
						?>
					</u>
					<br><br>
					</center>
					<?php
						if(get_field('youtube_id', $lead->ID)){
					?>
								<img src='http://img.youtube.com/vi/<?php echo get_field('youtube_id'); ?>/default.jpg' alt='Youtube Image'  class='circle'>
							<?php
							
							
						}else if( get_field('MX_user_id' ,$lead->ID) ){ //the post does not have featured image, use a default image
							
							echo get_avatar( get_field('MX_user_id' ,$lead->ID) );
							
						
							
						}else if( has_post_thumbnail( $lead->ID ) ) { //the post does not have featured image, use a default image
							$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $lead->ID ), 'thumbnail' );

							?>
								<img src='<?php echo esc_attr( $thumbnail_src[0] ) ; ?>' alt='Youtube Image'  class='circle'>
							<?php
							echo '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
						}

					?>
					
				</div>
				<div class='col-xs-6 text-left'>
					
					<table border="1" style='margin: 0 auto; width: 100%;'>
<th colspan='3'>

<center><h3>Current Stats </h3></center>
<?php


$userID = get_field( 'MX_user_id', $lead->ID );
$users = array($userID);


//$counts = count_many_users_posts($users);
//echo 'Posts made by user: ' . $counts[$userID];
if( !get_field( 'MX_user_id', $lead->ID ) ){ echo "-- No USER ID --"; }




	
						
						
						//echo "HERE=--- " . count($leads);
						$user = get_user_by('id', $userID);
						
					//	print_r($user);
						
						$updates = 0 ; 
						foreach( $all_leads as $update ){ 
								
								
								
								if( get_post_meta( $update->ID, 'MX_modified_user', 1) == $user->display_name ){ $updates++; } 
						
						
						}
						//echo "<h3>Updates</h3>";
						
						//echo $updates . "<br>";
						
						?>
						
						

<?php


//echo 'Posts made by user: ' . $counts[2473];
?>
</th>
<tr>
<td>-</td>
<td>Post #</td>
<td>Amount Earned</td>
</tr>

<tr>
<td>New Posts</td>
<td><?php echo $counts[$userID]; ?></td>
<td>$<?php 

$post_count =  $counts[$userID];

$money = $post_count * 0.25;
$money = number_format((float)$money, 2, '.', '');
$post_money = $money;
echo $post_money; 


?>
</td>
</tr>

<tr>
<td>Updates</td>
<td>
<?php echo $updates; ?></td>
<td>$<?php 



$money = $updates * 0.05;
$money = number_format((float)$money, 2, '.', '');
$updates_money = $money;
echo $updates_money; 


?></td>
</tr>

<tr>
<td><h4>Total</h4></td>
<td><h4>

<?php 

echo ($post_count+ $updates);
?>


</h4></td>
<td><h4>

$<?php 


$money = ($post_money + $updates_money);
$money = number_format((float)$money, 2, '.', '');
$total_money = $money;
echo $total_money;


?>
</h4></td>
</tr>
</table> 
					
					
					
					
					
					
					
					
					
						<div class='col-sm-12  hidden'>
				<h4 class='visible-xs'>Budget Summary</h4>
				
				
				<div class=' well'>
			
				<div class='col-xs-6'>
					Income:
				</div>
				<div class='col-xs-6'>
					$
					<?php 
					
						echo $tot_income;
							?>
				</div>
					<div class='clear'><br></div>
				<div class='col-xs-6'>
					Expense: 
				</div>
				<div class='col-xs-6'>
					$
					<?php 
						echo $tot_expense;
						
							?>
				</div>
					<div class='clear'><br></div>
				<div class='col-xs-6'>
					Left Over:
				</div>
				<div class='col-xs-6'>
					$
					<?php 
							echo $client_profit;
							?>
				</div>
				
				<div class='clearfix'></div>
			</div>
			
			
				<div class='pull-right hidden'>
					<?php 
						
						$due = ((($weeks) * $rate)+($security + $rate + $app_fee));
						echo "Invested --->$" . $initial_investment;
					
					

						$tot_owed  += $due;

						echo "<br>Left Over--->$" . $client_profit;
						
						$percent = round((float)$return_rate * 100 ) . '%';
						echo "<br>Return rate --->$" . $percent;
						echo "<br>Return Amount --->$" . $return_amount;
						
						
						$owed = ($due - $client_profit);

					$banked = $loss = 0;
					

					if( $owed < 0 || get_field( "move-out_date", $lead->ID ) ){
						if( $owed < 0 ){ 
							$banked = (-$owed);
							//echo "<br>BANKED: $" . $banked;
						 }
						else{ 
							$loss = $owed; 
							//echo "<br>LOSS: $" . $loss;

							
						}
						if( get_field( 'security_applied', $lead->ID ) == "yes"  ){ 
								//echo "<br>SECURITY APPLIED!!";
								$final = ((-$loss) + $security);
								//echo "<br>FINAL: $" . $final;
							}

						$owed = 0; 
					}
					//	echo "<br><br>Owed: $" . $owed; 
				
						

						$tot_due += $owed;
					?>
				
				</div>
			</div>
					
					
					
					
					
					
					
					
					
					
				</div>
				<div class='col-xs-3 text-center'>
					<button class='pull-right1  btn btn-block'> >> </button>
					<br>
									
		<?php 
				
				$email = get_field('MX_user_email' ,$lead->ID);
						 $user = get_user_by_email($email);
				
				if( get_user_by_email($email) ){
					
					?>

			<a  target='_blank' href='/user-profile?ID=<?php 
				
				$email = get_field('MX_user_email' , $lead->ID);
						 $user = get_user_by_email($email);
				
				echo $user->ID; ?>' class='btn btn-default btn-block'>View Profile</a>
				<?php	
				}else if( get_field('MX_user_id' ,$lead->ID) ){
				?>

			<a  target='_blank' href='/user-profile/?ID=<?php echo get_field('MX_user_id' ,$lead->ID); ?>' class='btn btn-default btn-block'>View Profile</a>
				<?php
				}
				else{
					?>
			
			<a  target='_blank' href='/claim?claimID=<?php echo $lead->ID; ?>' class='btn btn-default btn-block'>Claim Profile</a>
				<?php
				}
				
				

				?>
				<a  target='_blank' href='/admin/' class='btn btn-default btn-block'>ADMIN Panel >></a>
				<a  target='_blank' href='/help' class='btn btn-default btn-block'>FAQ's >></a>
			<a  target='_blank' href='/post' class='btn btn-success btn-block'>New Post >></a>

				</div>
			</a>
			
			<div class="clear"></div><hr>
		</div>
			
			
			<?php
			
		}
			 
?>




	
		
		
		<div class="col-sm-6 staff well yellow">
				<div class="col-sm-4">
				
						<center>
					
					<u>
					<?php 
							$Private = get_field( 'ssi_private', $lead->ID );
							
							if( $Private == "Yes" ){ echo "Private"; }else{ echo "Public";}
						?>
					</u>
					<br><br>
				
				
					<img src='http://1.gravatar.com/avatar/1e5da67ce11e9f05b8c383735c54dbc9?s=32&d=mm&r=g&forcedefault=1' alt='avatar'  class='avatar '  width='96' height='96'>
					<?php //echo get_avatar(); ?>
					
					</center>
				</div>
				<div class="col-sm-8">
				
					<center>
					<h4>Your Name</h4> [ New Staff Member ]<br>
					<br>
					</center>
					<strong>Hometown:</strong> Your Hometown<br>
<!--
					<strong>Email:</strong> <a title="E-mail: staff@shamanshawn.com" href="mailto:staff@shamanshawn.com">staff@shamanshawn.com</a><br>
-->
					<strong>Favorite Food:</strong> Coming Soon..
					
					
					<div class='clear'></div><br>
					<a href='/apply/'><button class='btn btn-default'>Apply Now </button></a>
				</div>
					
		</div>
</div>
 
	

	 
	 
<div class="clear"></div><div class="clear"></div>

<!-- #ENDNotes - Displays all Staff Members in a Grid -->

<div class="clear"></div><div class="clear"></div>	 
	 
	 
	 
	 
	 