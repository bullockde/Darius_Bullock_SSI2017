<?php 
 if( is_user_logged_in() ){
	$user = $current_user = wp_get_current_user();
	$pg = '/edit-profile/?ID=' . $user->ID;
	//wp_redirect( $pg );
}

get_header('no-login'); ?>
    
    <div class='clearfix'></div><br>
    <div class="">

            <?php if(have_posts()) { ?>
   
                <?php while (have_posts()) : the_post(); ?>                    
                
                <div class="single-post well  text-center col-md-8 col-md-offset-2" id="post-<?php the_ID(); ?>">
			
					
                   <div id='1claim' style='display: block;'>  
                   
                   
                   	<h3>Are you <?php echo get_the_title($_GET['claimID']); ?>?</h3><br>
                   	
                    <div class='  mb-0 img-thumbnail ads ad-shift'>
					
					
					
						<?php
							if(get_the_post_thumbnail( $_GET['claimID'], 'medium' )){

							echo get_the_post_thumbnail( $_GET['claimID'], 'medium' ); 
							}else{ echo get_avatar($current_user->ID); }
							
						?>
						
						<!--<button id='claim'>Claim Ad >></button><br><br>-->
						
						
						
					
						
						
					</div><br><hr>
						<div id='1claim' style='display: block;'>
					
							<?php the_content(); ?>
							<br>
						</div>
					
					
					
				</div>
				
	

                </div>
                    
                <?php endwhile; ?>
                  <?php } ?>	  
                <div class='clearfix'></div>

        
    </div>
	<div class='clearfix'></div><br><hr>
				<div class='clearfix'></div>
					<div class='col-md-12'>
						
						
						
						
		
						<center> 
						
						
							<div class="img-thumbnail">
								<!-- JuicyAds v3.0 -->
								<script async src="//adserver.juicyads.com/js/jads.js"></script>
								<ins id="498543" data-width="300" data-height="262"></ins>
								<script>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':498543});</script>
								<!--JuicyAds END-->
							</div>
						</center>
		
					</div>
					
					<div class='clearfix'></div><br>
					 
    
<?php get_footer('preview'); ?>
