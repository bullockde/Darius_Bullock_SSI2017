<center>			
<!-- JuicyAds v3.0 -->
<script async src="//adserver.juicyads.com/js/jads.js"></script>
<ins id="640043" data-width="468" data-height="72"></ins>
<script>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':640043});</script>
<!--JuicyAds END-->
</center>