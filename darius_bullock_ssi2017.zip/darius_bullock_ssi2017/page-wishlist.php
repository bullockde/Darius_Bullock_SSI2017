<?php get_header('wishlist'); ?>
   

<div class='clearfix'></div>
		<div id='wish' class='bg-main'>

				<div class="container-fluid text-center">	
					<br class='hidden-xs'>
				<div class='well yellow col-md-7'>
					<h1>Simply Tell Us:</h1><hr>

						<h3>WHO</h3>
						Who you are.
						
						<br><br>

						<h3>WHAT </h3>
						What you need HELP with.
						
						<br><br>

						<h3>WHEN</h3>
						When you need it done.
						
						<br><br>
						<h3>WHERE</h3>
						Where the HELP is needed. 
						
						<br><br>
						
						<h3>HOW</h3>
						How do you Want it?
						<br>
						

	<br>
				<a target='_blank' href="/fantasy" class="btn btn-info btn-lg">Make Your Wish >></a>
				
				</div>	
				<div class=' col-md-5 text-center'>
						<div class='clear visible-xs'><br><hr></div>
						
					<?php	get_template_part( 'content', 'sidebar-ads' ); ?>
				</div>
			
			
					
					<div class='clearfix'></div><br>
				</div><!-- // container -->
			
</div><!-- // wish -->



	<div class="container text-center">
	<hr>
		<h2>Its that Simple...<br class='visible-xs'> We already Know <br class='visible-xs'>The WHY!!</h2>
	<hr>
	</div>
	


	



	<section id='testimonials' class='hidden'>
				
			
				<div class="container">

					




					<div class="container">
  <div class="row">
	<div class="page-header" id="feeback">
		<h2>Testimonials</h2>			
	</div>
	<div class='row'>
	<div class='col-md-2 text-center'>
	<a  target="_blank" href='https://tack.bz/2auIw'><img class='img-responsive' src='http://www.treatyourselfmassage.com/wp-content/uploads/2015/04/pressure-washing-reviews-thumbtack.png'></a>
	<a target="_blank" href='http://www.yelp.com/biz/treat-yourself-massage-philadelphia'><img class='img-responsive' src='http://www.treatyourselfmassage.com/wp-content/uploads/2015/04/yelp-review.png'></a>
	<a target="_blank" href='https://tack.bz/2b0GS'><img class='img-responsive' src='http://www.treatyourselfmassage.com/wp-content/uploads/2015/04/thumbtack-review.png'>
	</div></a>

 
    <div class='col-md-offset-0 col-md-10'>
      <div class="carousel slide" data-ride="carousel" id="quote-carousel">
        <!-- Bottom Carousel Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
          <li data-target="#quote-carousel" data-slide-to="1"></li>
          <li data-target="#quote-carousel" data-slide-to="2"></li>
        </ol>
        
        <!-- Carousel Slides / Quotes -->
        <div class="carousel-inner">
        
          <!-- Quote 1 -->
          <div class="item active">
            <blockquote>
              <div class="row">
                <div class="info col-sm-3 text-center">
                  <!--<img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/kolage/128.jpg" style="width: 100px;height:100px;">-->
		<span class='glyphicon glyphicon-ok'></span>
		<p>April 20, 2015</p>
		<p>Stuart A.</p>
                </div>
                <div class="col-sm-9">
			<p>Shawn gives an excellent massage. He uses very therapeutic gliding strokes that left me more relaxed than I’ve felt in some time. He worked all the muscle groups, leaving me standing straighter, as well as feeling taller. I carry a lot of tension in my body, and the massage relaxed me and lessened the tension in a major way. He also did a lot of good work on my lower back, which is my trouble area. I will definitely be back to see Shawn again in the near future.</p>
		
                </div>
              </div>
            </blockquote>
          </div>
          <!-- Quote 2 -->
          <div class="item">
            <blockquote>
              <div class="row">
                <div class="info col-sm-3 text-center">
                  <!-- <img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/mijustin/128.jpg" style="width: 100px;height:100px;">-->
		<span class='glyphicon glyphicon-ok'></span>
		<p>April 13, 2015</p>
		<p>Andrew R.</p>
		
                </div>
                <div class="col-sm-9">
                  <p>Had a terrific massage from Shawn a few weeks ago. It had been a really intense week and I must say it was what I needed. It was professional, therapeutic and very relaxing - to the point where I fell in and out of sleep and relaxation. Shawn is professional, talented and to his credit very knowledgeable with regard to the human body, the negative impact of stress and how to balance and manage that with exclusive massage techniques. Truly has healing hands. I recommend him to all interested in experiencing one of the best massages ever!</p>
		
                </div>
              </div>
            </blockquote>
          </div>
          <!-- Quote 3 -->
          <div class="item">
            <blockquote>
              <div class="row">
                <div class="info col-sm-3 text-center">
                  <!--<img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/keizgoesboom/128.jpg" style="width: 100px;height:100px;">-->
		<span class='glyphicon glyphicon-ok'></span>
		<p>John</p>
                </div>
                <div class="col-sm-9">
                  <p>At first I was very apprehensive about meeting Shawn. This was my very first massage and I was not sure what to expect. After meting him and having such a positive experience, I can assure you it will not be my last. Shawn was very professional from the beginning. The setting was perfect for a relaxing experience. I think Shawn knew I was nervous and he initiated conversation to make me feel at ease. I was pleased with the massage and at times I felt like I was drifting off. I have not been this relaxed in ages. I will definitely use Shawn again and I highly recommend that you do to.</p>
		
                </div>
              </div>
            </blockquote>
          </div>
        </div>
        
        <!-- Carousel Buttons Next/Prev -->
        <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
        <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
      </div>                          
    </div>
  </div>
</div>



			<!--		<div class="row">
					<div class="col-md-10">
						<blockquote>
							<p>I had a massage from Shawn a few weeks back ,when I decide to go to his place I was very nervous but once I met him face to face I felt like I knew him for years .Shawn’s massage technics were very professional and relaxing I have had a bad back for years and have a stressful job (like most people do ) when Shawn started to touch me my stress seemed to exit my body. Shawn a very professional guy as well as warm and engaging .I can’t wait to see him again I know the next time will be even better!!</p>
							<footer>Walter F.</footer>
						</blockquote>
					</div>
					<div class="col-md-10 col-md-offset-2">
						<blockquote class="blockquote-reverse">
							<p>Shawn is one professional therapist. I really enjoyed my time from start to end. Shawn ensured that I was relaxed and happy. He passionately worked the aching pains out of my muscles. I recommend that everyone use Shawn’s services. Just to reiterate, Shawn is extremely professional.</p>
							<footer>Tyson Carter</footer>
						</blockquote>
					</div>
					<div class="col-md-10">
						<blockquote>
							<p>At first I was very apprehensive about meeting Shawn. This was my very first massage and I was not sure what to expect. After meting him and having such a positive experience, I can assure you it will not be my last. Shawn was very professional from the beginning. The setting was perfect for a relaxing experience. I think Shawn knew I was nervous and he initiated conversation to make me feel at ease. I was pleased with the massage and at times I felt like I was drifting off. I have not been this relaxed in ages. I will definitely use Shawn again and I highly recommend that you do to.</p>
							<footer>John</footer>
						</blockquote>
					</div>
				</div>

			--><!--  // END OLD TESTIMONIALS -->



				
				
				
				<div class='text-center'>
					<a href="/leave-a-testimonial" class="btn btn-danger ">Leave A Testimonial</a>	
				</div>
					
					
				</div><!-- // container -->
			
		</section><!-- // testimonials -->

		
		
		<?php // get_template_part('content', 'wishlist'); ?>
	
	
    
     <?php get_template_part('content', 'wishlist'); ?>
	 
	 
	 
	 
<?php  

	$args = array(
   // 'author'        =>  $_GET['ID'],
   'post_type' => 'ssi_fantasies',
   'post_status' => array('pending', 'publish'),
   // 'category_name' => 'fantasy',
	'orderby'       =>  'modified',
    'order'         =>  'ASC',
    'posts_per_page' => -1
    );
	$Galleries = get_posts($args);
				?>
		<div class='profile-social text-center'>
			<?php //echo count($requests); ?>
			<h3><u><?php echo count($Galleries); ?></u> Fantasies</h3><hr>
		</div>

		<?php
	foreach($Galleries as $Gallery){ 
	
		//if( get_field( 'post_type', $Gallery->ID ) == 'ssi_photos' ){ }else{ continue; }
		
		//print_r($Gallery);
	?>
		 <a  target='_blank' href='/?p=<?php echo $Gallery->ID; ?>'>
							<div class=''>
						<div class='col-xs-2'>	
						<?php
								echo "";
								echo get_the_post_thumbnail( $Gallery->ID , array(50,50) );
								echo "";
								?>
						</div>
						<div class='col-xs-8'>
						
					
							
						<?php		
								echo $Gallery->post_title;
								
							?> - 
							(<?php echo get_field( '#_of_photos', $Gallery->ID ); ?> Photos)
							<br><u><?php if(get_field( 'member_level', $Gallery->ID )){ echo get_field( 'member_level', $Gallery->ID ); }else{  echo "Public"; } ?></u>
						
						</div> 
							
							
							<button type="button" class="btn btn-default btn-sm pull-right">
							  View <span class="glyphicon glyphicon-play"></span> 
							</button>

							
									<div class='clearfix'></div><hr>
						</div>
								</a>
<?php	}
	


$count++;  ?>

	<div class='clearfix'></div>
	<a target='_blank' href='/fantasy' class='btn btn-info btn-block btn-lg'>> Post a Fantasy <</a>
	
	<div class='clearfix'></div><hr>
	 
	 
<?php get_footer('members'); ?>
<?php 
	
		if( $_GET['status'] == 'sent' ){ $message = "We Got Your Wish! .. We Emailed You A Copy as Well.. ;-) ";
			echo "<script type='text/javascript'>alert('$message');</script>"; }

	?>