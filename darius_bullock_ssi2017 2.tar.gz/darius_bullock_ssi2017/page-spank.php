<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 $funnel = "/spanking/";
					wp_redirect($funnel);

get_header(); ?>
<div class='clear'></div><hr>
<div id="" class="col-md-8">

		<header class="entry-header text-center">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</header><!-- .entry-header -->
		<center>
		<?php twentysixteen_post_thumbnail(); ?>
		</center>
	
	
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			?>
			
			
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				
				<div class="entry-content">
					<?php
					the_content();

					wp_link_pages( array(
						'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
						'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
						'separator'   => '<span class="screen-reader-text">, </span>',
					) );
					?>
				</div><!-- .entry-content -->

				<?php
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>
</div>
<div id="" class="col-md-4">
	
	<?php get_sidebar(); ?>
</div>

<?php get_sidebar( 'content-bottom' ); ?>
<div class='clear'></div><hr>
<?php get_footer(); ?>
