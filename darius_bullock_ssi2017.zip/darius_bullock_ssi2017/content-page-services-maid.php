<div class='clear'></div>

<section id='maid' class='maid'>
		
		<div class='container'>
		<h2>Maid & Cleaning Services</h2><hr>
			<div class="col-md-6">


				<a href="http://hegotitmaid.com/" target="_blank">He Got It Maid</a>
				
				<a href="http://hegotitmaid.com/" target="_blank">
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/11/cropped-hegotitmade.jpg'>  </a>

				
			</div>
			<div class="col-md-6">

				<a href="http://shegotitmaid.com/" target="_blank">She Got It Maid</a>

				<a href="http://shegotitmaid.com/" target="_blank">
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/11/cropped-shegotitmade.jpg'>  </a>

			</div>
		</div>
	
	</section>

<div class='clear'></div>