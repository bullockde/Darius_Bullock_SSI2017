<div class="clear"></div>

<section class='social'>
		
	
		
		<div class=' text-center'>
			<h2>#SSISocial</h2><hr>
		</div>
			
			
	<div id='social' style=' display: block;'>


			<div class="col-sm-4 hidden-xs1 text-center">
			<?php if ( 1 /*!wp_is_mobile()*/ ) { ?>

				<small>Click Below to Connect:</small><hr>

				<div class="col-xs-3 pad0"><a target='_blank' href='https://www.facebook.com/ShamanShawnInc/'><img src='/wp-content/uploads/2015/09/icon-facebook.png' class='img-responsive aligncenter'></a></div>
				<div class="col-xs-3 pad0"><a target='_blank' href='https://twitter.com/shamanshawninc'><img src='/wp-content/uploads/2015/09/icon-twitter.png' class='img-responsive aligncenter'></a></div>
				<div class="col-xs-3 pad0"><a target='_blank' href='https://www.youtube.com/channel/UChPquIqMjch7rEcoSnmN_AA'><img src='/wp-content/uploads/2015/09/icon-youtube.png' class='img-responsive aligncenter'></a></div>
				<div class="col-xs-3 pad0"><a target='_blank' href='https://www.linkedin.com/pub/shaman-shawn/53/296/58b'><img src='/wp-content/uploads/2015/09/icon-linked-in.png' class='img-responsive aligncenter'></a></div>
				
				

			<div class='clear'><hr></div>
				<div class="fb-page" data-href="https://www.facebook.com/ShamanShawnInc" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/ShamanShawnInc"><a href="https://www.facebook.com/ShamanShawnInc">Shaman Shawn Inc.</a></blockquote></div></div>
			<?php } ?>
			
			</div>
			<div class="col-sm-4 text-center">
				<div class="col-lg-12">
				
				<center>
				
				<div class='clearfix'></div><br>
		
				<?php dynamic_sidebar( 'content-bottom-2' ); ?>
			
				 <small>EVERYBODY get "GIG" - ity!</small><hr>
		
			
				<!-- Put this code anywhere in the body of your page where you want the badge to show up. -->

			<div itemscope itemtype='http://schema.org/Person' class='fiverr-seller-widget' style='display: inline-block;'>
				 <a itemprop='url' href=https://www.fiverr.com/shamanshawn rel="nofollow" target="_blank" style='display: inline-block;'>
					<div class='fiverr-seller-content' id='fiverr-seller-widget-content-a92c9887-946f-459a-9ac6-105f6adfdee7' itemprop='contentURL' style='display: none;'></div>
					<div id='fiverr-widget-seller-data' style='display: none;'>
						<div itemprop='name' >shamanshawn</div>
						<div itemscope itemtype='http://schema.org/Organization'><span itemprop='name'>Fiverr</span></div>
						<div itemprop='jobtitle'>Seller</div>
						<div itemprop='description'></div>
					</div>
				</a>
			</div>

			<script id='fiverr-seller-widget-script-a92c9887-946f-459a-9ac6-105f6adfdee7' src='https://widgets.fiverr.com/api/v1/seller/shamanshawn?widget_id=a92c9887-946f-459a-9ac6-105f6adfdee7' data-config='{"category_name":"Programming \u0026 Tech"}' async='true' defer='true'></script>

							
				

			</div>
				<div class='hidden col-sm-4'>
					<a href='/register/' class='btn btn-lg btn-info btn-block'>SignUp</a><br>
				</div>
				<div class='hidden col-sm-4'>

					<?php if(is_user_logged_in()){ ?>

						<a href='/wp-login.php?action=logout&_wpnonce=b48f0b370d&redirect_to=http%3A%2F%2Fshamanshawn.com%2Fwp-admin%2Ftheme-editor.php%3Ffile%3Dcontent-social.php%26loggedout%3Dtrue%23038%3Btheme%3Dtwentyfourteen%26%23038%3Bscrollto%3D954%26%23038%3Bupdated%3Dtrue' class='btn btn-lg btn-info btn-block'>Logout</a><br>
					
					<?php }else{ ?>
						<a href='/wp-admin/' class='btn btn-lg btn-info btn-block'>Login</a><br>
					
					<?php } ?>
				</div>
				<div class='hidden col-sm-4'>
					<a href='/' class='btn btn-lg btn-info btn-block'>Home</a><br>
				</div>

			</div>

			<div class='col-sm-4 pad0 left10'>

		
		<center>
		<small> Advertisement </small><hr>
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- SSI2018_300_600_sky -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-9799103274848934"
     data-ad-slot="9445055504"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
		</center>
		

		</div>

	<!--  	<div class="col-lg-4 hidden-xs1 text-center">

				<h3>YouTube Videos</h3>
			<?php 

				echo do_shortcode('[youtube video=ZjMvqfAOVyQ]');

				echo do_shortcode('[youtube video=nn4oJ_rDE-s]');

			
				echo "<a href='https://www.youtube.com/channel/UChPquIqMjch7rEcoSnmN_AA' class='btn btn-small btn-info' target='_blank'>View My Channel </a> ";


				if ( !wp_is_mobile() ) { ?>
				<!--  #<a class="twitter-timeline" href="https://twitter.com/ShamanShawnInc" data-widget-id="643739182595227648">Tweets by @ShamanShawnInc</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>  
			<?php } ?>
			
		</div>-->
<div class='clearfix'></div>

		</div><!-- #social -->
	
				

	<div class='clearfix'></div>
	</section>
	<section class='tag-line text-center'  class='pad0 left50'>
		<h2> InstaGram Feed </h2>
			<?php echo do_shortcode('[instagram-feed]'); ?>
		<br>
	</section>

<div class="clear"></div>