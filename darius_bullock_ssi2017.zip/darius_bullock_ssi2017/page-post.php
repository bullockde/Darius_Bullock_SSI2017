<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 

get_header('members'); ?>
<div class="clearfix"></div>page-post

<div id="primary1" class="container-fluid">
<div class='clear'></div>
	<div id="main1" class="col-md-8 well green" role="main1">
	    
	    						<div class='clear'></div>
	    						
	    						
	<a href="/post-photos" class="btn-block btn btn-success btn-lg pulse hidden1 mb-10"><br><h3>Add Photos &raquo;</h3><br></a>
	<a href="/post-video" class="btn-block btn btn-success btn-lg pulse hidden1 mb-10"><br><h3>Add Videos &raquo;</h3><br></a>
	
	<div class='clearfix'></div>
	
	
	<div id='add-gallery' style='display: none;' class='text-center <?php if ( /*!is_user_logged_in()*/ 0  ) { echo "hidden"; } ?>'>
			
			<button id='add-gallery' class='hidden-print btn btn-success btn-lg btn-block hidden1 pulse'><br><h3>> Add Photos <</h3><br></button>
			
		</div>
	
		<div class='clear'></div>	

		<div id='add-gallery' style='display: none;'  class='well green'>
				
			<div class="col-md-10 col-md-offset-1  home-beta">
			 <div class='clearfix mb-10'></div>
			    <center><h3> Upload Photos! </h3></center>
			 <div class='clearfix mb-15'></div>
			</div>
			<div class="col-md-10 col-md-offset-1 text-left">
			<div class="well">
			
			<?php //echo do_shortcode('[gravityform id="11" title="false" description="false"]');
			
			echo do_shortcode('[gravityform id="36" title="false" description="false"]');
			
			?></div>
			<div class='clear'></div>	
			<button id='add-gallery' class='hidden-print btn btn-default btn-sm'>x close</button>
			<div class='clearfix'></div>	<br>	
			</div>
			
			<div class='clear'></div>
		</div>
	<div class='clearfix mb-10'></div>
	
	
	
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>

	</div><!-- .site-main -->
	<?php if( !wp_is_mobile() ){  ?>
	<div class="col-md-4">
	
		<div class="img-thumbnail">
			<?php get_template_part( 'ad', '300-250-2' ); ?>
			<?php //get_template_part( 'ad-exo', '300-250-2' ); ?>
			<?php //get_sidebar( 'content-bottom' ); ?>
		</div>
	</div>

	<?php } ?>
</div><!-- .content-area -->




<div class='clearfix'></div>

<?php get_footer('preview'); ?>
