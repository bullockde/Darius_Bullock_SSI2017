<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<div class='clearfix mb-15'></div>
    
        <div class="container text-center hidden1">
    	
                <h1 class="page-title">Damnnnn SON... You Broke It!!</h1>
		<img src='http://instaflixxx.com/wp-content/uploads/2015/08/10-17-30-988_640.jpg'>
        	<br>
        
		<a href='/' class='btn btn-default'>Return Home</a>
        </div>
		
<div class='clearfix'></div>

	<div class='col-md-12 text-center'>	
	
		<?php //get_template_part('content','dashmaster-5000'); 
		
				//get_template_part('content','footer-nav'); 

		?>
	
		<hr>Our Partners<hr>
		<?php //get_template_part('content','projects-grid'); 
		 ?>
	</div>
			
			
<div class='clearfix'></div>
           
<?php get_footer(); ?>
