<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 

get_header(); ?>

<h4>List of Agents</h4>
 <table>
   <tr>
       <th>Author Data</th>
     <th>Agent ID</th>
     <th>Email</th>
     <th>Action</th>
 </tr>
 <?php
 
 $number = 3; //max display per page
 $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; //current number of page
 $offset = ($paged - 1) * $number; //page offset
 $users = get_users(array('role' => '')); //get all the lists of users 
 $args = array(
     'offset' => $offset,
     'number' => $number,
     'role' => '',
     'fields' => array( 'ID', 'user_login', 'user_email' )
 );
 $query = get_users($args);//query the maximum users that we will be displaying
 $total_users = count($users);//count total users
 $total_query = count($query);//count the maximum displayed users 
 $total_pages = ($total_users / $number); // get the total pages by dividing the total users to the maximum numbers of user to be displayed //Check if the total pages has a decimal we will add + 1 page
 $total_pages = is_float($total_pages) ? intval($total_users / $number) + 1 : intval($total_users / $number);
 
 if(is_array($query )){ 
     foreach($query as $agent_data) {
        echo '<tr>';
        
        
         $author_info = get_userdata($agent_data->ID); ?>
        <td>
            <span style="float:left;padding:0 5px 0 0;"><?php echo get_avatar( $author->ID, 50 ); /* http://codex.wordpress.org/Function_Reference/get_avatar */ ?></span>
        <span class="fn"><strong>First name</strong> : <?php echo $author_info->first_name; ?></span><br />
        <span class="ln"><strong>Last name</strong> : <?php echo $author_info->last_name; ?></span><br />
        <span class="em"><strong>Email address</strong> : <a href="mailto:<?php echo $author_info->user_email; ?>"><?php echo $author_info->user_email; ?></a></span><br />
        <span class="we"><strong>Website</strong> : <a href="<?php echo $author_info->user_url; ?>"><?php echo $author_info->user_url; ?></a></span><br />

        <span class="de"><strong>Bio</strong> :<br /><?php echo $author_info->description ; ?></span>
        <div class="clear">&nbsp;</div>
        </td>
        

       <?php 
        
        
        echo '<td>'.$agent_data->user_login.'</td>';
        echo '<td>'.$agent_data->user_email.'</td>';
        echo '<td><a href="/wp-admin/user-edit.php?user_id='.$agent_data->ID.'">Edit</a></td>';
        echo '</tr>'; 
     } 
 }
 ?>
 </table>
 
 <?php
 if ($total_users > $total_query) {
    echo '<div id="support-pagination" class="clearfix">';
    $current_page = max(1, get_query_var('paged'));
    echo paginate_links(array(
       'base' => get_pagenum_link(1) . '%_%',
       'format' => 'page/%#%/',
       'current' => $current_page,
       'total' => $total_pages,
       'prev_next' => false,
       'type' => 'list',
    ));
 }
 echo '</div>';
 ?> 
 </div> 
<div class='clearfix'></div>

<?php get_footer('preview'); ?>
