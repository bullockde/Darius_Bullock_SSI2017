<?php get_header(); ?>
   <section id='men' class='text-center'>
		<h3>When it comes to Booking <span class='hidden-xs'>.. </span>We have Options!!</h3>
   </section>
   	<section id='men' class='text-center'>
			<div class='col-sm-4 split'>
				<h3>SHORT -<span class='x'>X</span>- SCAPE</h3>
				<h4>Simple Service Booking</h4>
				
				<small><button id='learn1'>Learn More</button></small><br>
				
				<div id='learn1' style='display: none;'>
					<br>Use this to Book a Basic <br>MASSAGE or MANSKAPING <br>and Sessions Under 3 Hrs.
				</div>
				
				<br>
					<a target='_blank' href="https://xscape.appointy.com/" class="btn btn-lg btn-danger ">Book A Session >></a>
					
			</div>
			<div class='clear visible-xs '><hr></div>
			<div class='col-sm-4 split'>

				<h3>CUSTOM -<span class='x'>X</span>- SCAPE</h3>
				<h4>Customize Your Experience</h4>
				
				<small><button id='learn2'>Learn More</button></small><br>
				
				<div id='learn2' style='display: none;'>
					<br>Use this to Book <br>EXTENDED SESSIONS<br>Any/All services
				</div>
				
				<br>
					<a target='_blank' href="/request" class="btn btn-lg btn-danger">Plan a Great X-Scape >></a>
					
			</div>
			<div class='clear visible-xs '><hr></div>
			<div class='col-sm-4 '>
				
				<h3><?php //bloginfo( 'name' ); ?>BUDGET -<span class='x'>X</span>- SCAPE</h3>
				<h4>Budget Friendly Booking</h4>
				
				<small><button id='learn3'>Learn More</button></small><br>
				
				<div id='learn3' style='display: none;'>
					<br>Use this to Submit A<br>BUDGET Service REQUEST<br>Any Budget - Any Time
				</div>
				
				<br>
					<a target='_blank' href="/request" class="btn btn-lg btn-danger">Request A Session >></a>
					
			</div>

			
			<div class='clear'></div>
	</section>
	
	<div class='clear'></div>
	
    <div class="main">
    
        <div class="container">

            <div class="">
                
            <?php if(have_posts()) { ?>
   
                <?php while (have_posts()) : the_post(); ?>                    
                
                <div class="single-post hidden" id="post-<?php the_ID(); ?>">
					<br>
                      <h2 class="post-title hidden"><?php wp_title(""); ?></h2>   <hr>
                    <?php the_content(); ?> 

                </div>
                    
                <?php endwhile; ?>
                    
                <div class="clear"></div>
      <!--
                <?php $args = array( 'numberposts' => 6, 'orderby' => 'rand' );

                $rand_posts = get_posts( $args );

                foreach( $rand_posts as $post ) : ?>
            
                <div class="post" id="post-<?php the_ID(); ?>">
                    
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail(array(240,180), array('alt' => get_the_title(), 'title' => '')); ?></a>
                    
                    <?php if ( get_post_meta($post->ID, 'duration', true) ) : ?><div class="duration"><?php echo get_post_meta($post->ID, 'duration', true) ?></div><?php endif; ?>
                        
                    <div class="link"><a href="<?php the_permalink() ?>"><?php short_title('...', '34'); ?></a></div>
                    
                    <span>Added: <?php the_time('F j, Y'); ?> at <?php the_time('g:i a'); ?></span>
                        
                    <span><?php the_tags('Tags: ', ', ', ''); ?></span>
                    
                </div>

            <?php endforeach; ?>
            
            <div class="clear"></div>
                    
                <?php }
        
                else { ?>
        
                    <h2>Sorry, no posts matched your criteria</h2>
        
                <?php } ?>
       --> 
            </div>
            <div>
				<?php //get_sidebar('right'); ?>
			</div>
       
        
        
		
        </div>
        <div class="clear"></div>
        
    </div>
    
<?php get_footer(); ?>
