<div class='clear'></div>
<div class='banner'></div>
<div class='leader' >
	
	<div class='col-md-2'>
	
		<img class='img-responsive hidden-xs ' src='http://shamanshawn.com/wp-content/uploads/SSI-Logo-Banner-New-QR.png'>
	
	</div>
	<div class='col-md-8 ' >
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- SSI2018_Responsive -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9799103274848934"
     data-ad-slot="3085916311"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	<div class='col-md-2 hidden-xs hidden-sm '>
	
		<img class='img-responsive ' src='http://shamanshawn.com/wp-content/uploads/SSI-Logo-Banner-New-QR.png'>
	
	</div>
	
	<div class='clear'></div>
</div>
</div><div class='clear' ></div>
<div class='tagline text-center'>
	"Bridging the Gap between the HAVE's and the HAVE NOT's." -#SSI
</div>
	

<div class='clear'></div>