<center>
<script type="text/javascript">
var ad_idzone = "2993244",
	 ad_width = "250",
	 ad_height = "250";
</script>
<script type="text/javascript" src="https://ads.exosrv.com/ads.js"></script>
<noscript><a href="https://main.exosrv.com/img-click.php?idzone=2993244" target="_blank"><img src="https://syndication.exosrv.com/ads-iframe-display.php?idzone=2993244&output=img&type=250x250" width="250" height="250"></a></noscript>
</center>