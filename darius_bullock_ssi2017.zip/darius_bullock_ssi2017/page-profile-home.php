<?php

get_header('yungdaddy'); ?> 

	<div class="clear"></div>

	

	<?php if( !is_paged() ){ get_template_part( 'content', 'welcome' ); } ?>
	
	
	<?php //if( !is_paged() ){ get_template_part( 'content', 'recent-wall' ); }
	 ?>
<div id="" class="">



	 <div class='clear'></div><hr>
	 
	 
	 <?php //get_template_part( 'content', 'members' );
	  ?>
	 
	
		<div class='clear'></div>



</div>

<?php get_footer(); ?>