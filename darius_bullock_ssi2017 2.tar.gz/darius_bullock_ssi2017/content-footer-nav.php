<div class='clear'></div>	
	
	<div class="stats">
	
	
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Home ></h4></figcaption>
			</figure>
			</a>
		</div>	
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/blog'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Blogs ></h4></figcaption>
			</figure>
			</a>
		</div>
		<div class="col-md-2 col-xs-6 text-center well hidden">
			<a  href='/models'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Series ></h4></figcaption>
			</figure>
			</a>
		</div>	
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/walls'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Walls ></h4></figcaption>
			</figure>
			</a>
		</div>
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/wishlist'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Fantasies ></h4></figcaption>
			</figure>
			</a>
		</div>	
		
		<div class="col-md-2 col-xs-6 text-center well">
									
			<a  href='/requests'>
			<figure>
			 
			
			
			  <img src="/wp-content/uploads/2016/11/man-x-scape-shawn-e1478869098864.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Requests ></h4></figcaption>
			</figure>
			</a>						
		</div>
		
		
		<div class=" col-md-2 col-xs-6 text-center well">
			<a  href='/photos'>						
			<figure>
				 <img src="/wp-content/uploads/2016/11/14642200_853702041432368_4968411123150703434_n-e1478868844240.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			 
			  <figcaption><h4>Photos ></h4></figcaption>
			</figure>
			</a>						
		</div>
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/video-gallery'>						
			<figure>
				 <img src="/wp-content/uploads/2016/11/14642200_853702041432368_4968411123150703434_n-e1478868844240.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			 
			  <figcaption> <h4>Videos ></h4></figcaption>
			</figure>
			</a>						
		</div>
		<div class="col-md-2 col-xs-6 text-center well">
									
			<a  href='/events'>
			<figure>

			  <img src="/wp-content/uploads/2016/11/man-x-scape-shawn-e1478869098864.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Events ></h4></figcaption>
			</figure>
			</a>						
		</div>
		

		
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/models'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Models ></h4></figcaption>
			</figure>
			</a>
		</div>	
		
		<div class="col-md-2 col-xs-6 text-center well hidden">
			<a  href='/thots'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption><h4>THOTs ></h4></figcaption>
			</figure>
			</a>
		</div>
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/pros'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption><h4>PROs ></h4></figcaption>
			</figure>
			</a>
		</div>	
			
		
		<div class="col-md-2 col-xs-6 text-center well">
			<a  href='/projects'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption> <h4>Projects ></h4></figcaption>
			</figure>
			</a>
		</div>	
		
		<div class="col-md-2 col-xs-6 text-center well">
									
			<a  href='/people'>
			<figure>
			  <img src="/wp-content/uploads/2016/11/deep350_350-e1478869245737.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption><h4>Members ></h4></figcaption>
			</figure>
			</a>
		</div>
					
								
								
	</div><!-- // stats -->
	
<div class='clear'></div>