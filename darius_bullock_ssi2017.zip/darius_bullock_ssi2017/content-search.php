<div class='clear'></div>
	<section class='search text-center'>
	
		<div class='container'>
			
		
		<div class="col-sm-3">
				
			<b>#SSIFilter: </b>
		</div>
		<br class='visible-xs'>
		<div class="col-sm-3">
				
			<?php the_widget( 'WP_Widget_Search' ); ?> 
		</div>
		<div class="col-sm-3">
				
			<?php the_widget( 'WP_Widget_Categories', 'dropdown=1&count=1' ); ?>  

			
		</div>
		<div class="col-sm-3">
				
			<?php the_widget( 'WP_Widget_Archives', 'dropdown=1&title=0' ); ?> 
			
		</div>
		</div>
	</section>
	<div class='clear'></div>
