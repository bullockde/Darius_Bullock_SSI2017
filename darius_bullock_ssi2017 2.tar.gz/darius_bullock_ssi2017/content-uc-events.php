<?php 

	$cats = array( get_cat_ID('current-event') /*, get_cat_ID('playroom') */);

	$events = get_posts(array( 'post_type' => 'ssi_events', 'category' =>  $cats, 'posts_per_page' => 5 , 'order' => 'desc'));
	
	$event = $events[0];
?>

 <div class='clear'></div>
 
 
 
 
 
 
 
 
 
 
 
 
 
		<?php if(  ( count($events) > 0 ) && ( !is_paged() )  /*&& ( strtotime(get_field('event_date', $event->ID)) >= strtotime( 'now' )  )*/) { ?>
		
		<div class='well container green mb-0 text-center'>
		
		
				<h3> Upcoming Events </h3><hr>
		
		<div id="" class="col-md-6 1col-md-offset-3 hidden1 mb-0">
			
			<?php echo get_field( 'event_countdown', $event->ID );  
		?>
			
		</div>
		
		<div id="" class="col-md-6 1col-md-offset-3 hidden1">
			<div class="well yellow stats text-center mb-5 hidden1">
				<h2 class="mb-15"><?php echo $event->post_title; ?></h2>
				<!--<h2>North PHILLY Playroom</h2>-->
				<?php date_default_timezone_set("America/New_York"); 

					echo date("M jS, Y", strtotime(get_field('event_date', $event->ID)));
					?>
				
				<br><a href="/?p=<?php echo $event->ID; ?>" class="h4">[ <?php echo get_field( 'event_time', $event->ID ); ?> ]</a>
				
				
				<br>
				
					<div class='clear'></div>
				<?php $rsvps = get_field( 'event_rsvps', $event->ID ); 
						$max_guests = get_field( 'event_max_guests', $event->ID );
						$seats = $max_guests - $rsvps;
					
					?>
					<small>( <u><?php echo $seats; ?></u><!--/ <?php echo $max_guests; ?>--> Slots Left ) </small>
					
						
						
						<div class='clearfix'></div>
						
											
<?php

	
	$event_rsvps = get_field('event_rsvps', $event->ID);
	//echo "RSVPS" . $event_rsvps;
	$max_guests = get_field( 'event_max_guests', $event->ID );
	//echo "MAX" . $max_guests;
 if( $event_rsvps < $max_guests ){ ?>		
	<div id="Verify" style="display: block;">		

		<button id="Verify" class="btn btn-success btn-block btn-lg hidden"><br>> RSVP NOW <<br><br></button>	
			
	</div>			
<?php }else{ ?>
		<h3 class="alert-danger">This Event had <u><?php echo $max_guests; ?></u> Slots!</h3>
		<br>
		
		<div id="Verify" style="display: block;">		

		<button id="Verify" class="btn btn-danger btn-lg">> Join the Overflow <</button>	<br>
			
		
	</div>	
<?php } ?>		
		
			
	<div id="Verify" class="  " style="display:none;">
		<div class="well ">
				
		<form method='get' src="/?p=<?php echo $event->ID; ?>">
				
			
			<div class='clearfix'></div>
			
			
			<h3><center>Confirm - Basic Stats</center></h3><hr>	
				<div class=' col-xs-6'>
				Age:
			</div>
			<div class=' col-xs-6'>
				 <input type='text' name='MX_user_age' value='<?php echo get_user_meta(  $current_user->ID, 'MX_user_age', 1); ?>' required>
			</div>
			<div class=' col-xs-6'>
				Height:
			</div>
			<div class=' col-xs-6'>
			<?php 
				
					$att = get_user_meta($current_user->ID, 'MX_user_height_ft', 1);
					$options = array( '', '4', '5',  '6',  '7' );

				?>
				<select name="MX_user_height_ft" required>
				<?php 
					foreach($options as $option){
						
						?>
						<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
						<?php
					}
				?>
				</select>
			
				ft
				
				<?php 
				
					$att = get_user_meta($current_user->ID, 'MX_user_height_in', 1);
					$options = array( '', '0', '1', '2',  '3',  '4', '5',  '6',  '7', '8', '9', '10', '11');

				?>
				<select name="MX_user_height_in" required>
				<?php 
					foreach($options as $option){
						
						?>
						<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
						<?php
					}
				?>
				</select>
				
						 in
				
				
			</div>
			<div class=' col-xs-6'>
				Weight:
			</div>
			<div class=' col-xs-6'>
				<input type='text' name='MX_user_weight' value='<?php echo get_user_meta($current_user->ID, 'MX_user_weight', 1); ?>' required>
			</div>	
			
				<div class=' col-xs-6'>
				Position:
			</div>
			<div class=' col-xs-6'>
				<?php 
				
					$att = get_user_meta($current_user->ID, 'MX_user_position', "user_" . $user->ID);
					
					$options = array( 'Top', 'Vers/Top', 'Vers', 'Vers/Bttm', 'Bottom');

				?>
				<select name="MX_user_position" required>
				<?php 
					foreach($options as $option){
						
						?>
						<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
						<?php
					}
				?>
				</select>
			</div>
			<div class=' col-xs-6'>
				Endowment:
			</div>
			<div class=' col-xs-6'>
				<?php 
				
					$att = get_user_meta($current_user->ID, 'MX_user_endowment', "user_" . $user->ID);
					$options = array(  '4', '4.5', '5', '5.5', '6', '6.5', '7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '12.5', '13+');

				?>
				<select name="MX_user_endowment" required>
				<?php 
					foreach($options as $option){
						
						?>
						<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
						<?php
					}
				?>
				</select>
					 in
			</div>
											
			<div class=' col-xs-6'>
				Cut / Uncut:
			</div>
			<div class=' col-xs-6'>
				<?php 
				
					$att = get_user_meta($current_user->ID, 'MX_user_circumcised', "user_" . $user->ID);
					
					$options = array(  'Cut', 'Uncut');

				?>
				<select name="MX_user_circumcised" required>
				<?php 
					foreach($options as $option){
						
						?>
						<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
						<?php
					}
				?>
				</select>
			</div>
				
			<div class='clear'></div><hr>
			<h3><center>Contact Info</center></h3><hr>	
				<div class=' col-xs-6'>
				Name / Alias: *
			</div>
			<div class=' col-xs-6'>
				 
				 <input name='username' type='text' value='<?php echo $current_user->display_name; ?>' required>
			</div>
				<div class=' col-xs-6'>
				Phone#:
			</div>
			<div class=' col-xs-6'>
				 
				 <input name='MX_user_phone' type='text' value='<?php	echo get_user_meta($current_user->ID, 'MX_user_phone', "user_" . $current_user->ID); ?>' >
			</div>
				<div class=' col-xs-6'>
				Email: *
			</div>
			<div class=' col-xs-6'>
				 
				 <input name='MX_user_email' type='text' value='<?php	echo get_user_meta($current_user->ID, 'MX_user_email', "user_" . $current_user->ID); ?>' required>
			</div>
				<div class=' col-xs-6'>
				City:
			</div>
			<div class=' col-xs-6'>
				 
				 <input name='MX_user_city' type='text' value='<?php	echo get_user_meta($current_user->ID, 'MX_user_city', "user_" . $current_user->ID); ?>' >
			</div>
				<div class=' col-xs-6'>
				State:
			</div>
			<div class=' col-xs-6'>
				 
				 <input name='MX_user_state' type='text' value='<?php	echo get_user_meta($current_user->ID, 'MX_user_state', "user_" . $current_user->ID); ?>' >
			</div>
			<div class='clearfix'></div><hr>
			
			<div class="event-info h4 hidden1">
					<div class='clearfix'></div><br>
						<div class="col-xs-6">
							<b>Are you Hosting?</b>
						</div>
						<div class="col-xs-6">
							<?php 
							
								$att = get_user_meta($userid, 'event_host', 1);
								$options = array( 'No', 'Yes' );

							?>
							<select name="event_host" >
							<?php 
								foreach($options as $option){
									
									?>
									<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
									<?php
								}
							?>
							</select>

						</div>
					</div>
			<div class='clearfix'></div>
			
			<p>NOTICE - Only RSVP if you Plan to SHOW UP!</p>
			
			<div class='clearfix'></div><hr>
			
					
					<input name='userID' type='hidden' value='<?php echo $current_user->ID; ?>'>
					<input name='time' type='hidden' value='<?php echo date("g:i A"); ?>'>
					<input name='mystery' type='hidden' value='true'>
					<input name='update' type='hidden' value='true'>
					<input type='submit' value='CONFIRM' class='btn btn-success btn-block btn-lg'>
					

		
		</form>
			
			
		<a href='/events' class='btn btn-danger btn-block btn-lg hidden'><< Im NOT Going</a>	
			
				
		</div>
			
	</div>		
			<div class='clearfix'></div>
						
						
						
			</div>
			

						
			
			
			
			
		
		</div>
		
		
		<div class='clearfix'></div>
		
		<div class='container'>
			<a href="/?p=<?php echo $event->ID; ?>" target="_blank" class="btn btn-success btn-block btn-lg pulse"><br>  Request a DOOR PASS &raquo; <br><br></a>
			
		</div>
		
		
		<div class='clearfix'></div>
		</div>
		
		<?php } ?>
		
		<div class='clearfix'></div>
 