<?php
/**
 * Template Name: Options Template
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 
 

 foreach ($_COOKIE as $param_name => $param_val) {
				
	//echo $param_name . " ==> " . $param_val . "<br>";

}
 ?>

 <?php
 foreach ($_POST as $param_name => $param_val) {
				
	//echo $param_name . " ==> " . $param_val . "<br>";

}			
			
 if( isset($_COOKIE["MX_user_email"])){
			setcookie( "MX_user_email", $_COOKIE["MX_user_email"], time() + (86400 * 30), "/");
			
			update_post_meta( $_COOKIE['contactID'], 'MX_user_email'  , $_COOKIE['MX_user_email'] );
		}
 
 if( isset($_COOKIE["contactID"]) )  {	

			
			
			$funnel = "/list/";
		
			wp_redirect($funnel);
			exit;	
		}
 
 
 
 
		if( $_POST['key'] == "confirm" ){
			
			$name = "";
		
		if($_COOKIE['name'] == ''){ $name = "Mystery Man"; }else{ $name = $_COOKIE['name']; }
		// Create post object
		$my_post = array(
		  'post_title'    => $name,
		  'post_type'  => 'ssi_contact',
		  'post_status'   => 'publish',
		  'post_author'   => 1,
		  //'post_category' => $cats
		);
		 
		// Insert the post into the database
		$postID = wp_insert_post( $my_post );
		
		setcookie( "contactID", $postID, time() + (86400 * 30), "/");
		
		$current_user = wp_get_current_user();
		//print_r($current_user);
		
		setcookie( "userID", $current_user->ID, time() + (86400 * 30), "/");
		
		setcookie( "MX_user_level", "1", time() + (86400 * 30), "/");
		update_post_meta( $postID, "contactID", $postID );
		update_post_meta( $postID, "userID", $current_user->ID );
		
		
			foreach ($_COOKIE as $param_name => $param_val) {
				
				//echo $param_name . " ==> " . $param_val . "<br>";
				
				update_post_meta( $postID, $param_name, $param_val );
				//update_field($param_name, $param_val , "user_" . $current_user->ID );
				//echo "'MX_user_$param_name' ,";
			}
			
		
	/*	
		$EventName = date("M jS", strtotime(get_field('event_date',get_the_ID())));
		
		$catID = get_cat_ID( $EventName );
							//$category =  get_the_category($EventID);
							$cats = array();
							
							array_push($cats, $catID);
		
		
		add_post_meta($postID , 'showed_up', 'No' );
		add_post_meta($postID , 'event_host', 'No' );
		update_post_meta($postID , 'vortex_system_likes', 1 );
		update_post_meta($guestID  , 'event_time_in', $_GET['time'] );
		wp_publish_post( $postID ); 
		wp_update_post( $postID ); 
		
		*/
		wp_update_post( $postID ); 
	}
 
 
 
	
 
			//echo "Count-> " . $_POST['count'];
			//echo "<br>Choice-> " . $_POST['choice'];
			
			if( $_POST['key'] == "member" ) {	
				if( $_POST['choice'] == "Yes" ) {
					$funnel = "/login/";
					//wp_redirect($funnel);
					//exit;	
				}
			}else{
				setcookie( $_POST['key'], $_POST['choice'], time() + (86400 * 30), "/");
			}
			
			
			//header("Refresh:0");
			//echo "<br>Cookie-> " . $_COOKIE["contactID"];
		if( isset($_POST["MX_user_email"]) ) {	

			$funnel = "/list/";
		
			//setcookie( "MX_user_email" , $_POST['MX_user_email'], time() + (86400 * 30), "/");
			
			//$email = $_POST["MX_user_email"];
			
			$contactID = 0;
			
			$contactID = $_COOKIE["contactID"]; 
			
			
			//update_post_meta( $contactID, "MX_user_email", $email );
			
			wp_update_post( $contactID ); 
			//echo "EMAIL CAPTURED!";
			//wp_redirect($funnel);
			//exit;	
		}
		
			
		if( isset($_COOKIE["confirm"]) || is_user_logged_in() ) {	

			if( $_COOKIE['person'] == "Pix" ){ $funnel = "/photos/"; }
			if( $_COOKIE['person'] == "Vids" ){ $funnel = "/videos/"; }
			
			$funnel = "/profile/";
		
			//wp_redirect($funnel);
			//exit;	
		}
		
		

get_header('new-network'); ?> 
	
	

<div id="options" class="col-md-8 col-md-offset-2">


	<?php //print_r($current_user->ID);
		
		//wp_redirect('/tour/');
		//exit;	
		
		//setcookie( $v_username, $v_value, 30 * DAYS_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
		
		$questions = array(
		
					array ( 
					"key" => "human",
					"q" => "Have we Met Before?",
				   "a1" => "Yes",
				   "a2" => "No"
					 ),
					array ( 
					"key" => "member",
					"q" => "Are you a Site Member?",
				   "a1" => "Yes",
				   "a2" => "No"
					 ),
					 array ( 
					"key" => "name",
					"q" => "Awesome!! <br>Im <u>YungDADDY</u> .. and You Are?",
				   "a1" => "John",
				   "a2" => "Jane"
					 ),
					 array ( 
					"key" => "gender",
					"q" => "You Consider Yourself a:",
				   "a1" => "Boy",
				   "a2" => "Girl"
					 ),
					array ( 
					"key" => "seeking",
					"q" => "What Are You Seeking?",
				   "a1" => "Sex",
				   "a2" => "Love"
					 ),
					 array ( 
					"key" => "person",
					"q" => "Which Turns You On More?",
				   "a1" => "Pix",
				   "a2" => "Vids"
					 ),
					 array ( 
					"key" => "confirm",
					"q" => "Does this look about right?",
				   "a1" => "Yes",
				   "a2" => "No"
					 ),
					 array ( 
					"key" => "MX_user_email",
					"q" => "Good Job! - I will Email the Next Step:",
				   "a1" => "Yes",
				   "a2" => "No"
					 ),
					 array ( 
					"key" => "thanks",
					"q" => "Thank You!",
				   "a1" => "Yes",
				   "a2" => "No"
					 ),
		);
		
		//print_r( $questions );
		//echo " --> " ;
		//print_r($_POST['key']);
		//echo " <br> " ;
		//echo " --> " ;
		//print_r($_POST['choice']);
		//echo " <br> " ;
		//setcookie( $_POST['key'], $_POST['choice'], time() + (86400 * 30), "/");
		
		
		
		
		foreach($questions as $question){
				
				//print_r($question['key']);
				
				//echo " --> " ;
				
				//print_r($_COOKIE[$question['key']]);
				
				//echo " <div class='clear'></div><hr>" ;
				
				
			}
			
		
		$count = $_POST['count'];
		if( !isset( $_POST['count'] ) ){  $count = 0; }
		$question = $questions[$count];
		
	

	if( $question['key'] == "confirm" ) {
			
			echo "<h3><center> You are a <u>" . $_COOKIE['gender'] . "</u> named <u>" . $_COOKIE['name'] . "</u> seeking <u>" . $_COOKIE['seeking'] . "</u>.</center></h3>";
			
			
			
			
		}
		
				?> 
				
		
		
		
	<div class='col-xs-12'>	

		<h1 class="entry-title text-center"><?php echo $question['q']; ?></h1>
		
		<form id='options' method='POST' >
			<div class='well options text-center'>
				
				<input type='hidden' name='key' value='<?php echo $question['key']; ?>'> 	
				<input type='hidden' name='count' value='<?php echo $count+1; ?>'> 
			
				
				<?php 
				
					if( $question['key'] == 'name' ){
					?>
					
					<center><input type="text" name='choice' placeholder='Type Your Name' width="75%">
					</center>
					<input type='submit' class='btn btn-danger' value='Submit'> 
				
				<?php }else if( $question['key'] == 'MX_user_email' ){
					?>
					
					<center><input type="text" name="MX_user_email" placeholder="Enter Your Email" width="75%">
					</center>
					<input type='submit' class='btn btn-danger' value='Submit'> 
				
				<?php }else if( $question['key'] == 'thanks' ){
					?>
					
					<center>
					<a href='/list'>Next Step >></a>
					</center>
					
				
				<?php }else{ ?>
					<div class='col-xs-6 '>
						<input type='submit' name='choice' class='btn btn-danger' value='<?php echo $question['a1']; ?>'> 
						
				</div>
				<div class='col-xs-6 '>
						<input type='submit' name='choice' class='btn btn-danger' value='<?php echo $question['a2']; ?>'> 
				</div>
				
				<?php } ?>	
				<div class='clear'></div>
			</div>	
		</form>
	</div>			
			<?php
			
	
			
		echo " <div class='clear'></div><hr>" ;

?>

	<?php  if( $_POST['q'] == 'member' ){ ?>
	
			<center><a href='/login/'>Member Login </a></center>
		
		<?php } ?>
		



	<?php //get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->
	<div class='clear'></div>
	
<div class='text-left col-md-12 mansion well hidden'>
	
		<h4 class='text-center '>Training List</h4><hr>
	<?php
		$guests = get_posts( array (
						
					   'posts_per_page'    =>  -1,
					   'post_type' => 'ssi_contact',
					   'post_status' => 'pending',
						//'category_name'                  => 'event' . get_the_ID() ,
					    //'order'                  => 'asc',
						//'orderby'                => 'meta_value_num',
						//'meta_key'               => 'vortex_system_likes',
						//'categories'	=>	array( -147 ),
					)     );
					
			foreach($guests as $lead){
				?>
				
				
					<div class='col-xs-6'>
						<a target='_blank' href='<?php echo $lead->guid; ?>'>
								<?php echo $lead->post_title;  ?>
						</a>
					</div>
					<div class='col-xs-6 text-right'>
					
						Level 0
					
					</div>
					<div class='clear'></div>
					
				<?php
				
			}
					
	?>
		
	
<div class='clear'></div>
			
</div>

<?php //get_sidebar(); ?>
<?php get_footer('preview'); ?>