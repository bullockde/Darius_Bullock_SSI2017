<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package Afterlight
 * @since Afterlight 1.0
 */

get_header(); ?>
<div class="btn-group btn-group-justified">

	<a href="/photo-list" class="btn btn-default"> <small>LIST</small> </a>
	<a href="/photos" class="btn btn-default"> <small>6 GRID</small> </a>
	<a href="/photo-gallery" class="btn btn-default"> <small>15 GRID</small> </a>
	<!--<a href="http://dlfreakfest.org/levels/?level=4" class="btn btn-default">Level 4 <br> <small>REQUEST</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=5" class="btn btn-default">Level 5 <br> <small>SESSION</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=6" class="btn btn-default">Level 6 <br> <small>THoT FILE</small> </a>
	<a href="http://dlfreakfest.org/levels/?level=7" class="btn btn-default">Level 7</a>-->
	<!--<a href="http://dlfreakfest.org/levels/?level=8" class="btn btn-default">Level 8</a>-->
	<!--<a href="http://dlfreakfest.org/levels/?level=9" class="btn btn-default">Level 9</a>-->
	<!--<a href="http://dlfreakfest.org/levels/?level=10" class="btn btn-default">Level 10</a>-->
</div>
<div id="primary" class="">

	
			
			
					
							
							<div class='clear mb-15'></div>
	
	<div id='add-gallery' style='display: block;' class='text-center <?php if ( /*!is_user_logged_in()*/ 0  ) { echo "hidden"; } ?>'>
			<center>
				<button id='add-gallery' class='hidden-print btn btn-success pulse btn-lg text-center btn-block1'>> Add Photos <</button><br>
			</center>
		</div>
	
		<div class='clear'></div>	<br>

		<div id='add-gallery' style='display: none;' >
			<div class='clear'></div>	
			<div class="col-md-10 col-md-offset-1  home-beta">
			<center><h3> Upload Photos! </h3></center><br>
			</div>
			<div class="col-md-10 col-md-offset-1 text-left">
			<div class="well">
			
			<?php //echo do_shortcode('[gravityform id="11" title="false" description="false"]');
			
			echo do_shortcode('[gravityform id="36" title="false" description="false"]
			');
			
			?></div>
			<div class='clear'></div>	
			<button id='add-gallery' class='hidden-print btn btn-default btn-sm'>x close</button>
			<div class='clear'></div>	<br>
			</div>
		</div>
	<div class='clear'></div>
			
			

	<div class=' '><div class='col-md-8'>
	
	

	
<?php




		$args = array( 'post_type' => array( 'post','ssi_photos'), 'posts_per_page' => 6  );

		$leads = get_posts( $args );
		
		$count = 0;
		$skipped = 0;

		//print_r( $leads );
		foreach( $leads as $lead ){ 
			
			if(/* !is_user_logged_in() && get_field( 'member_level', $lead->ID ) != 'Public'*/ 0 ){ $skipped++; continue; }else{ $count++; }
	?>
	
		<div class='video-set col-md-12 well1'>
			<div class='col-md-12'>

				
			<?php 
				echo "<div class='' >";
			//	echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>";
				
					if ( has_post_thumbnail( $lead->ID ) ) {
    			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $lead->ID ), 'thumbnail' );	
						
   						if ( ! empty( $large_image_url[0] ) ) {
        						echo '<a href="' . esc_url( $large_image_url[0] ) . '" title="' . the_title_attribute( array( 'echo' => 0 ) ) . '">';
        						//echo get_the_post_thumbnail( $lead->ID, 'thumbnail' ); 
        						echo '</a>';

   					 	}
					}
				echo "</div>";
				?>
				<!--<a href='/photo/<?php echo $lead->post_name; ?>'> <img src='<?php echo esc_url( $large_image_url[0] ); ?>' class='img-responsive aligncenter'></a>
				-->
			</div>

			<div class='col-md-4 hidden'>
					<div class='visible-xs'><br><br></div>
					<h4>Photo Set</h4>
					<hr>
					
				<?php
						$shortcode = get_field( 'gallery_shortcode', $lead->ID );
						echo do_shortcode($shortcode);

				 ?>
				<div class='clear'></div><br><br>

				<p class="btn btn-block btn-lg hidden" style="text-align: center;"><a href="<?php echo $lead->guid; ?>">View Preview</a></p>
				<p class="btn btn-block btn-lg hidden" style="text-align: center;"><a href="/subscribe/">Subscribe Now!</a></p>
			</div>
			<div class='clearfix'></div>
			
			<h4 class="well"> <a href='/photo/<?php echo $lead->post_name; ?>'> <?php echo $lead->post_title; ?> </a> <small>  -- <?php echo get_the_date( 'F d - h:i A' , $lead->ID ); ?> </small></h4>
		</div>
		
		
		<?php 

		if( ($count % 3) == 0){ echo "<div class='clearfix'></div>";}

		}// #END forach
	?>
	
	<div class='clearfix'></div>
</div>
	
			<div class='col-md-4   text-center '>
		   
				<div class='1ads 1ad-shift img-thumbnail'>
					<?php //get_template_part( 'content', 'sidebar-ads' ); 
					
					
					    get_template_part( 'ad', '300-250-1' );
					   // get_template_part( 'ad', '300-250-2' );
					?>	
					<div class='clearfix mb-0'></div>
					<?php //get_template_part( 'content', 'sidebar-ads' ); 
					
					
					   // get_template_part( 'ad', '300-250-1' );
					    //get_template_part( 'ad', '300-250-2' );
					?>	
				</div>
	        <div class='clearfix mb-15'></div>
	        
	         <div class='well  text-center mb-15'>
		        <?php 
		
    			//get_template_part('content' , 'member-quicknav'); 
    
    	    	
    			
    			dynamic_sidebar( 'content-bottom-2' );
    			
    		//	get_template_part( 'content', 'sidebar-upcoming-events' );
    			
    			//get_template_part( 'ad', '300-250-1' );
    		
    		
    		?>
    		</div>
		</div>
		
				<div class='clear'></div>
				
	
</div>
	
</div><!-- .content-area -->

<?php //get_template_part( 'content', 'welcome' ); ?>
</div>
<div class='clearfix'></div><br>
<?php 
	get_footer('members'); 
?>