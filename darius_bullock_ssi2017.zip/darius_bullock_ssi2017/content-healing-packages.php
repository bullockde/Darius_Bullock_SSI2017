	
	<center><h2>Coaching / Healing Packages</h2></center>
	
	<!-- Pricing Table 3 Columns -->
<div class="clear"></div>
<div class="container"><hr>
<div class="columns">
<ul class="price">
 	<li class="header">ReVAMP</li>
 	<li class="grey">$10 / <small>Monthly</small></li>
 	<li>1 Call</li>
	<li>1 Email</li>
 	<li> -- </li>
 	<li> -- </li>
 	
	<li class="grey"><a class="btn btn-info btn-lg btn-block" href="/contact">Start Now &gt;&gt;</a></li></ul>
</div>
<div class="columns">
<ul class="price">
 	<li class="header" style="background-color: #008fb9;">ReCOVER</li>
 	<li class="grey">$30 / <small>Monthly</small></li>
 	<li>3 Calls</li>
	<li>3 Emails</li>
 	<li>1 Guided Step</li>
 	<li> -- </li>
 	
	<li class="grey"><a class="btn btn-info btn-lg btn-block" href="/contact">Start Now &gt;&gt;</a></li></ul>
</div>
<div class="columns">
<ul class="price">
 	<li class="header">ReNEW</li>
 	<li class="grey">$50 / <small>Monthly</small></li>
 	<li>5 Calls</li>
	<li>5 Emails</li>
 	<li>2 Guided Steps</li>
 	<li>Recap / Reccommendation</li>
 	
 	<li class="grey"><a class="btn btn-info btn-lg btn-block" href="/contact">Start Now &gt;&gt;</a></li>
</ul>
</div>
</div>
<div class="clear"></div>
<!-- ## Pricing Table 3 Columns -->
	