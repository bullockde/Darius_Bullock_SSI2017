<section id='dashboard' class='header  text-center'>

<div class='clear'></div><br>


<?php 
	if( is_user_logged_in() ){
	 $current_user = wp_get_current_user();
	}
?>



<div class='container'>

		<div class='clear'></div>
		
<?php if( is_user_logged_in() ){ ?>

<div class="spotlight col-md-12 text-center">
				
					<div class='clear'></div> 
					<div class=' col-md-12'>
					
								<a href='/'>   
									<center><img class='logo' src='/wp-content/uploads/2016/11/man-x-scape-logo.png' class='img-responsive '>
									</center>

								</a> 
								<br><br>
								<?php //echo dispMailbox();

								?><br><br>

					</div>
					<div class=' col-md-1'>
					
								
								<br><br>
							

					</div>
					
					<div class="col-md-5   col-md-offset-0 image text-center hidden1">
							<div class='clear'></div> 
						<div class="well">
					
					<h4><b><?php if( is_user_logged_in() ){  echo 'Welcome Back, ' . $current_user->user_login . '!'; }else{ echo "<b>Welcome, " . $_COOKIE['name'] . "!</b>";}  ?></b></h4>
									<div class='clear'></div> <hr>
									
									
					<div class='col-xs-5 col-sm-4 text-center'>
					
					
					
								<?php
								
									if ( !function_exists( 'bp_core_fetch_avatar' ) ) { 
											require_once '/bp-core/bp-core-avatars.php'; 
										} 
										  
										// An array of arguments. All arguments are technically optional; some will, if not provided, be auto-detected by bp_core_fetch_avatar(). This auto-detection is described more below, when discussing specific arguments. 
										$args = array( 
											'item_id' =>  $current_user->ID, 
											'object' => '', 
											'type' => '' ,
											'width' => '100px',  
											'height' =>'100px', 
										); 
									  
									// NOTICE! Understand what this does before running. 
									
									
									
				if(!userphoto_exists($current_user)){
					echo bp_core_fetch_avatar($args);
					
					//userphoto($current_user->ID, '<div class="photo porn">', '</div>', array(style => 'width: 125px; height: 125px;') ) ;
					
				}else if(userphoto_exists($current_user)){
										
										
					userphoto($current_user->ID, '<div class="photo porn">', '</div>', array(style => 'width: 125px; height: 125px;') ) ;
					
				}else{
				
				?>
					<img src='http://ssixxx.com/wp-content/uploads/2016/08/man-blank-profile.png' class="photo">
					
				<?php } ?>

									
									<div class='clear'></div>
									<a href='/members/instaflixxx/profile/change-avatar/' >Change Photo</a>
					</div>
				<div class='col-xs-7 col-sm-8 text-center'>
	
				<div class='col-xs-6'><b>Age:</b> </div><div class='col-xs-6'> <?php			
					
		if( get_user_meta($current_user->ID, 'MX_user_age' , 1) ){
					echo get_user_meta($current_user->ID, 'MX_user_age' , 1);
		}else{
					echo 'Old';
		}
	?></div>
				<div class='col-xs-6'><b>Ht:</b> </div><div class='col-xs-6'><?php			
					
		if( get_user_meta($current_user->ID, 'MX_height_ft' , 1) ){
					echo get_user_meta($current_user->ID, 'MX_height_ft' , 1) . "' " . get_user_meta($current_user->ID, 'MX_height_in' , 1);
		}else{
					echo 'Short' ;
		}
	?> </div>
				<div class='col-xs-6'><b>Wt:</b> </div><div class='col-xs-6'><?php			
					
		if( get_user_meta($current_user->ID, 'MX_weight' , 1) ){
					echo get_user_meta($current_user->ID, 'MX_weight' , 1);
		}else{
					echo 'Fat ';
		}
	?> </div>
								
	
							
						
								</div>
								

									<div class='col-xs-7'>
										<div class='clear'></div> <hr>
										<div class='col-sm-4'>
											<b>Location:</b>
										</div>
										<div class='col-sm-8'>  
												<p><?php 
												if ( get_field('city', "user_" . $current_user->ID ) && get_field('state', "user_" . $current_user->ID ) ){
												
													echo get_field('city', "user_" . $current_user->ID );?>, <?php echo get_field('state', "user_" . $current_user->ID ); ?> <?php //echo get_field('zip_code', "user_" . $current_user->ID ); 
												
												}else if ( get_field('state', "user_" . $current_user->ID ) ){
													echo get_field('state', "user_" . $current_user->ID ) . ', ' . get_field('country', "user_" . $current_user->ID );
												}
												else{
													echo 'In The Closet';
												}
												
												?></p>
										
									</div>
									
									</div>

					
					<div class='clear'></div><hr style='margin: 1em 0 0.5em;'>
												<div class='col-xs-6'>
									<a href='/edit-profile/?ID=<?php echo  $current_user->ID; ?>' class='btn  btn-block'>Edit Profile</a>
									</div>
									<div class='col-xs-6'>
						<a href='/wp-login.php?action=logout' class='btn  btn-block'>Logout</a>
									</div>
									<div class='clear'></div> 
							
					
					</div>

					
					
					<div class='clear'></div><br>
			
				
				
		

			 <a href='/members/<?php $current_user = wp_get_current_user(); echo  $current_user->user_login;  ?>/profile/change-avatar/'><button class='btn btn-info btn-block hidden1'>Update Profile Photo</button></a>

				<button id='profilemenu' class='btn btn-info btn-block hidden1'>Profile Menu</button>

				<div id='profilemenu' class="profilemenu " style="display: none;">

					<a href='/members/<?php $current_user = wp_get_current_user(); echo  $current_user->user_login;  ?>/profile/' class='btn btn-lg btn-info btn-block'>View My Profile</a>
						<a href='/members/<?php $current_user = wp_get_current_user(); echo  $current_user->user_login;  ?>/profile/edit/' class='btn btn-lg btn-info btn-block hidden1'>Edit My Profile</a>


				</div>

				<button id='whatsnew' class='explode btn btn-danger btn-sm hidden1'>Random Button</button>
				
</div></div>
<?php }else{
	?>	<br><br>
	<a href='/'>   
									<center><img class='logo' src='/wp-content/uploads/2016/11/man-x-scape-logo.png' class='img-responsive '><br>(Return to Homepage)
									</center>

								</a> 
								<br><br>
	<?php

}
	?>
						
</div><!--  #Container  -->




</section>