<?php 
/* Template Name: Companions
*/

get_header(); ?>
   
    	<div class="clearfix mb-15"></div>
		
<?php get_template_part('content','men'); ?>

    
<?php get_footer(); ?>
