
	
		<div class='clear'></div>
			
			<?php  
			$count = 0;
			$photo_count = 1;
			
			$user = $current_user = wp_get_current_user();

	wp_reset_query();
	$args = array(
    'author'        =>  $user->ID,
	'post_type' 	=> 'ssi_photos',
    'orderby'       =>  'modified',
    'order'         =>  'DESC',
    'posts_per_page' => -1
    );
	
	$Galleries = get_posts($args);
	
	?>
	<hr><h3 class=' text-center'><u><?php echo count($Galleries); ?></u> Photos</h3><hr>
	<?php
	
	foreach($Galleries as $Gallery){ 
	
		//if( get_field( 'post_type', $Gallery->ID ) == 'ssi_photos' ){ }else{ continue; }
		
		//print_r($Gallery);
	?>
	
	<div class='col-xs-4 col-md-2 text-center'>
	    <?php echo $photo_count++; ?><br>
	    <a  target='_blank' class='img-thumbnail' href='/?p=<?php echo $Gallery->ID; ?>'>	
	        <?php
    			echo "";
    			echo get_the_post_thumbnail( $Gallery->ID , array(100,100) );
    			echo "";
			?>
			<br>
			(<?php echo get_field( '#_of_photos', $Gallery->ID ); ?> Photos)
			
		</a>
		<div class='clear mb-10'></div>
	</div>
	<div class='well green hidden'>
		 <a  target='_blank' href='/?p=<?php echo $Gallery->ID; ?>'>
							
						<div class='col-xs-2'>	
						<?php
								echo "";
								echo get_the_post_thumbnail( $Gallery->ID , array(50,50) );
								echo "";
								?>
						</div>
						<div class='col-xs-8 hidden1'>
						
					
							
						<?php		
								echo $Gallery->post_title;
								
							?> - 
							(<?php echo get_field( '#_of_photos', $Gallery->ID ); ?> Photos)
							<br><u><?php if(get_field( 'member_level', $Gallery->ID )){ echo get_field( 'member_level', $Gallery->ID ); }else{  echo "Public"; } ?></u>
						
						</div> 
							
							
							<button type="button" class="btn btn-default btn-sm pull-right hidden1">
							  View <span class="glyphicon glyphicon-play"></span> 
							</button>

							
									
						
								</a>
								<div class='clear'></div>
								</div>
								
<?php	}
	
wp_reset_query();

$count++;  ?>


    <div class='col-xs-4 col-md-2 text-center'>
	    <a type="button" class="btn btn-default btn-sm hidden1" id="myBtn2" data-toggle="modal" data-target="#myModal2-photos" data-show="true"><span class=" glyphicon glyphicon-plus" aria-hidden="true"></span><br>Photos</a>
	</div>

    

	<div class='clear'></div>
	

	
	<div id='add-gallery' style='display: none;' class='text-center <?php if ( /*!is_user_logged_in()*/ 0  ) { echo "hidden"; } ?>'>
			
			<button id='add-gallery' class='hidden-print btn btn-success btn-lg btn-block hidden1'>> Add Photos <</button>
			
			
				
								<div class='clear'></div>
	 
    <a type="button" class="btn btn-default 1btn-md hidden" id="myBtn2" data-toggle="modal" data-target="#myModal2-albums" data-show="true"><span class=" glyphicon glyphicon-plus" aria-hidden="true"></span> Albums</a>

	
			
		</div>