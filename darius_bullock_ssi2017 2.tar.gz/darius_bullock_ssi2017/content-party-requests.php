<div class='party-log '>

<h4 class='text-center'> Top <u>5</u> Party Requests <hr></h4>

<div class='clear'></div>	
	
	<div id='add-gallery' style='display: block;' class=' col-md-12 <?php if ( /*!is_user_logged_in()*/ 0  ) { echo "hidden"; } ?>'>
			
			<button id='add-gallery' class='hidden-print btn btn-success btn-lg btn-block hidden'>> New Post <</button>
			
		</div>
	
		<div class='clear'></div>	

		<div id='add-gallery' style='display: none;' >
			<div class='clear'></div>	
			<div class="col-md-10 col-md-offset-1  home-beta">
			<center><h3> New Post! </h3></center>
			</div>
			<div class="col-md-10 col-md-offset-1 text-left">
			<div class="well">
			
			<?php //echo do_shortcode('[gravityform id="11" title="false" description="false"]');
			
			echo do_shortcode('[gravityform id="23" title="false" description="false"]
			');
			
			?></div>
			<div class='clear'></div>	
			<button id='add-gallery' class='hidden-print btn btn-default btn-sm'>x close</button>
			<div class='clear'></div>	<br>
			</div>
		</div>
	<div class='clear'></div>
	
	

<div class='col-md-12'>
	
	

	
<?php

		if ( is_single() ) {
			// about.php is used
			//echo "IS PARTY!";
			
			$event_category = 'event' . get_the_ID();
				$args = array( 'post_type' => 'ssi_event_logs', 'posts_per_page' => 5  );
		} else {
		//	echo "NOT PARTY!";
			// about.php is not used
				$args = array( 'post_type' => 'ssi_event_logs', 'posts_per_page' => 5  );
			
		}


	

		$leads = get_posts( $args );
		
		$count = 0;
		$skipped = 0;

		//print_r( $leads );
		foreach( $leads as $lead ){ 
		
			if( !in_category("requests") ){ continue; }
			
			//if( !is_user_logged_in() && get_field( 'member_level', $lead->ID ) != 'Public' ){ $skipped++; continue; }else{ $count++; }
	?>
	
		<div class='video-set col-md-12 well1'>
			<div class='col-md-12'>

				
			<?php 
				echo "<div class='' >";
			//	echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>";
				
					if ( has_post_thumbnail( $lead->ID ) ) {
    			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $lead->ID ), 'thumbnail' );	
						
   						if ( ! empty( $large_image_url[0] ) ) {
        						echo '<a href="' . esc_url( $large_image_url[0] ) . '" title="' . the_title_attribute( array( 'echo' => 0 ) ) . '">';
        						//echo get_the_post_thumbnail( $lead->ID, 'thumbnail' ); 
        						echo '</a>';

   					 	}
					}
				echo "</div>";
				?>
				<!--<a href='/photo/<?php echo $lead->post_name; ?>'> <img src='<?php echo esc_url( $large_image_url[0] ); ?>' class='img-responsive aligncenter'></a>
				-->
			</div>

			<div class='col-md-4 hidden'>
					<div class='visible-xs'><br><br></div>
					<h4>Photo Set</h4>
					<hr>
					
				<?php
						$shortcode = get_field( 'gallery_shortcode', $lead->ID );
						echo do_shortcode($shortcode);

				 ?>
				<div class='clear'></div><br><br>

				<p class="btn btn-block btn-lg hidden" style="text-align: center;"><a href="<?php echo $lead->guid; ?>">View Preview</a></p>
				<p class="btn btn-block btn-lg hidden" style="text-align: center;"><a href="/subscribe/">Subscribe Now!</a></p>
			</div>
			<div class='clear'></div>
			
			<h4 class="text-left" > <a href='/?p=<?php echo $lead->ID; ?>'> <?php echo $lead->post_title; ?> </a> </h4>
			<div class='text-left'>
			- by: 
			
			<a target="_blank" href="/user-profile/?ID=<?php echo get_the_author_meta( 'ID', $lead->post_author ); ?>">
			<?php //$author = get_the_author_meta( $lead->ID ); 
			
				//print_r( $author );
				echo get_avatar( get_the_author_meta( 'ID', $lead->post_author ) , "25");
				//the_author_meta( 'display_name', $lead->post_author );
			?> 
			</a>
			<small>  -- <?php echo get_the_date( 'M d - h:i A' , $lead->ID ); ?> </small>
			
			</div>
		</div>
		
		
		<?php 

		if( ($count % 3) == 0){ echo "<div class='clear'></div>";}

		}// #END forach
	?>
	
			
	
	
</div>
	
		
				<div class='clear'></div><br>
				
	
</div>