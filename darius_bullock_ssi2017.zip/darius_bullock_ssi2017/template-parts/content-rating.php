<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

//global $wp_query;
  //  $theid = intval($wp_query->queried_object->ID);
   

$Gallery = get_post(get_the_ID());

//var_dump( $Gallery );

?>

<?php $format = get_post_format(); ?>


	
	<a  target='_blank' href='/?p=<?php echo $Gallery->ID; ?>' class='btn  is-style-outline has-very-light-gray-to-cyan-bluish-gray-gradient-background has-background  btn-block mb-15 '>
	
	<div class='wells bg yellow1 mb-10' >
		
							
						<div class='col-xs-4 col-sm-2 img-thumbnail '>
						
							
						 
						<?php
						
						
						
						
						if ( has_post_thumbnail( $Gallery->ID ) ) {
    				echo get_the_post_thumbnail( $Gallery->ID , array(75,75) , array( "class" => "img-thumbnail circle img-responsive " ) );
    				
    				
   					 	}else if( get_field('youtube_id', $Gallery->ID) ) {
						?>
						<center>
							<div class='clearfix mb-5'></div>
								<img src='http://img.youtube.com/vi/<?php echo get_field('youtube_id', $Gallery->ID); ?>/0.jpg' alt='Youtube Image' class='img-responsive img-thumbnail mb-5' >
						
						
						</center>
						<?php
						
					}else{
						?>
						<center>
						
						
						
						<img class="img-responsive img-thumbnail  1avatar circle mb-0" src="<?php echo esc_url( wp_get_attachment_url( get_theme_mod( 'custom_logo' ) ) ); ?>" width="75" height="75">
					
						
						
					 
						</center>
						<?php
						
					}
			

						
						
							
								?>
								
						<div class="clearfix mb-0"></div>
															<u><?php if(get_field( 'member_level', $Gallery->ID )){ echo get_field( 'member_level', $Gallery->ID ); }else{  echo "Public"; } ?></u>

						</div>
					<div class='col-xs-8 col-sm-10'>
						
						<h5 class="text-left 1hidden">
						<?php echo substr($Gallery->post_title, 0, 22); if( strlen($Gallery->post_title) > 22 ){ ?> ..<?php } ?></h5>
							
							<!--- 
							(<?php echo get_field( '#_of_photos', $Gallery->ID ); ?> Photos)-->
								<div class="clearfix mb-10"></div>

							
								<div class=' well  mb-0 hidden1'>	
							<?php			
							
							//
							//print_r($Gallery);
							//	if(check_rated($Gallery->ID)) { echo check_rated($Gallery->ID); }
								
								
								
								
								if(check_rated( $Gallery->ID ) ){ 
									//echo "RATED";
									
									//echo the_ratings('div',$Gallery->ID,true);
									echo do_shortcode( "[ratings id=$Gallery->ID  ]" );
								}else{
									//echo "UN-RATED";
									echo do_shortcode( '[ratings id="'. $Gallery->ID  . '"]' );
								}
                        
										$closet = 0;
						//echo do_shortcode( '[ratings id="'. $Gallery->ID  . '" results="true"]' );
							
							
	?>					</div>
						
						 
							
						</div>
							
						
								
								<div class='clearfix'></div>
						</div>
						
						
						<button type="button" class="btn btn-success btn-sm  btn-block 1pull-right">
							 View <span class="glyphicon glyphicon-play"></span> 
							</button>
						
						</a>
						
						 <div class="clearfix mb-0"></div>
		<footer class="entry-footer">
		<?php twentysixteen_entry_meta(); 
		
		?>
		
		
			
			
			
		
		
			<?php 
				
				$user_logged_in = 0;
				$user_is_admin = 0;
			$user = wp_get_current_user();
			$allowed_roles = array('editor', 'administrator');
	
			if ( is_user_logged_in() && array_intersect($allowed_roles, $user->roles ) ) {
					$user_logged_in = 1;
					$user_is_admin = 1;
					?>
					
					
					<?php
		
			edit_post_link(
				sprintf(
					/* translators: %s: Name of current post */
					__( 'Edit<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
					get_the_title()
				),
				'<span class="edit-link">',
				'</span>'
			);
		?>
					
					
		<form method="post" action="" class='1pull-left'>
			<button name="update" type="submit" class='1btn 1btn-danger link' value="Remove Lead" />Delete</button>
			<input name="ID" type="hidden" value="<?php get_the_ID(); ?>" />
			<input name="post_to_draft" type="hidden" value="true" />
			<input name="URI" type="hidden" value="<?php echo get_page_link(); ?>" />
		</form>


			<?php } ?>
			
			
	</footer><!-- .entry-footer -->
		
							
						
	
							
								<div class='clearfix mb-10'></div>




