<div class='clear'></div>

<section id='marketing' class='marketing'>
		
		<div class='container text-center'>
		<h2>Marketing & Branding</h2>
			<div class="col-md-12 text-center">
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/09/ssi-cards-maret-branding-slide.png'>
				
			</div>
			<div class="col-md-4">
				<h3>Paper Products</h3><hr>
				<ul>
					<li>Business Cards</li>
					<li>Promotional Flyers</li>
					<li>Event Advertising</li>
					<li>Invitations</li>
					<li>Thank You Cards</li><br>
					<a target='_blank' href='#' class='btn btn-default'>Learn More (coming soon)</a>
				</ul>
			</div>
			<div class="col-md-4">
				<h3>Web Products</h3><hr>
				<ul>
					<li>Website Creation</li>
					<li>Site Maintenance</li>
					<li>Web Updates & Edits</li>
					<li>SEO Management</li>
					<li>Server Management</li><br>
					<a target='_blank' href='#' class='btn btn-default'>Learn More (coming soon)</a>
				</ul>
				
			</div>
			<div class="col-md-4">
				<h3>Brand Management</h3><hr>
				<ul>
					<li>Brand Creation</li>
					<li>Social Media Marketing</li>
					<li>Person 2 Person Ads</li>
					<li>Brand Consulting</li>
					<li>Customer Management</li><br>
					<a target='_blank' href='#' class='btn btn-default'>Learn More (coming soon)</a>
				</ul>
				
			</div>
		</div>
	
	</section>
<div class='clear'></div>
