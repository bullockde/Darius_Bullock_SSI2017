<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>


<?php get_template_part( 'content', 'series-widget' ); ?><hr>

	<div id="" class="col-md-8">
	
	
			<div class='report'>
					
					
	<?php
							$Cat_ID = 0;			
			if ( is_archive() ) {
					$archive = get_queried_object();
					//echo "here";
					$Cat_ID = $archive->term_id;
				}else{
					$Cat_ID = $categories[0]->term_id;
				}		
				
			//	$movies = get_posts( array('category_name' =>  $categories[0]->name , 'orderby' => 'rand', 'posts_per_page' => 4  ) );
						$categories =  get_the_category( $Cat_ID );
						$blogs = get_posts( array('category' =>  $Cat_ID , 'orderby' => 'rand', 'posts_per_page' => -1  ) );
						$models = get_posts( array('post_type' => 'ssi_models', 'category' =>  $Cat_ID , 'orderby' => 'rand', 'posts_per_page' => -1  ) );
						$photos = get_posts( array('post_type' => 'ssi_photos', 'category' =>  $Cat_ID , 'orderby' => 'rand', 'posts_per_page' => -1  ) );
						$videos = get_posts( array('post_type' =>  'ssi_videos' , 'category' => $Cat_ID , 'orderby' => 'rand', 'posts_per_page' => -1  ) );
						$requests = get_posts( array('post_type' =>  'ssi_requests' , 'category' => $Cat_ID , 'orderby' => 'rand', 'posts_per_page' => -1  ) );
						$movies = array_merge( $models, $blogs, $photos, $videos, $requests );
						
					//	shuffle($movies);
						
					//	$movies = array_slice($movies, 0, 5);
										
						
							
							//print_r( $music );
							echo "<h4>Recent Updates</h4>";

		echo "<div id='mid'>";
							foreach($movies as $post){ ?>
							
					
						<div class='hidden1 report'>
							
							<div class='col-sm-2 hidden'>
								
							<?php	//echo get_the_post_thumbnail( $post->ID , array(50,50) ); ?>
							
							<?php

								if( has_post_thumbnail( $post->ID ) ){
									
									echo get_the_post_thumbnail( $post->ID );
									
								}else{
									echo "<img class='floatl margin10' width='175' src=" . z_taxonomy_image_url($categories[0]->term_id) . " />";
								}
							?>
							
							</div>
							
							<div class='col-xs-10'>
							
								<div class='artist'>
								<a href='<?php echo home_url() . "/" . $post->post_name; ?>'>
							<?php	echo $post->post_title; ?></a>
							<br>
							<small>by <?php 
								$user = get_user_by('ID' , $post->post_author);
							
								//print_r( $user );
							echo $user->display_name; ?></small>
								</div>
							</div>
							
							<?php
							?>
							
							<div class='col-xs-2'>
							<a href='<?php echo home_url() . "/" . $post->post_name; ?>'>	
							
							  
							  <span class="hidden1 glyphicon glyphicon-play"></span> 
							
							</a>
							</div>
							
							
							
									<div class='clear'></div><hr>
						</div>
					
							<?php
							}
		
						?>
						<div id="newpost" style='display: none;'>
				<center>
					<button id='newpost' class='btn btn-block btn-success'> New Post </button>
				</center>
				</div>
			</div>		
					
	</div>
		

		<?php if ( have_posts() ) : ?>

			<header class="">
				<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</header><!-- .page-header -->

			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				 
			?>
			<div class='well'>
			<?php
				get_template_part( 'template-parts/content', get_post_format() );
			?>
				<div class='clear'></div>
			</div>
			<?php
			// End the loop.
			endwhile;

			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentysixteen' ),
				'next_text'          => __( 'Next page', 'twentysixteen' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			//get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
		
		
	</div><!-- .content-area -->
<div id="" class="col-md-4">
<?php get_sidebar(); ?>
</div><!-- .content-area -->
<?php get_footer(); ?>
