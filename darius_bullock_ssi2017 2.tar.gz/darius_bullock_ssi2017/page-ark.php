<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 

get_header('network'); ?>
 <style>

	hr{
		margin: 10px 0;
	}

 </style>

<section class='splash1'>

	
	<img class='hidden1' src='http://dlfreakfest.org/wp-content/uploads/2018/08/DLFreakFest-Splash-2018-free.png
	'>
	
	
	<div class="col-xs-12 text-center">
		<?php // echo do_shortcode('[wpmem_form login]'); ?><hr>
		<?php //echo do_shortcode('[wpmem_form register]'); ?>
		
		<?php 
			
			if(is_user_logged_in()){
				?>
				
				<?php
				
				
			}else{
				?>
				<a href='/'>Home</a> | 
				<a href='/members'>Members</a> | 
				<a href='/events'>Events</a>
				<!--
				
				 |
				<a href='/blog'>FliXXX</a> | 		
				<a href='/freak-now'>Freak Now!</a>
				-->
				<?php
				
			}
		
			
		
		
		?>
		<br>
		
		<?php 
			
			if(is_user_logged_in()){
				
				get_template_part( 'content' , 'members' ); 
				
			}else{
				
				get_template_part( 'content' , 'member-area' ); 
			}
		
			
		
		
		?>
	</div>
	<div class='clearfix'></div>
</section>

<div class='clearfix'></div>




<?php get_footer('kik'); ?>
