<div class="clear"></div>
<section class='portfolio'>
	
		<div class='container'>
		<div class='hidden'>
			<div class='col-xs-6'>
				<h2>#SSIPortfolio</h2>
			</div>	
			<div class='col-xs-6'>
				<button id='portfolio' class='btn btn-lg btn-default btn-section'>View / Hide</button>
			</div><div class='clearfix'></div>
			<hr>
		</div>
			
			
	<div id='portfolio' style=' display: block;'>	
		
		<div class="col-sm-6">
			<h2>#SSIPortfolio</h2><hr>
			
			<a href='/projects/' class='btn btn-lg btn-info btn-block'>Current Projects</a>
			<a href='/projects/' class='btn btn-lg btn-info btn-block'>Completed Projects</a>
			<a href='/blog/' class='btn btn-lg btn-info btn-block'>Our Blog</a>
			<a href='/gallery/' class='btn btn-lg btn-info btn-block'>Our Gallery</a>
		</div>
		
		<div class="col-sm-6">
			<h2>#SSISupport</h2><hr>
			
			<a href='http://www.gofundme.com/TYMassage' class='btn btn-lg btn-info btn-block'>Support Our GoFundMe</a>
			<a href='/support/#wishlist' class='btn btn-lg btn-info btn-block'>View Our Wishlist</a>
			<a href='/support/' class='btn btn-lg btn-info btn-block'>Visit Our Support Page</a>
			<a href='/deals/' class='btn btn-lg btn-info btn-block'>Support Our Affiliates</a>
		</div>
		
		</div><!--  #portfolio  -->
	</div><!--  #container  -->
	</section>
<div class="clear"></div>