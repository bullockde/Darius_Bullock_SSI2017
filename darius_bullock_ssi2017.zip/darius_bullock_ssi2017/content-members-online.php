<div class='clearfix'></div>
		
		<div class="clear bg-blue">
			
			<center><?php  /*dynamic_sidebar('home-ad-slot');*/ ?></center>
			<center>
				
				<?php 
					if( /*is_page('kik')*/ 1 ){
					if ( bp_has_members( 'type=active&max=5' ) ) : ?> 
					<h2>Members Online</h2>
					<?php while ( bp_members() ) : bp_the_member(); ?>                      
						<a href="/user-profile/?ID=<?php echo bp_get_member_user_id(); ?>">
							<?php bp_member_avatar('type=full&width=55&height=55') ?>
						</a>
						
					<?php endwhile; ?>
					<br>
				<?php endif; 
				
					}
					?>
			</center>
			<div class='clearfix'></div><br>
		</div>

		
	<div class="clear"></div>