<div class='profile-social text-center hidden1'>
			<?php 
			
			$args = array(
				'author'        =>  $user->ID,
				'post_type'		=> 'ssi_requests',
				'orderby'       =>  'modified',
				'post_status' => 'publish',
				'order'         =>  'ASC',
				'posts_per_page' => -1
				);
			$requests = get_posts( $args );
			//echo count($requests); ?>
			<hr><h3><u><?php echo count($requests); ?></u> Requests</h3><hr>
		</div>

		<?php
		
			foreach( $requests as $request ){
		?>
		<div class='well'>
		<div class='col-md-4 text-center'>
		<br><br>
		<?php 
				
				//echo get_field( "request_status", $request->ID, true );
			//print_r($request);
					$selected = get_field( "MX_user_consent", $request->ID );
			
			if( has_post_thumbnail( $request->ID ) ){
				echo get_the_post_thumbnail( $request->ID , 'thumbnail', array( 'class' => 'circle' )  );
			}else{
				echo get_avatar( $user->ID );
				
			}
	
			?><br><br>
		</div>
		<div class='col-md-8 text-center'>
		
			<div class='row'>
				<div class='col-md-6'>
					<?php
						if( get_field( "request_date", $request->ID ) ){ echo "<b><u>Date</u></b><br>" . get_field( "request_date", $request->ID ); }
						
						?>
				</div>
				<div class='col-md-6'>
					<?php
						if( get_field( "request_time", $request->ID ) ){ echo "<b><u>Time</u></b><br>" . get_field( "request_time", $request->ID ); }
					?>
				</div>
				<div class='clearfix'></div>
			</div>
		
				<div class='clearfix'></div>
				<?php
				if( get_field( "request_length", $request->ID ) ){ echo "<br><b>" . get_field( "request_length", $request->ID ); }
				?></b>
				<br>
				(<?php
				if( get_field( "request_interest", $request->ID ) ){ echo "" . get_field( "request_interest", $request->ID ) . ""; }
				
				?>)
				<?php
				echo "<br><br><b><u>Fantasy</u></b><br>" . $request->post_content;
				
			?>
		</div>
			<div class='clear'></div>	<br>
			<a target='_blank' href='/?p=<?php echo $request->ID; ?> ' class='btn btn-lg btn-default btn-block pulse hidden1'> View Request &rarr; </a>
		
		</div>
		
		<div class='clear'></div>	
		<?php
			}
		?>
		
		<a target='_blank' href='/thot-request' class='btn btn-lg btn-success btn-block pulse hidden1'> Make A Request &raquo; </a>
		