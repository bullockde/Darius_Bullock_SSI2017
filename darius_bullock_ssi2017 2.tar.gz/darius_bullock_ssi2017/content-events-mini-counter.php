	
			
			
						<?php
						$past_events = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					   'post_type' => 'ssi_events',
					   
					   'category_name' => 'past-events',
						'order' => 'desc',

					)     );
					
					$upcoming_events = get_posts( array (  
											
										   'posts_per_page'         =>  -1,
										   'post_type' => 'ssi_events',
										   'category_name' => 'upcoming-events',
										   'meta_key'               => 'event_date',
											'order' => 'asc', 

										)     );


				?>
		
							
				

				<div class='col-sm-8 col-sm-offset-2 text-center hidden1'>
					
					<h2 class='text-center'> Events </h2><hr>
					
					<div class='col-xs-6 h3  well hidden1'>
						<h4>Upcoming</h4>
						
							<h1><?php echo count($upcoming_events); ?></h1>
						
					</div>
					<div class='col-xs-6 h3 well hidden1'>
						<h4>Completed</h4>
						
							<h1><?php echo count($past_events); ?></h1>
						
					</div>
						
			<div class="clear"></div>
			
				</div>
			
			<div class="clear"></div>