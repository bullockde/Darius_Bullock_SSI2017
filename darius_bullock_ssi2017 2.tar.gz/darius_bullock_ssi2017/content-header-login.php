<style>
	.bg-blue {
		background: radial-gradient( #173e9a, #000000)  !important;
		border-top: 3px solid #000;
		border-bottom: 3px solid #000;
		padding: 1em 0 0;
		color: #fff;
	}
	.pb-5 {
		padding-bottom: 1em !important;
	}
	button, input, select, textarea {
		font-family: inherit;
		font-size: inherit;
		line-height: inherit;
	}
	#header-login input {
		line-height: normal;
		width: inherit !important;
		font-size: 12px;
	}




	button, input, optgroup, select, textarea {
		margin: 0;
		font: inherit;
		color: inherit;
	}
	button, input {
		overflow: visible;
	}
	button, input, optgroup, select, textarea {
		margin: 0;
		font-family: inherit;
		font-size: inherit;
		line-height: inherit;
	}
</style>

	<div id='header-login' class='text-center bg-blue pb-5 <?php if( !is_user_logged_in() && !is_front_page() ){ echo 'mb-15'; } ?>' style='display: block;'>
	
	
	
		
		<?php
			if( !is_user_logged_in() ){
		
			$redirect_to = '/';
		?>
		<form name="loginform" id="loginform" action="<?php echo site_url( '/wp-login.php' ); ?>" method="post">
			<span class="hidden-xs">&nbsp;&nbsp; Member Login: </span>
			

			<input id="user_login" placeholder="Username" type="text" size="10" value="" name="log">
			<input id="user_pass" placeholder="Password" type="password" size="10" value="" name="pwd">
			<input id="rememberme" type="checkbox" value="forever" name="rememberme">
			<input id="wp-submit" class="btn btn-primary" type="submit" value="Login" name="wp-submit">

			<input type="hidden" value="<?php echo esc_attr( $redirect_to ); ?>" name="redirect_to">
		</form>
		 <?php
		
		
			}else{
				
				?>
				
				<h4><b><?php if( is_user_logged_in() ){  $current_user = wp_get_current_user(); echo 'Welcome Back, ' . strtoupper($current_user->user_login) . '!'; }else{ echo "<b>Welcome, " . $_COOKIE['name'] . "!</b>";}  ?></b></h4>
				<?php
				
			}
		?>

	</div>