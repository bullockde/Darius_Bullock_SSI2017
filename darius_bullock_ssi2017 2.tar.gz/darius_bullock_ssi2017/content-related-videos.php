<div id='related' class='posts'>
									<hr><h2 class="post-title text-center well blue-bg">Related Videos</h2><hr>
								
									<?php if( in_category( "Straight Porn" ) ){

          $args = array( 'category_name' => 'Straight Porn' , 'numberposts' => 8 , 'orderby' => 'rand' );

}
else if( in_category( "Gay" ) ) {

          $args = array( 'category_name' => 'Gay' , 'numberposts' => 8 , 'orderby' => 'rand' );

}else{ 

	   $args = array( 'numberposts' => 6, 'orderby' => 'rand' );
            
}

	if( 1 ) { 

         $args = array( 'post_type' => 'ssi_videos' , 'numberposts' => 8 , 'orderby' => 'rand' );

	}

	$rand_posts = get_posts( $args );

            foreach( $rand_posts as $post ) : ?>

				<div class="col-xs-6">
					<?php get_template_part( 'content', 'post' ); ?>
					
				</div>

			<?php endforeach; ?>

								</div>
								
		<div class='clearfix'></div>	<br>


			<div class='ads ad-shift img-thumbnail col-md-8 col-md-offset-2'>
				<center>
					<?php get_template_part('ad', '728-90'); ?>
				</center>
			</div>
		
			
			

		<div class='clearfix'></div>	