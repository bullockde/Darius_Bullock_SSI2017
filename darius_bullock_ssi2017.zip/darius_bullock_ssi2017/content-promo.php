						

<div class='upcoming-events text-center'>

<?php

$upcoming_events = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					   'post_type' => 'ssi_events',
					   'category_name' => 'upcoming-events',
					   'meta_key'               => 'event_date',
						'order' => 'asc',

					)     );
	
?>

<div class="clear"></div>

	




		<?php 
					$found = 0;
					
					$count = 0;
					
					$cancelled = false;
					
					foreach( $upcoming_events as $lead ){
						
						if( get_field('event_cancelled', $lead->ID ) == "Yes" )  { $cancelled = true; }else{ $cancelled = false; }
						
						
					if( $count == 0 ) { 
					
						
						
						
						?>
			
	<div class='col-md-10 col-md-offset-1 text-center hidden1'>		
		
		

		<div class='border flyer flyer-bg well'>
		
		<?php if( $cancelled )  { echo "<div class='alert-danger h2'> Event CANCELLED!! </div><br>"; } ?>
		
		 <h3 class="entry-title" <?php if( $cancelled )  { echo "style='text-decoration: line-through;'"; } ?>><?php 
		 
		 
		 echo $lead->post_title; ?><hr></h3>
		 	<div class='clear'></div>
			
	<div class='col-sm-6 '>		
			
			
			<a href='/<?php echo $lead->post_type; ?>/<?php echo $lead->post_name; ?>' class=''><?php echo get_the_post_thumbnail($lead->ID); ?> </a>
			
			<div class='clear'></div>
		
				<a href='/<?php echo $lead->post_type; ?>/<?php echo $lead->post_name; ?>' class='hidden btn btn-rsvp btn-default btn-lg btn-block'> Full Details </a>
			
	</div>		
	<div class='col-sm-6  '>	
	
		<div class='  well yellow'>	
			<div class='col-xs-6 '>
						<h4><u>Date</u></h4><span <?php if( $cancelled )  { echo "style='text-decoration: line-through;'"; } ?> class=' orange'> <?php date_default_timezone_set("America/New_York"); 

						echo date("M jS", strtotime(get_field('event_date', $lead->ID)));
						?> </span>
														
														
					</div>
					<div class='col-xs-6 '>
						<h4><u>Time</u></h4><span <?php if( $cancelled )  { echo "style='text-decoration: line-through;'"; } ?> class='orange'><?php echo get_field( 'event_time', $lead->ID ); ?></span>
					</div>
					<div class='clear '></div>
						
						<h3><u>Location</u> <br> 
				
				<?php 
						//echo get_user_meta( $current_user->ID , 'show_location' ,  1);
				
					if( 1 /*get_user_meta( $current_user->ID , 'show_location' ,  1) == 'true'*/ ){
						?>
						<h6 <?php if( $cancelled )  { echo "style='text-decoration: line-through;'"; } ?>><?php echo get_field( 'event_location', $lead->ID ); ?></h6>
						
						<?php
					}else{
						?>
						<br>
						<button id="address" class="btn btn-default">Show Location</button>
						<?php
						
					}
				?>
				
				
				
				<div id="address" class="col-xs-12  " style="display:none;">
		<div class="well">
				
		<form method='get'>
				<h4><center>For FULL Location</center></h4>
			<h3><center>Enter Your Phone#:</center></h3>
			<small>- We will NOT share your Phone# -</small><hr>	
				
			<div class=' col-xs-12'>
				 <input type='phone' name='MX_user_phone' placeholder='1-555-555-5555' required>
				
<!--				
				 <input name='username' type='hidden' value='<?php echo $current_user->display_name; ?>'>
					<input name='userID' type='hidden' value='<?php echo $current_user->ID; ?>'>
					
					<input name='mystery' type='hidden' value='true'>
					<input name='update' type='hidden' value='true'>
-->					
					<input name='show_location' type='hidden' value='true'>
					<input type='submit' value='Show Location' class='btn btn-success btn-block btn-lg'>
			</div>
			
		</form>
		<div class='clear '></div>
		</div>
		
		
		</div>
				
				<?php //echo get_field( 'event_location', $lead->ID ); ?>
				
				<!--<small>(Doors close at 3am)</small>-->
				
				
		
		<br>
		<h4><u><?php the_field('event_rsvps', $lead->ID); ?></u> RSVP's</h4>
			<div class='clear'></div>
				<?php $rsvps = get_field( 'event_rsvps' , $lead->ID); 
						$max_guests = get_field( 'event_max_guests' , $lead->ID);
						$seats = $max_guests - $rsvps;
					
					?>
					( <u><?php echo $seats; ?></u> Slots Left ) <br>
		
		<!--
		( <u><?php the_field('event_showed', $lead->ID); ?></u> Here Now! )
		-->
		<?php //echo get_field( 'event_price' , $lead->ID); ?>
		<br>
		
		<a href='/<?php echo $lead->post_type; ?>/<?php echo $lead->post_name; ?>' class='hidden1 btn btn-rsvp btn-default btn-lg1 btn-block'> Full Details </a>
		</div>


			
		<div class='clear'></div>
		
				
				
				<a href='/<?php echo $lead->post_type; ?>/<?php echo $lead->post_name; ?>' class='btn btn-success btn-lg btn-block'><br> Quick RSVP >> <br><br></a>
				<!--
					
						<a target='_blank' href='/rsvp?event=event<?php echo $lead->ID; ?>' class='btn btn-success btn-lg btn-block'> Quick RSVP >> </a>
				
			-->
		<div class='clear'></div>
		
	</div>	
	
		<div class='clear'></div>
		
		
		
			<div class='clear'></div>
			<div class='col-xs-12  text-center'>		
			
				<hr> Official Event Flyer <hr>
				<center>
					<img src='<?php echo get_field( 'event_flyer' , $lead->ID ); ?>' class=' img-responsive'>	
				</center>
				
				<div class='clear'></div><br>
			</div>	


		
		</div>
		
		</div>
						
						<div class='clear'></div><hr><br>
						
						
	</div>					<?php 
					
					
					}
					

						
						?>
						
						
						<div class='clear'></div>
						

						
	<?php } ?>
	
	
</div>	


	<div class='clearfix'></div>