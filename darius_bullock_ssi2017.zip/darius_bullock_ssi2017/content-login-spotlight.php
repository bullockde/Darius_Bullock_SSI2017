	<div class='col-md-5 spotlight  hidden1 text-center mb-0'>
		
			<?php //get_template_part( 'ad', '300-250-1' ); ?>
			
			<div class='well'><a href='/members/'>#SSIMembers</a></div>

			<?php if( /*!is_user_logged_in()*/ 1 ){ ?>
				
				<div id='loginform'>
					<a href='/register/' class='btn btn-lg btn-info btn-block hidden'>Register Now</a>
					<button id='loginform' class=' btn btn-lg btn-info btn-block'>Register Now</button>
					<button id='loginform' class=' btn btn-lg btn-info btn-block'>Login</button>

					<button id='whatsnew' class=' btn btn-lg btn-danger btn-block'>Random Button</button>
				
				
								<div id='whatsnew' class='random well' style='display: none;'>
		<?php
				query_posts(array( 'post_type' => array( 'ssi_videos' , 'ssi_photos', 'post'  ) , 'orderby' => 'rand', 'showposts' => 1 ));
				if (have_posts()) :
				while (have_posts()) : the_post(); 
		?>
				
				<div class='text-center'>
				
			

				<?php
					$format = get_post_format( get_the_ID() );

					if( $format == 'video' || in_category( 'music' , get_the_ID() ) || in_category( 'songs-that-touch-the-soul' , get_the_ID() ) ){
					//get_template_part( 'content', 'video' );
					}else{
						?>
						
						<h3 style="color:#000;"><?php the_title(); ?></h3>
						
						<center><?php the_post_thumbnail(); ?></center>
						<?php //the_post_thumbnail();

							//get_template_part( 'content', 'video' );

							the_content(); 
						?>
						
						<h1><a  href='<?php the_permalink() ?>' class='btn btn-info btn-lg btn-block hidden1'>Learn More >></a></h1>
						
						
						
					<?php
					//get_template_part('template-parts/content' , 'page');
					//the_content(); 
					}
				?>
				</div>
				
				

	<?php endwhile;
		endif;

		//wp_reset_query();
		?>
		
		</div>
				
				
				</div>

				<div id='loginform' class=' well ' style='display: none;'>
					<?php //echo do_shortcode("[wpmem_form register]"); ?><br>
					<?php echo do_shortcode("[wpmem_form login redirect_to='/members']"); ?>
					
				</div> 
					<?php }else{ ?>
					<a href='/activity/' class='btn btn-lg btn-info btn-block'>Member Activity</a><br>

						<a href='/members/' class='btn btn-lg btn-info btn-block'>View All Members</a><br>
					<?php } ?>

		</div><!--  #members  -->