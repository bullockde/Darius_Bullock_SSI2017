<?php
		
	$post_type = array( "ssi_projects", "ssi_brands" );
	
			$args = array( 

				'post_type' => $post_type,
				'posts_per_page' => 6,
				'orderby' => 'rand'

			 );
			
			$leads = get_posts( $args );
				
		
		
		$count = 0;
			
			foreach($leads as $brand){
				?> 
			<a href="<?php echo get_field('website_link', $brand->ID ); ?>" target="_blank">
				<div class='  col-md-4 col-sm-6 well'>
				<div class='col-md-12 '> 
					
					<center>
					<?php
					    if( has_post_thumbnail() ){
						    echo get_the_post_thumbnail( $brand->ID , 'thumbnail', array(
							'class' => 'circle'

							) );
					    }else{
					        
					        ?>
							
                                <img width="150" height="150" src="http://dlfreakfest.org/wp-content/uploads/2019/11/dlfreakfest-default-avatar-150x150.jpg" class="circle wp-post-image" alt="">					   
                                
                        <?php
					    }
					    
					    
						echo "<h4>" . $brand->post_title . "</h4> ";
						
						  if( count($brand->post_excerpt) <= 2 ){
						    ?>
							
                            - #SSIxXx Partners -                                 
                        <?php
					    }else{
					        echo "<small>" . $brand->post_excerpt . "</small>";
					        
					    }
					    
					    
					    
					
					
					?>
					
					</center>
					
				</div>
				
				<div class='col-md-12 hidden '> 
				<?php
					
					//echo get_the_post_thumbnail($brand->ID);
					
				?>
					
						
				<div class='col-xs-5'>
				<b>Last Activity:</b>
				
				</div>
				<div class='col-xs-7'> 
					<?php echo date('M d, Y' , strtotime($brand->post_modified)); ?>
					
				</div>

					<div class=' clear'></div>
				<div class='col-xs-5 hidden'>
				<b>Project Contact:</b>
				
				</div>
				<div class='col-xs-7 hidden'> 
					<a href="<?php echo get_field('project_contact_link', $brand->ID ); ?>" target="_blank"><u><?php echo get_field('project_contact', $brand->ID ); ?></u>
					
				</div>
				<div class='clear'><br></div>
				<div class=' clear'></div>
				<div class='col-xs-5'>
				<b>Website Link:</b>
				
				</div>
				<div class='col-xs-7'> 
					<u><?php echo get_field('project_link_title', $brand->ID ); ?></u></a>
					
				</div>
				
				<div class=' clear'></div>
				<div class='col-xs-5 hidden'>
				<b>Project Dates:</b>
				
				</div>
				<div class='col-xs-7 hidden'> 
					<?php echo get_field('project_start_date', $brand->ID ); ?>
					 -- <?php if( get_field('project_start_date',$brand->ID ) != 'on-going' ){ echo "Current";}else{ echo get_field('project_end_date', $brand->ID ); } ?>
					
				</div>
				
				<div class='clear'><br></div>
					<div class=' clear'></div>
				<div class='col-xs-5'>
				<b>Hashtags:</b>
				
				</div>
				<div class='col-xs-7'> 
					<?php 
					$posttags = get_the_tags($brand->ID);
					if ($posttags) {
					  foreach($posttags as $tag) {
						echo $tag->name . ' '; 
					  }
					}
				
				?>
					
				</div>
					<div class=' clear'></div>
				
		<!--		<div class='col-md-5'> 
				<b>Highlights:</b>
				</div>
				<div class='col-md-7'> 
					<?php echo get_field('project_budget', get_the_ID() ); ?>

				</div>
		
				<div class='clear'><br></div>
				<div class='col-md-12'>
				<a href='/web' class='btn btn-default'> Web Hosting </a>
				
				</div>
		-->			<div class='clearfix'></div>
					
				</div>
				<div class='clearfix'></div>
				<a target='_blank' href='<?php echo get_field('project_link', $brand->ID ); ?>' class='btn btn-info btn-block hidden'>View Project >> </a>
				
				</div></a>
			
				
				<?php
				$count++;
				/*if( ($count % 1) == 0 ){ 
				?> <div class='clear'><hr></div> <?php 
				}*/
			}

?>
<div class='clearfix'></div>

	<a href='/projects' class='btn btn-lg btn-success btn-block pulse h2' > <br>View All &rarr; <br><br></a>
	
<div class='clearfix'></div><br>
