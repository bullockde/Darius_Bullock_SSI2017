<?php get_header(); ?>
    

<?php get_template_part('content-people'); ?>

        <div class="clear"></div>
     
	
    <?php get_template_part('home-members'); ?>
	
<?php get_footer(); ?>