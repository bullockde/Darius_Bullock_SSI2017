<div class='clearfix'></div>

<section id='jumbo' class='about <?php if( !is_front_page() ){ ?> page-pad <?php } ?>'>
		
		<div class='container'>
		
		<?php if( !is_front_page() ){ ?> <h2>About Us</h2><hr> <?php } ?>
			<div class="col-md-6">
				
				<a href='/inc' target='_blank'> <img class='img-responsive aligncenter' src='/wp-content/uploads/2023/05/D274E60A-B0D1-4776-94A8-B9DB4F16F46C.jpeg'></a>
				<!--/wp-content/uploads/ShamanShawnInc-2017-snip-e1490062901804.jpg-->
			</div>
			
			<div class="col-md-6">
				
				<a href='/about/'><div class='btn col-xs-12'>ABOUT</div></a>
				<a href='/services/'><div class='btn col-xs-12'>SERVICES</div>	</a>
				<a target='_blank' href='/blog'><div class='btn col-xs-12'>BLOG</div></a>
				<a href='/contact'><div class='btn col-xs-12'>CONTACT</div></a>
				
			</div>
		</div>
	
	</section>

<div class='clearfix'></div>