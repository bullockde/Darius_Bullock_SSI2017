	<div class='clear'></div>
	<section id='services' class='services'>
	
		<div class='container'>
			
			<div class='row'>
			<div class='col-xs-6'>
				<h2>#SSIServices </h2>
			</div>	
			<div class='col-xs-6'>
				<button id='services' class='btn btn-lg btn-default btn-section'>View / Hide</button>
			</div><div class='clear'></div>
			<hr>
		</div>
			
			
	<div id='services' style=' display: block;'>
			<div class="col-sm-3">
				<h3>Massage Therapy</h3>

				<a href='/services/#massage' class='btn btn-lg btn-info btn-block'>Learn More</a>
				
			</div>
			
			<div class="col-sm-3">
				<h3>Computer Services</h3>
			
				<a href='/services/#computer' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>
			<div class="col-sm-3">
				<h3>Life Coaching</h3>
				
				<a href='/services/#coaching' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>
			
			<div class="col-sm-3">
				<h3>Maid Services</h3>
			
				<a href='/services/#maid' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>

			<!--<br class='visible-xs'>-->

			<div class="col-sm-3">
				<h3>Marketing & Branding</h3>
				
				<a href='/services/#marketing' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>
			
			<div class="col-sm-3">
				<h3>Event Planning</h3>
			
				<a href='/services/#events' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>
			<div class="col-sm-3">
				<h3>Property Management</h3>
				
				<a href='/services/#makeup' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>
			
			<div class="col-sm-3">
				<h3>& Much More</h3>
			
				<a href='/services/#more' class='btn btn-lg btn-info btn-block'>Learn More</a>
			</div>
			</div><!-- #services -->
		</div><!-- #container -->

	</section>
	<div class='clear'></div>