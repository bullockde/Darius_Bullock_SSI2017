<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

    <head>

       <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php bloginfo( 'name' ); ?> | Adult Social Network by #TheNewSSI</title>
		<meta name="robots" content="noindex">
	
		<meta name="description" content="MAN-X-SCAPE is the most diverse Adult Social Network for Gay, Straight, and Transgender dating and hookups, FREE Porn, Adult Events and Sex Parties, Adult Entertainment and more...">
		<meta name="keywords" content="music videos, news, entertainment, gay porn, straight porn, porn, bisexual, transexual porn, tranny, transgender, gay personals,online dating, homo , homosexual, homo sexual, FTM, MTF gay guys,International,  black man, gay pride, gratis,  group, web cam, chat rooms,  dating, gay chat,New York City, Los Angeles, Toronto, London, Philadelphia, Miami, Chicago, Montreal, Milan, Rome, Denver, Washington D.C., Atlanta, Seattle, Vancouver, San Diego, England, Florida, Baltimore, NYC, San Francisco, Bay Area, Boston, Berlin, Fort Lauderdale">
		<meta property="og:image" content="http://man-x-scape.com/wp-content/uploads/2017/03/man-x-scape-lrg.jpg">
		

        <meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
        <meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
        <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
        <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        

		<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">
   
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>  
	<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
   <script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>    	

	
	
	<script src="  https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
	
        
		
        <?php wp_head(); ?>
		

		
<!-- Google Analytics Code -->		
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-64309065-4', 'auto');
  ga('send', 'pageview');

</script>
<!-- END Google Analytics Code -->			

	

    <!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
	


	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/bootstrap-playground.css">
	
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![//if]-->
		<script src='https://www.google.com/recaptcha/api.js'></script>
		


</head>

    <body data-spy="scroll" data-target="#my-navbar">

    <header class='header gold text-center'>
      
		<br>
	<!--	<img src='/wp-content/uploads/2017/03/gold-diggers.png' width='200'>-->
		<br>
      <h1>Gold Diggers Entertainment</h1>
	  
	  <br><br>
    </header>
	
	
    

 <!-- Navbar --> 
		<nav class=' navbar-default text-center main-nav hidden'  id='my-navbar'>
			<div class="container ">
				<div class="navbar-header">
					<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#navbar-collapse'>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
					</button>
					
					<a href="" class='navbar-brand visible-xs'>Menu</a> 
					
				</div><!-- // navbar-header -->


				
				<div class="collapse navbar-collapse" id='navbar-collapse'>
			
			
					
					<div class=" visible-xs ">
						<a href="/people" class="btn btn-default visible-xs btn-block ">Member Login</a>
						<a target='_blank' href="/register" class="btn btn-danger visible-xs btn-block">Join Now (FREE) >></a>
					
					</div>
				
				</div>
			</div><!-- // container -->
		</nav><!-- // Navbar -->