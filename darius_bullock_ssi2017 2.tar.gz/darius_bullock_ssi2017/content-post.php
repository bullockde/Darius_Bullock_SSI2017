<div class="post  index drop-shadow curved curved-vt-2" id="post-<?php the_ID();  ?>" >
	
	<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
		<div class='well 1blue img-thumbnail col-xs-12'>					
				

						
			<div class="hover-img">
				<center>
					<a target="_blank" href="/?p=<?php the_ID();  ?>" >
						<div class='col-xs-12 text-center'>
							<?php
								if(get_field('youtube_id', $lead->ID)){
									?>
										<center>
											<img src="http://img.youtube.com/vi/<?php echo get_field('youtube_id', $lead->ID); ?>/0.jpg" alt="Youtube Image"  class="1circle img-thumbnail img-responsive" width="100%">
										</center>
									<?php
								}else if( has_post_thumbnail() ) { //the post does not have featured image, use a default image
									$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );
									?>
									<img src='<?php echo esc_attr( $thumbnail_src[0] ) ; ?>' alt='Youtube Image'  class='1circle img-responsive' width='100%'>
									<?php
									echo '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
								}else{
									// echo "NO Pic!";
									?>

									<img src="http://instaflixxx.com/wp-content/uploads/2013/12/play.jpg" class="img-fluid" width="100%" >
									<?php
								}
							?>
						</div>
					</a>
				</center>	
			</div>
						
				

			

				<div class="link hidden1">
				
				<div class='col-xs-8'><?php
				$title = get_the_title($post->ID);
				
				//echo "..";
				//substr($title ,  17); 
				echo $title;
				?></div>
				
				<div class='col-xs-4'>
		
					<?php if ( get_post_meta($post->ID, 'video_length', true) ) : ?><div class="duration"><?php echo get_post_meta($post->ID, 'video_length', true) ?></div><?php endif; ?>

				</div>
				
				</div>
		<div class="clear"></div>
		</div>
	
	</a>
	<div class="clear"></div>
</div>		
		<div class="clear"></div>
		<!--
<center>Updated: <?php echo get_the_modified_date( $d, $post ); ?></center>-->
