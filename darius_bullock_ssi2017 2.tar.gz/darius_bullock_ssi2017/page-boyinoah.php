<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 

get_header('network'); 





?>
	


			<?php 
			
			$events = get_posts(array(  'post_type' => 'ssi_events' , 'posts_per_page' => -1 )); 
			$models = get_posts(array(  'post_type' => 'ssi_models' , 'posts_per_page' => -1 , 'orderby' => 'modified', 'order' => 'asc' , 'post_status' => 'publish' , 'category_name' => 'top-thot' ));
			$projects = get_posts(array(  'post_type' => 'ssi_projects' , 'posts_per_page' => -1 ));
			$photos = get_posts(array(  'post_type' => 'ssi_photos' , 'posts_per_page' => -1 ));
			$videos = get_posts(array( 'post_type' => 'ssi_videos' , 'posts_per_page' => -1 ));
			$thots = get_posts(array(  'post_type' => array('ssi_models', 'ssi_requests') , 'posts_per_page' => -1 , 'orderby' => 'modified', 'order' => 'asc' , 'post_status' => array('publish', 'pending') , 'category_name' => 'thots' ));
			
		?>
		
		<div class='clearfix mb-15'></div><br class="hidden-xs">
<div id="" class="">






<div class='clear'></div>
	<div id="main" class="hoody-blk" role="main">
	
	
	
	
	
	
	<center>
		<h3>Gay Underwear Modeling</h3>
		<div class='clearfix'></div><br>
		<?php

		$thumb_id = get_post_thumbnail_id();
		$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail-size', true);
		$thumb_url = $thumb_url_array[0];
?>
        <div class="col-md-6 col-md-offset-3 ads ad-shift img-thumbnail">
		    <img src='<?php echo $thumb_url; ?>' class='img-thumbnail'>
		</div>
<?php
		 if( is_page( array('resume', 'contact', 'gallery', 'subscribe') ) ){

		 }else if ( $thumb_url == 'http://shamanshawn.com/wp-content/uploads/Home2016-featured.png' ){


		} else { 

		
				//twentysixteen_post_thumbnail(); 
			
		}

	?></center>
	

	<br>
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			//get_template_part( 'template-parts/content', 'page' );

	
?>

<div > 











				 

	<div class='well  text-center col-sm-6 col-sm-offset-3'>
		
		<div class=' video'>
				
					<?php
			
					echo get_the_content( get_the_ID() );
					
				$args = array( 'numberposts' => 1, 'post_type' => 'ssi_models' , 'orderby' => 'modified', 'order' => 'desc' , 'post_status' => 'publish' , 'category_name' => 'hoody' );
				$recent_posts = wp_get_recent_posts( $args );
				
				//print_r($recent_posts);
				
				foreach( $recent_posts as $recent ){
					
					//print_r($recent);
					?> 
					<h4>- Newest Model -</h4>
					
					<?php echo get_the_post_thumbnail( $recent["ID"] , 'medium' ); ?> 
					<br><br>
					<b><u>Name</u></b><br>
					<?php echo  $recent["post_title"]; 
					
					?>
					<br><br>
					<b><u>Location</u></b><br>
					<?php
					echo get_post_meta( $recent["ID"] , 'MX_user_city' ,1 );
					?>, 
					<?php
					echo get_post_meta($recent["ID"] , 'MX_user_state' , 1);
					?>
					<br><br>
					<b><u>His Fantasy</u></b><br><br>
				
					<?php
					echo $recent["post_content"];
					
					
					?>
					<br><br>
					<b><u>Status</u></b><br>
					<?php				
					//echo --$count;
					echo "Pending";
					//echo $lead->post_title;
					//echo "";
				?>
					<?php
					
				}
				wp_reset_query();
			?>
			</div>
	<div class='clearfix'></div>
	
	
			<?php
				$total_models = count($models);
				
				$count = count($models);
				
				foreach( $models as $lead ){
					
					if(  $count < 1 || $total_models  == $count ){ $count--; continue; }
					//if( $count < 1 ){ continue; }
					
				?>
				<div class='text-left col-xs-6'>
				<?php				
					echo $count--;
					echo " - ";
					echo $lead->post_title;
					//echo "<hr>";
				?>
				</div>
				<div class='text-left col-xs-6'>
				

					<?php
					echo get_post_meta( $lead->ID , 'MX_user_city' ,1 );
					?>, 
					<?php
					echo get_post_meta($lead->ID , 'MX_user_state' , 1);
					?>
			
				</div><div class='clearfix'></div><hr>
		


				<?php
				}
			?>
		
	<div class='clearfix'></div>
		
		<div class="stats">
						
			
			
			<?php get_template_part('content','stats');  ?>
			

								
		</div>

						

			<div class='clearfix'></div>
					
				
			
				
						
								
	
		
	<br>
		
		<center> 
			<!-- JuicyAds v3.0 -->
			<script async src="//adserver.juicyads.com/js/jads.js"></script>
			<ins id="498543" data-width="300" data-height="262"></ins>
			<script>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':498543});</script>
			<!--JuicyAds END-->	
		</center> 
		
		
		<hr><h4> Member Benefits </h4><hr>
		
		
		<p>- View All Member Profiles</p>
		<p>- Get Full Access to our Pix/Vids</p>
		<p>- Get Access to our Private Events</p>
		<p>- View Exclusive Model Content</p>
		<p>- Get Notified when we Make an Update!</p>
		<!--<p>- View My Full Model Profile</p>
		<p>- Get Full Access to My Amateur Photos</p>
		<p>- Get Full Access to My Amatuer Vidoes</p>
		<p>- Get My Personal Cell Phone #</p>
		<p>- Ask me any Question. I'll Answer!</p>-->
		<br>
		
		<div class='clearfix'></div>
		
		<div class='well'>
			<h4>Join Today - 100% FREE!</h4><hr>
			
			<a href='/dress-join' class='btn btn-success btn-lg btn-block hidden'>Join Now</a>
			<button id='join' class='btn btn-success btn-lg btn-block'>Join Now</button>
			<div id='join' style='display: none;'>
				<?php echo do_shortcode("[wpmem_form register]"); ?>
			</div>
			
			<br><h4>Already A Member?</h4><hr>
			
			<?php 
			
				if( is_user_logged_in() ){
					?>
					<a href='/profile' class='btn btn-success btn-lg btn-block'>Enter Here >></a>
					<?php
				}else{
					?>
					<button id='login' class='btn btn-success btn-lg btn-block'>Login Here</button>
			<div id='login' style='display: none;'>
				<?php echo do_shortcode("[wpmem_form login redirect_to='http://ssixxx.com/profile/']"); ?>
			</div>
					<?php
				}
			?>
			
			
		</div>
		
	</div>
	<div class='clearfix'></div>
	
 

</div><!-- #post-## -->

	</div><!-- // container -->

		

<?php 		
			
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>

	</div><!-- .site-main -->

	<?php //get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->
	<div class='clearfix'></div>
	
	
	
	
	<div class="entry-content">
		<?php
		the_content();

		wp_link_pages( array(
			'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
			'after'       => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
			'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
			'separator'   => '<span class="screen-reader-text">, </span>',
		) );
		?>
	</div><!-- .entry-content -->

	<?php
		edit_post_link(
			sprintf(
				/* translators: %s: Name of current post */
				__( 'Edit<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
				get_the_title()
			),
			'<footer class="entry-footer"><span class="edit-link">',
			'</span></footer><!-- .entry-footer -->'
		);
	?>


	
	
	
<?php //get_sidebar(); ?>
<?php get_footer('members'); ?>
