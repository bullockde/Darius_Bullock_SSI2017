<div class='clearfix'></div>
<div class='well  1yellow green mb-0 container-fluid text-center' style='padding: 5px 0;'>
	<center>
	<a href='/groups' class='btn btn-sm btn-default'>Groups</a> | 
	<a href='/forums' class='btn btn-sm btn-default'>Forums</a> | 
	<a href='/events' class='btn btn-sm btn-default'>Events</a> |
	<a href='/freak-now' class='btn btn-sm btn-default pulse' style='min-width: 95px;'>Freak &raquo;</a>
	</center>
</div>
<div class='clearfix mb-15'></div>