<?php get_header(); ?>
    
	<?php get_template_part('content', 'services');  ?>

	<!-- Massage Menu -->	

		
<section >
	

	<div  class="single-post massage container">
		<div id='massage'><br><br></div>
				<div class="page-header" id="feeback">
					<h1>Massage Menu</h1>
				</div>

			
			<div class='col-md-5 col-md-offset-1'>
				<br>

			<table class='pricetable table table-bordered'>
				<tr>
					<th>Time</th>
					<th>Rate</th>
				</tr>
				<tr>
					<td>15 min</td>
					<td>$25</td>
				</tr>
				<tr>
					<td>30 min</td>
					<td>$45</td>
				</tr>
				<tr>
					<td>60 min</td>
					<td>$85</td>
				</tr>
				<tr>
					<td>90 min</td>
					<td>$120</td>
				</tr>
			
			
			</table>

				<br>
				
			<table class='pricetable table table-bordered'>
				
				<tr>
					<th colspan='2'>15 Min FIX ($25/each)</th>
					
				</tr>
				<tr>
					<td>Neck</td>
					<td>Shoulders</td>
				</tr>
				<tr>
					<td>Arms</td>
					<td>Legs</td>
				</tr>
				<tr>
					<td>Hands</td>
					<td>Feet</td>
				</tr>
				<tr>
					<td>Back</td>
					<td>Torso</td>
				</tr>
			
			
			</table>
			
			
					<a target='_blank' href="/book" class="btn btn-lg btn-block btn-danger">Book Now >></a></center>
			</div>
			<div class='col-md-4 col-md-offset-1 text-center'>
			<div class='clear visible-xs'><br><br></div>
			Advertisement<br>
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- MAN-X-SCAPE_300_600 -->
				<ins class="adsbygoogle"
					 style="display:inline-block;width:300px;height:600px"
					 data-ad-client="ca-pub-3813829909026031"
					 data-ad-slot="1933275388"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
			</div>
			<div class='clear'></div><br><br>
			

	</div><!-- // container -->
	
	
	
	
	<div  class="single-post manscape container">
		<div id='manscaping'><br><br></div>
				<div class="page-header" id="feeback">
					<h1>Manscape Menu</h1>
				</div>

			<div class='col-md-6 text-center'>
				
				<img src='/wp-content/uploads/2016/11/manscape-stats.jpg' class='img-responsive'>
			</div>
			<div class='col-md-6  text-center'>
				<br>

			<table class='pricetable table table-bordered'>
				<tr>
					<th>Upper Body ($15/each)</th>
					<th>Lower Body ($25/each)</th>
				</tr>
				<tr>
					<td>Arms</td>
					<td>Legs</td>
				</tr>
				<tr>
					<td>Torso</td>
					<td>Glutes</td>
				</tr>
				<tr>
					<td>Back</td>
					<td>Groin</td>
				</tr>
				<tr>
					<td colspan='2'>$120 Full Body Grooming</td>
					
				</tr>
			
			
			</table>

				<a target='_blank' href="/book" class="btn btn-lg btn-block btn-danger">Book Now >></a>
			</div>
			<div class='clear'></div><br><br>

	</div><!-- // container -->
	<div  class="single-post companion container">
	
		<div class='col-md-6 companionship'>
		<div id='companionship'><br><br></div>
			<div class="page-header" >
				<h1>Companionship</h1>
			</div>
			
			Looking for the perfect Boyfriend Experience with No Strings Attached?<br><br>
			Receiving genuine attention and enjoy engaging activities with a safe, charming, non-judgmental gentleman with whom you can be yourself around. Discover and learn new things, and most importantly enjoy your time together whether it be for 1 hour or 1 week!<br><br>
			<ul>
				<li>Dinner Dates</li>
				<li>Movie Dates</li>
				<li>Weekend Adventures</li>
				<li>Night Out on the Town</li>
				<li>Extended Vacations</li>
			</ul>
			<center>
			<br><small>( No Defined Rates )</small><br>
					<a target='_blank' href="/request" class="btn btn-lg btn-danger">Request A Session >></a></center>
		</div>
		<div class='col-md-6 homemaking'>
		<div id='homemaking'><br><br></div>
			<div class="page-header">
				<h1>Home Making</h1>
			</div>
			
			Tired of Running your Home alone? Never seem to get it All Finished?<br><br>
			From doing the laundry and taking out the garbage to involved things such as Cooking and Organizing that Bookshelf or Closet. Your personal Homemaker will serve as another body within the home to help you take the load off and Get More Done!<br><br>
			<ul>
				<li>Cooking</li>
				<li>Laundry</li>
				<li>Organization</li>
				<li>Light Houskeeping</li>
				<li>Grocery shopping</li>

			</ul>
			<center>
			<br><small>( No Defined Rates )</small><br>
					<a target='_blank' href="/request" class="btn btn-lg btn-danger">Request A Session >></a></center>
		</div>
		
		<div class='clear'></div><br><br>
	</div>
	<div  class="single-post companion container">
			<div id='coaching'><br><br></div>
		<div class="page-header" >
				<h1>Life & Wellness Coaching</h1>
			</div>
		<div class='col-md-5 companionship'>

			
			
			
			<iframe width="100%" height="250" src="https://www.youtube.com/embed/ZjMvqfAOVyQ" frameborder="0" allowfullscreen></iframe>
			
		</div>
		<div class='col-md-7'>
		
				My Life Coaching Program  that I refer to as "SHAME2FAME Coaching" is hand written and was developed and organized by me starting in 2015 and has evolved over time. The program is designed to Assist people in getting where "THEY Want To Go" as it relates to the  <br> 
				
				<div class='col-md-5'>
					<div class='clear visible-xs'><br></div>
					<strong>8 Major Areas of Life:</strong>

			
					<ul>
						<li>Home</li>
						<li>Career</li>
						<li>Money</li>
						<li>Health</li>
						<li>Romance</li>
						<li>Fun &amp; Leisure</li>
						<li>Friends &amp; Family</li>
						<li>Personal Growth</li>
					</ul>
				</div>
				<div class='col-md-7'>
					<br>
						<img src='/wp-content/uploads/2016/11/SHAME-results.png' class='img-responsive'>
				</div>

					
					<br>
		</div>
		
		<div class='clear'></div><center>
			<br><small>( Any Budget - Any Time )</small><br>
					<a target='_blank' href="/request" class="btn btn-lg btn-danger">Request A Session >></a></center><br><br>
	</div>
	<div  class="single-post companion container">
			<div id='healing'><br><br></div>
		<div class="page-header" >
				<h1>Healing Services</h1>
			</div>
		
		<div class='col-md-7'>
		

				Energy Healing is all about accepting that you are an energy being. A being that is much more complicated than just a physical body. A being that exists in multiple dimensions at the same time. Accepting and understanding this, we can then utilise various techniques to restore your energy flow to the optimum balance across all those dimensions.  <br> <br> 

			<strong>I Heal using a Variety of Techniques:</strong>

	
			<ul>
				<li>Reiki</li>
				<li>I.E.T</li>
				<li>Massage</li>
				<li>Meditation</li>
				<li>Energy Work</li>
				<li>Kenesthetic Healing</li>
			</ul>
					<br>
		</div>
		<div class='col-md-5'>

			
			
			<img src='/wp-content/uploads/2016/11/man-x-scape-healing.jpg' class='img-responsive'>
			
			
		</div>
		
		<div class='clear'></div><center>
			<br><small>( Any Budget - Any Time )</small><br>
					<a target='_blank' href="/request" class="btn btn-lg btn-danger">Request A Session >></a></center><br><br>
	</div>
	
	
	
</section>
		<?php get_template_part('content', 'services');  ?>
	
   
	
	
    
<?php get_footer(); ?>
