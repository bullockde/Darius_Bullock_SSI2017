<div class='clear'></div>
<div class='banner'></div>
<div class='leader' >
	
	<div class='col-md-2'>
	
		<img class='img-responsive hidden-xs ' src='http://shamanshawn.com/wp-content/uploads/SSI-Logo-Banner-New-QR.png'>
	
	</div>
	<div class='col-md-8 text-center' >

<!-- JuicyAds v3.0 -->
<script type="text/javascript" data-cfasync="false" async src="https://poweredby.jads.co/js/jads.js"></script>
<ins id="1023137" data-width="300" data-height="262"></ins>
<script type="text/javascript" data-cfasync="false" async>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':1023137});</script>
<!--JuicyAds END-->

	</div>
	<div class='col-md-2 hidden-xs hidden-sm '>
	
		<img class='img-responsive ' src='http://shamanshawn.com/wp-content/uploads/SSI-Logo-Banner-New-QR.png'>
	
	</div>
	
	<div class='clear'></div>
</div>
</div><div class='clear' ></div>
<div class='tagline text-center'>
	"Bridging the Gap between the HAVE's and the HAVE NOT's." -#SSI
</div>
	

<div class='clear'></div>