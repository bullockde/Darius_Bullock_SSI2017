<section id='blog' class='red-bg well yellow visible-xs1 visible-md1'>
	<div class='container'>
			<div class="text-center text-capitalize">
				<h2>Our <?php echo $post->post_name ; ?></h2><hr class="mb-10">
<div id='our-menu' class='well green gender-menu hidden1 mb-10'>
		<?php 
			
			$men = get_posts(array( 'category_name' => 'men', 'post_type' => 'ssi_models' , 'posts_per_page' => -1 )); 
			$women = get_posts(array( 'category_name' => 'women', 'post_type' => 'ssi_models' , 'posts_per_page' => -1 ));
			$trans = get_posts(array( 'category_name' => 'trans', 'post_type' => 'ssi_models' , 'posts_per_page' => -1 ));
			
			
		?>
			
							<div class="container">
						

								
								<div class="col-sm-4 text-center">
									
			<a target='black' href='/men'>
			<figure>
			
			
			
			  <img src="/wp-content/uploads/2016/11/man-x-scape-shawn-e1478869098864.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption><h4>(<?php echo count($men); ?>) MEN >></h4></figcaption>
			</figure>
			</a>						
								</div>
								
								<div class="col-sm-4 text-center">
									
			<a target='black' href='/women'>
			<figure>
			  <img src="/wp-content/uploads/2016/11/deep350_350-e1478869245737.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption><h4>(<?php echo count($women); ?>) WOMEN >></h4></figcaption>
			</figure>
			</a>
								</div>
						
							
								
								
								
								
								<div class="col-sm-4 text-center">
			<a target='black' href='/trans'>						
			<figure>
			  <img src="/wp-content/uploads/2016/11/reviews-1-e1478870034226.jpg" class="img-thumbnail hidden" alt="The Pulpit Rock" width="304" height="228">
			  <figcaption><h4>(<?php echo count($trans); ?>) TRANS >></h4></figcaption>
			</figure>
			</a>
								</div>
								
								
									
								
							

								
								
							</div><!-- // container -->
							<div class='clearfix'></div>
			
		</div><!-- // Gender Menu -->
				
				
				<div class='clearfix'></div>
				<div class='well filter hidden'>
					<?php 
					
						$areas = get_posts( array('category_name' => 'areas') ); 
						
						
					/*
						$term_id = 10;
						$taxonomy_name = 'area';
						$termchildren = get_term_children( $term_id, $taxonomy_name );
						
						//print_r($termchildren);

						echo '<ul>';
						foreach ( $termchildren as $child ) {
							$term = get_term_by( 'id', $child, $taxonomy_name );
							echo '<li><a href="' . get_term_link( $child, $taxonomy_name ) . '">' . $term->name . '</a></li>';
						}
						echo '</ul>';
*/
						
					
						$categories = get_categories( array(
							'parent' => 10,
							'orderby' => 'name',
							'order'   => 'ASC'
						) );
						 
						foreach( $categories as $category ) {
							$category_link = sprintf( 
								'<a href="%1$s" alt="%2$s">%3$s</a>',
								esc_url( get_category_link( $category->term_id ) ),
								esc_attr( sprintf( __( 'View all posts in %s', 'textdomain' ), $category->name ) ),
								esc_html( $category->name )
							);
							 
							echo '<p>' . sprintf( esc_html__( ' %s', 'textdomain' ), $category_link ) . '</p> ';
							//echo '<p>' . sprintf( esc_html__( 'Description: %s', 'textdomain' ), $category->description ) . '</p>';
							echo '<p>' . sprintf( esc_html__( 'Ads: %s', 'textdomain' ), $category->count ) . '</p>';
						} 
					
					?>
				</div>
 
			</div>
			<div class="well text-center">
					
					<?php
					
					//print_r($post);
$args = array(  'post_type' => 'ssi_models' , 'posts_per_page' => -1 , 'category_name' => 'approved');

		$count = 1;
		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
			<?php if( $count != 1 ){ echo "<hr>" ; } ?>
	<div class='blog-post'>
		
		<div class='col-sm-6 text-center'>
			
			<h2 class="post-title text-center"><?php the_title(); ?></h2>
			<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail('medium', array('class' => 'img-responsive aligncenter','alt' => get_the_title(), 'title' => '')); ?></a>
		</div>
		<div class='col-sm-6 text-center'>
			<div class='visible-xs'><br></div>
			
			<div class='text-center'>
				<h3><?php 
				$oldCity = get_post_meta($post->ID, 'ad_city', true);
				add_post_meta($post->ID, 'MX_user_city',$oldCity, 1 );
				$oldState = get_post_meta($post->ID, 'ad_state', true);
				add_post_meta($post->ID, 'MX_user_state',$oldState, 1 );
				echo get_post_meta($post->ID, 'MX_user_city', true); ?>, <?php echo get_post_meta($post->ID, 'MX_user_state', true); ?></h3><br>
			</div>
			<div class='clearfix'></div><br>
			
			
			<div class=' col-xs-6'>
				Age:
			</div>
			<div class=' col-xs-6'>
				<?php echo get_post_meta($post->ID, 'MX_user_age', true); ?>
			</div>
			<div class=' col-xs-6'>
				Height:
			</div>
			<div class=' col-xs-6'>
				<?php echo get_post_meta($post->ID, 'MX_user_height', true); ?>
			</div>
			<div class=' col-xs-6'>
				Weight:
			</div>
			<div class=' col-xs-6'>
				<?php echo get_post_meta($post->ID, 'MX_user_weight', true) ?>
			</div>
			
			<div class='clearfix'></div>			
			<u>Services</u> <br>
				
				<?php $services = get_post_meta($post->ID, 'service_recieved');
						foreach($services as $service) echo $service . "<br>";
				?>
			<!--
			Services:<br><br>
			
			Rates:<br>
			--><br>
			1 <?php echo get_post_meta($post->ID, 'client_phone', true); ?><br><br>
			
			<a href='/claim/?claimID=<?php echo $post->ID; ?>'> Claim This Ad </a><br>
			<a href='<?php echo $post->guid; ?>' class='btn btn-warning'> View FULL Ad >> </a>
			
			<?php //print_r($post); ?>
		</div>
		<div class='clearfix'></div>
	</div>
				
			
		<?php
			
			if( /*($count % 4) ==*/ 0 ){ ?> <div class='clear hidden-xs hidden-sm'><hr></div> <?php }
			$count++;
		endforeach; 
		//wp_reset_postdata();
		?>
		<div class='clearfix'></div>
			
			<hr>
			<button id='new-review' class="btn btn-danger btn-lg btn-block">Post AD!</button>
				  
				  
				<div id='new-review' style='display: none; text-align: center; color: #e00;'>
					<hr>
                    <?php echo do_shortcode('[gravityform id="6" title="false" description="false"]'); ?> 
				</div>
			
		</div>
		<div class='clearfix'></div>
	</div><!-- // container -->		
	
</section><!-- // Our MEN -->