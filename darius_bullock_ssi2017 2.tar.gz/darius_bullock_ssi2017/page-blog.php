<?php get_header(); ?>
   
    <div class="clearfix mb-15"></div>
    
    	blog template 
<section id='blog' class='visible-xs1 visible-md1'>
	<div class='container'>
	
	    <a href='/post' class='hidden11 btn btn-lg btn-success btn-block'><br>New Post &raquo;<br><br></a>
	    
	    <div class="clearfix mb-15"></div>	
			
			<div class="well text-center">
					
					<?php
$args = array( 'post_type' => array('post', 'ssi_photos') , 'posts_per_page' => -1 );

		$count = 1;
		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); 
		
		get_template_part( 'content' );
		
		    //the_content();
		?>
			<hr>
			
				<a href="<?php the_permalink(); ?>">
					<div class='col-md-3 text-center blog-post well'>
					    <center>
						<?php 

							if ( !has_post_thumbnail($post)) {
								

								?>
								<img src="http://dlfreakfest.org/wp-content/uploads/2019/11/dlfreakfest-default-avatar.jpg"  class="img-responsive">
								
								<?php

							}
						  the_post_thumbnail('thumbnail', array( 'style' => 'small' ,'class' => 'img-responsive ','alt' => get_the_title(), 'title' => ''));
						
						the_title();
						 ?>
						</center>
						<div class='visible-xs visible-sm'><hr></div>
					</div>
				</a>
			
		<?php
			
			if( ($count % 4) == 0 ){ ?> <div class='clear hidden1-xs hidden1-sm'><hr></div> <?php }
			$count++;
		endforeach; 
		wp_reset_postdata();?>
		<div class='clearfix'></div>
							<a href='/post' class='hidden11 btn btn-lg btn-success btn-block'><br>New Post &raquo;<br><br></a>

			
		</div>
	</div><!-- // container -->		
</section><!-- // Blog SPace -->
	
<?php 
//get_template_part( 'content', 'ssi-banner-ad' );
//get_template_part( 'content', 'portfolio' );


get_footer('members'); ?>
