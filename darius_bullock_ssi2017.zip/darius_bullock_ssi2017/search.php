<?php 

get_header(); 

global $post;

?>
    
    <div class="main">
        
        <!-- wp:search {"label":"Search","placeholder":"BBC, Gay, Philadelphia, Top, Vers ...","buttonText":"Search","buttonUseIcon":true} /-->
    
        <div class="content ">
		
			<?php //get_template_part('left-sidebar');
			?>
        here
            <div class="posts col-2">
    
            <?php if(have_posts()) { ?>
                    <h2 class="page-title"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a><?php wp_title(); ?></h2>

                    
                    <?php while (have_posts()) : the_post(); ?>                    
                
                    <div class="post well" id="post-<?php the_ID(); ?>">
                        
                        <a href="<?php echo get_the_permalink() ?>" title="<?php echo get_the_title(); ?>"><br><?php echo get_the_title(); ?><?php echo get_the_post_thumbnail($post->ID,array(240,180), array('alt' => get_the_title(), 'title' => '')); ?></a>
                        <br>
                        <?php if ( get_post_meta($post->ID, 'duration', true) ) : ?><div class="duration"><?php echo get_post_meta($post->ID, 'duration', true) ?></div><?php endif; ?>
                        <br>
                        
                        
                        <span>Added: <?php the_time('F j, Y'); ?> at <?php the_time('g:i a'); ?></span>
                        <br>
                        <span><?php the_tags('Tags: ', ', ', ''); ?></span>
                        
                        
                        
                        	
	<div id='add-meta-<?php echo $post->ID; ?>' style='display: block;' class='text-center <?php if ( /*!is_user_logged_in()*/ 0  ) { echo "hidden"; } ?>'>
			
			<button id='add-meta-<?php echo $post->ID; ?>' class='hidden-print btn btn-success btn-lg btn-block hidden1'>Details</button>
			
			
				
								<div class='clear'></div>
	 
    <a type="button" class="btn btn-default 1btn-md hidden" id="myBtn2" data-toggle="modal" data-target="#myModal2-albums" data-show="true"><span class=" glyphicon glyphicon-plus" aria-hidden="true"></span> Albums</a>

	
			
		</div>
	
		<div class='clear'></div>	

		<div id='add-meta-<?php echo $post->ID; ?>' style='display: none;' >
			<div class='clear'></div>	
			<div class="col-md-10 col-md-offset-1  home-beta">
			<center><h3> Post Details </h3></center>
			</div>
			<div class="col-md-10 col-md-offset-1 text-left">
			<div class="well">
			
			 <?php foreach( $post as $key => $val ){
                            echo "<br>" . $key . " = " . $val;
                        }
                        
            ?>            
            </div>
			<div class='clear'></div>	
			<button id='add-meta-<?php echo $post->ID; ?>' class='hidden-print btn btn-default btn-sm'>x close</button>
			<div class='clearfix'></div>	
			</div>
		</div>
	<div class='clear'></div>
	
                        
                    </div>
                    
                    <?php endwhile; ?>
                    
                    <div class="clear"></div>

                    <div class="paginator">
                    
                        <?php if (function_exists("pagination")) {
    
                               // pagination($additional_loop->max_num_pages);
                            
                            } ?>

                    </div>
                    
                    <div class="clear"></div>
                    
                <?php }
        
                else { ?>
        
                    <h2>Sorry, no posts matched your criteria</h2>
        
                <?php } ?>
        
            </div>
            
        
        </div>
        

        
        <div class="clear"></div>
        
    </div>
    
<?php get_footer(); ?>
