<?php get_header(); ?>
    
    <div class="main">

        <div id='porn' class="content">

        <?php //get_template_part( 'content', 'series-widget' ); ?><hr>

            <div class="porn posts">


<h2 class="post-title text-center">Category: <?php single_cat_title( $prefix = '', $display = true ); ?></h2>



<?php  
  wp_reset_query();
  
	$number = 16;
	if( 1 ){ $number = $number; }
	
	$current_page = get_queried_object();
	
	//print_r($current_page);
	
	//print_r($current_page->slug);
    $category     = $current_page->post_name;
	$paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;  


        //echo "----->" . $current_page->slug;
 
        
        $query = new WP_Query( 
            array(
                'paged'         => $paged, 
                'category_name' => $category,
                'orderby'		=> 'modified',
                'order'         => 'desc',
                'post_type'     => 'ssi_requests',
                'post_status'   => 'publish',
				'posts_per_page'   => $number
            )
        );

        if ($query->have_posts()) {
               while ($query->have_posts()) { 
               $query->the_post();

					echo "ID=" ; 
					 print_r( get_the_id() );
			   ?>
			   
			   
			   
			   <div class='col-sm-12 '>
			   here
			   <?php get_template_part('content' , 'single-request'); ?>
			   
			   <?php
			   	$status = get_field( "request_status", get_the_id() );
					
			switch ($status) {
				case "Pending":
				   echo "Pending...";
					break;
				case "Interested":
					echo "Molly is Interested..   but she needs more information";
					break;
				case "Invited":
					echo "You are Invited! - Invite Sent";
					break;
				case "Booked":
					echo "You are Booked! - A Time has been Set";
					break;
				case "Completed":
					echo "Request Completed!";
					break;
				case "Denied":
					echo "Request Denied";
					break;
				case "Hold":
					echo "On Hold";
					break;
				default:
					//echo "Pending...";
						
					
			}
			
			if(get_field( "status_notes", get_the_id() )){
					echo "</span><br><br>" . get_field( "status_notes", get_the_id() );
					}
				if(get_field( "final_products", get_the_id() )){
					echo "<hr>" . get_field( "final_products", get_the_id() );
					}	
					
				echo "</center>"; ?>
				</div>
                
                <?php
            }

           
        }
        ?>
<div class="clear"></div><br><br>
		<div class="paginator container">
					
			<?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages); } ?>
				
		 </div>
<div class="clear"></div><br><br>
				
            </div>
            
          
        
        </div>
        
     
        
        <div class="clear"></div>
        
    </div>
    
<?php get_footer(); ?>
