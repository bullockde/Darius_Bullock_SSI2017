<?php
/**
*
*
 */

get_header('network'); ?>

<div id="primary" class="">

		
<div class=' '>


			
	<div class='col-md-8 col-md-offset-2 text-center'>

	
		
				<?php

			

				$requests = get_posts( 
				
					array(	
						'category_name' => 'invited',
						'posts_per_page'   => -1,  
						'post_status'                => 'publish',
						//'date_query' => array(  'before' => '1 month ago'  ) 
					) 
				);
			

			
						//print_r( $folks );
						// Start the loop.
						$count = 1;
						
						//$folks = (array)$query;
						foreach( $requests as $request ){
							
					
							if( get_field( "request_status", $request->ID  ) == 'Invited' ){

								echo $count++ . ". ";
								
								echo '<h1>' . $lead->post_title . '</h1>';
								
								echo "<hr>";
							}
						}
						
						?>
			
			
				<a href='/book/' class='btn btn-default btn-lg h1'>Request a Session >></a>
				

				<br><br>
				<?php if( is_page('mansion-vip-list') ){ 
					// Mansion Party VIP List Entries

					$members = GFFormsModel::get_leads( '10' );
					
					foreach( $members as $member ){
						
			echo "<div class='row'><div class='col-md-6'><div class='col-md-6'><img src='" . $member[9] . "' width='150' height='150' ></div>";
						echo "<div class='col-md-6'> Name: " . $member[1] . "<br>";
						echo "Age: " . $member[6] . "<br>";
						echo "Height: " . $member[7] . "<br>";
						echo "Weight: " . $member[8] . "<br>";
						echo "Member Since: " . $member[date_created] . "</div></div></div><br><br>";

						
						echo "<div class='clearfix'></div><br>";
						echo "";
						echo "";

					}
					echo "<br><br><br>";
					print_r( $members );
					

				?>
					
					
					
				<?php } ?>

	</div>
			
			<div class='clearfix'></div>

	<div class='col-md-10'>
			
			<?php get_template_part( 'content', 'request-page' ); ?>
			<?php get_template_part( 'content', 'requests' ); ?>
			
			
	</div>
	
	<div class='col-md-2 text-center'>Ad
		
		<?php get_template_part( 'ad', '160-600' ); ?>
	</div>
		
				<div class='clearfix'></div>
</div>	
		
		

	
</div><!-- .content-area -->
<?php 
	get_footer('preview'); 
?>