<style>
 .upcoming-events p {
		margin: 0 0 .5em;
	}
</style>						

<div class='upcoming-events text-center'>




<?php


$upcoming_events = get_posts( array (  
						
					   'posts_per_page'         =>  2,
					   'post_type' => 'ssi_events',
					   'category_name' => 'upcoming-events',
					   'meta_key'               => 'event_date',
						'order' => 'asc',

					)     );

					
$past_events = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					   'post_type' => 'ssi_events',
					   
					   'category_name' => 'past-events',
						'order' => 'asc',

					)     );

					
$all_upcoming_events = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					   'post_type' => 'ssi_events',
					   'category_name' => 'upcoming-events',
					   'meta_key'               => 'event_date',
						'order' => 'asc', 

					)     );

					
$folks = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					  // 'post_type' => 'party_guests',
						'category_name'                  => 'vip-member',
						'post_status'                => 'draft',
						'order' => 'asc',
						//'offset' => 2
					   // 'meta_key'               => 'vortex_system_likes',
						//'categories'	=>	array( -147 ),
					)     );
					
					foreach( $folks as $lead ){
						set_post_type( $lead->ID , 'party_guests' );
						wp_publish_post( $lead->ID ); 
					}
		
?>
<div class="clear"></div>

	


			


		<?php 
					$found = 0;
					
					$count = 0;
					
					$cancelled = false;
					
					
					if( count($upcoming_events) > 1 ){
						$leads = array_shift($upcoming_events);
					
						
					}
					
					foreach( $upcoming_events as $lead ){
						
						if( get_field('event_cancelled', $lead->ID ) == "Yes" )  { $cancelled = true; }else{ $cancelled = false; }
						
						
					if( $count == 0 ) { 
					
						
						
						
						?>
				
	<div class='1col-md-10 1col-md-offset-1 text-center  well green hidden1'>		
		

			<?php echo get_field('event_countdown', $lead->ID); ?>
			<div class='clearfix '></div>
			<a href="/rsvp"><img src="<?php echo get_field('event_flyer', $lead->ID); ?>" ></a>
			<div class='clearfix mb-10 '></div>
			<div class='well yellow mb-10 hidden'>
			<h3><?php echo date("l | M jS, Y", strtotime(get_field('event_date', $lead->ID))); ?> <br><small>Doors Open @ 11PM</small></h3>
						[<?php echo get_field( 'event_location', $lead->ID ); ?>]
			</div>
			<div class='image hidden'>		
			
			
				<a href='/<?php echo $lead->post_type; ?>/<?php echo $lead->post_name; ?>' class=''><?php echo get_the_post_thumbnail($lead->ID); ?> </a>
				
				<div class='clear mb-10'></div>
		
			</div>		
			
			<a href='/<?php echo $lead->post_type; ?>/<?php echo $lead->post_name; ?>' class='btn btn-success btn-lg btn-block hidden1 mb-10'><br> Quick RSVP >> <br><br></a>
			
			
			
	
			<div class='clear'></div>
			
			
			
						
						
	</div>					<?php 
					
					
					}
					

						
						?>
						
						
						<div class='clear'></div>
						

	<?php } ?>
	

<div class='clear'></div>

</div>