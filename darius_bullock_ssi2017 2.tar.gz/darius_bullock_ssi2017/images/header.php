<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

	//if( is_front_page() && is_user_logged_in() ){ $pg = "/members/"; wp_redirect($pg); exit; }
  //if( is_user_logged_in() && is_page('login') ){ $pg = "/profile/"; wp_redirect($pg); exit; }
  
  global $post;
	
/*** ##START - Check & Complete User Profile **/
	if ( !function_exists( 'bp_core_fetch_avatar' ) ) { 
		require_once '/bp-core/bp-core-avatars.php'; 
	} 
	
	
	$user = $current_user = wp_get_current_user();
	
			
			// An array of arguments. All arguments are technically optional; some will, if not provided, be auto-detected by bp_core_fetch_avatar(). This auto-detection is described more below, when discussing specific arguments. 
		$args = array( 
			'item_id' => $user->ID, 
			'object' => '', 
			'type' => '' ,
			'html' => 1,
			'no_grav' => 1
		); 
		  
		// NOTICE! Understand what this does before running. 
		$result = bp_core_fetch_avatar($args); 
		
		//echo $result;
/*
	if( current_user_has_avatar() && strpos( $_SERVER['REQUEST_URI'], "change-avatar") && strpos( $_SERVER['REQUEST_URI'], "register") ){  
			$pg = "/profile"; wp_redirect($pg); exit;
	}else{
		
		if( is_page('members') ){
			//$pg = "/members-list/<" . $user->user_nicename . "/profile/change-avatar/"; wp_redirect($pg); exit;
		}

	}
*/	
		
	
	$age = get_user_meta($user->ID , 'MX_user_age' , 1);


	
/*** ##END - Check & Complete User Profile **/






			$requests = get_posts( 
				
					array(	
						'category_name' => 'requests',
						'posts_per_page'   => -1,  
						'post_status'                => 'publish',
						//'date_query' => array(  'before' => '1 month ago'  ) 
					) 
				);
				foreach( $requests as $request ){ set_post_type( $request->ID, 'ssi_requests' ); }
				
				
if($_POST['new_post']){
	
	//$date_added = date('Y-m-d H:i:s', strtotime($_POST['date_added']) );
// Create post object

		//$post_status = $_POST['post_status']
		
		$my_post = array(
		  
		  'ID' => '',
		// 'post_date'	=> $date_added,
		 'post_type' => $_POST['post_type'] ,
		 'post_title' => $_POST['post_title'] ,
		'post_content' => $_POST['post_content'] . '',
		 'post_status' => 'publish'

		);
		

		// Insert the post into the database
		$post_id = wp_insert_post( $my_post );
		
		foreach ($_POST as $param_name => $param_val) {
			add_post_meta($post_id, $param_name, $param_val, true);
			update_post_meta( $post_id, $param_name, $param_val  );

		}
		
		//set_post_type( $post_id, 'ssi_staff' );
		
} 

$past_events = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					   'post_type' => 'ssi_events',
					   
					   'category_name' => 'past-events',
						'order' => 'desc',

					)     );
					
$upcoming_events = get_posts( array (  
						
					   'posts_per_page'         =>  -1,
					   'post_type' => 'ssi_events',
					   'category_name' => 'upcoming-events',
					   'meta_key'               => 'event_date',
						'order' => 'asc', 

					)     );

	
	
			$current_user = wp_get_current_user();
	
	
			$age = get_user_meta($current_user->ID , 'MX_user_age' , 1);

			if( is_user_logged_in() && !is_numeric($age) && is_page('cashappkings') ){ 
					$pg = "/profile/"; wp_redirect($pg); exit;
			}
			elseif( is_front_page() && is_user_logged_in() ){ $pg = "/members/"; wp_redirect($pg); exit; }


?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	
	
	

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
	
	<meta name="juicyads-site-verification" content="c0c65d86091675f3337207e89ad95d25">
	<meta name="exoclick-site-verification" content="e16b449a769083acb9059455b296cc92">
	<style>
		 
	</style>


</head>

<body <?php body_class(); ?>>

		<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentysixteen' ); ?></a>

		<header id="masthead" class="site-header text-center" role="banner">
	
			<?php if ( get_header_image() ) : ?>
				<?php
					/**
					 * Filter the default twentysixteen custom header sizes attribute.
					 *
					 * @since Twenty Sixteen 1.0
					 *
					 * @param string $custom_header_sizes sizes attribute
					 * for Custom Header. Default '(max-width: 709px) 85vw,
					 * (max-width: 909px) 81vw, (max-width: 1362px) 88vw, 1200px'.
					 */
					$custom_header_sizes = apply_filters( 'twentysixteen_custom_header_sizes', '(max-width: 709px) 85vw, (max-width: 909px) 81vw, (max-width: 1362px) 88vw, 1200px' );
				?>
				<div class="header-image">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<img src="<?php header_image(); ?>" srcset="<?php echo esc_attr( wp_get_attachment_image_srcset( get_custom_header()->attachment_id ) ); ?>" sizes="<?php echo esc_attr( $custom_header_sizes ); ?>" width="<?php echo esc_attr( get_custom_header()->width ); ?>" height="<?php echo esc_attr( get_custom_header()->height ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
					</a>
				</div><!-- .header-image -->
			<?php endif; // End header image check. ?>
		</header><!-- .site-header -->
 

		
		<style>
	.bg-blue {
		background: radial-gradient( #173e9a, #000000)  !important;
		border-top: 3px solid #000;
		border-bottom: 3px solid #000;
		padding: 1em 0 0;
		color: #fff;
	}
	.bg-blue.header{
		
		background: radial-gradient(#8dabbc,#606b72 ) !important;
		border-top: 3px solid #000;
		border-bottom: 3px solid #000;
		padding: .7em 0 0;
		color: #fff;
	}
	.pb-5 {
		padding-bottom: 1em !important;
	}
	button, input, select, textarea {
		font-family: inherit;
		font-size: inherit;
		line-height: inherit;
	}
	#header-login input {
		line-height: normal;
		width: inherit !important;
		font-size: 12px;
	}




	button, input, optgroup, select, textarea {
		margin: 0;
		font: inherit;
		color: inherit;
	}
	button, input {
		overflow: visible;
	}
	button, input, optgroup, select, textarea {
		margin: 0;
		font-family: inherit;
		font-size: inherit;
		line-height: inherit;

	/*	div#header-login {
		    display: none !important;
		}*/
</style>

		
		
		
		
				
			<?php	
			$current_user = wp_get_current_user();
	
	
			$age = get_user_meta($current_user->ID , 'MX_user_age' , 1);

			if( is_user_logged_in() && !is_numeric($age) && !is_page('edit-profile') ){ 
			?>
				<div id='no-pic' class=" well yellow mb-5 alert-warning hidden">
				
						<center><h2>Complete Your Profile!</h2><br>-- BLANK profiles will be deleted --<br><br>
					   <a href='/profile/' class='btn btn-warning'>Edit Profile</a>

						</center>			 
					  
				</div>
			<?php
			}
			
			// An array of arguments. All arguments are technically optional; some will, if not provided, be auto-detected by bp_core_fetch_avatar(). This auto-detection is described more below, when discussing specific arguments. 
		$args = array( 
			'item_id' => $current_user->ID, 
			'object' => '', 
			'type' => '' ,
			'html' => 1,
			'no_grav' => 1
		); 
		  
		// NOTICE! Understand what this does before running. 
		$result = bp_core_fetch_avatar($args); 
		
		//echo $result;

	if( current_user_has_avatar() ){}else{
		
		if( is_page('members-area') ){
			//$pg = "/members/<" . $user->user_nicename . "/profile/change-avatar/"; wp_redirect($pg); exit;
		}
?>
		<div class='clearfix'></div>   
		
		
		
		<div id="no-pic" class="  alert alert-warning text-center1 mb-5 hidden">
            <strong>Upload a Photo! - <small>( Face NOT Required )</small> &rarr; </strong> <a href="/members-list/<?php echo $user->user_nicename; ?>/profile/change-avatar/" class="btn btn-warning pull-right1">Upload Image</a>
            <button class="close" data-dismiss="alert">×</button>
        </div>
		
		
		<div class=''></div> 
		<div class='clear'></div> 
        <div id='no-pic' class=" well alert-warning yellow mb-5  hidden">
				<button class="close hidden" data-dismiss="alert">×</button>
			
			
				<center><h2>You MUST upload a Photo!</h2><br>-- Face is NOT Required --<br><br>
              <a href='/members-list/<?php echo $user->user_nicename; ?>/profile/change-avatar/' class='btn btn-warning'>Upload Image</a>

				</center>			 
            
        </div>
<?php

		
		//exit;
	}
	

	
/*** ##END - Check & Complete User Profile **/
?>
		
		
		
		
		
		<?php
			if( /*is_user_logged_in()*/ 1 ){ ?>

				




                <div class="profile-menu-top 1container-fluid text-center">
                    
                    <div class="clearfix mb-0"></div>
                    <div class="col-xs-6 col-sm-3">
                                       <div class="clearfix mb-15 hidden-xs"></div>
                                       
									<h2 class="entry-title ">
    									<a href="/members/">
    										<?php if( is_front_page() ){ echo "DLFreakFest.org"; }else{ the_title(); }  ?>
    									</a>
									</h2>
								</div>
								<div class="col-md-3 col-xs-6 1hidden-sm">
									   <div class="clearfix mb-15 hidden-xs"></div>
                                      
									
										<span class="glyphicon glyphicon-user hidden " aria-hidden="true"></span>
										<?php if( !is_user_logged_in() ){ ?>
										    <a target="_blank" href="/add/" class="btn btn-info"><b>Create</b> a <b>NEW Profile</b> &raquo; </a>
									    <?php }else{ ?>
									           <div class="1btn-group btn-group-justified text-center 1col-md-8 1col-xs-12">
                                					<div class='clearfix'></div>
                                					<center>
                                						<a href="/edit/?ID=<?php echo  $current_user->ID; ?>" class="btn btn-default">Edit Profile</a>
                                						<a  href="/user-profile/?ID=<?php echo  $current_user->ID; ?>" class="btn white btn-info">View Profile</a>
                                					</center>
                                					<div class='clearfix mb-0'></div>
                            					</div>
									    <?php } ?>
									    <div class="clearfix mb-5"></div>
									

								</div>
								<div class=" col-sm-6 1hidden-xs text-right">
								        
								        
								        <div class="clearfix mb-0"></div>
								        
										<div id='header-login' class='1text-center well green 1bg-blue 1pb-5 mb-0 <?php if( !is_user_logged_in() && !is_front_page() ){ echo 'mb-0'; } ?>' style='display: block;'>
	
	
	                                           <center>
		
                                        		<?php
                                        			if( !is_user_logged_in() ){
                                        		
                                        			$redirect_to = '/';
                                        		?>
                                        		<form name="loginform" id="loginform" action="<?php echo site_url( '/wp-login.php' ); ?>" method="post">
                                        			<span class="hidden-xs">&nbsp;&nbsp; Member Login: </span>
                                        			
                                        
                                        			<input id="user_login" placeholder="Username" type="text" size="10" value="" name="log">
                                        			<input id="user_pass" placeholder="Password" type="password" size="10" value="" name="pwd">
                                        			<input id="rememberme" type="checkbox" value="forever" name="rememberme">
                                        			<input id="wp-submit" class="btn btn-primary" type="submit" value="Login" name="wp-submit">
                                        
                                        			<input type="hidden" value="<?php echo esc_attr( $redirect_to ); ?>" name="redirect_to">
                                        		</form>
                                        		 <?php
                                        		
                                        		
                                        			}else{
                                        				
                                        				?>
                                        				
                                        				<h4><b><?php if( is_user_logged_in() ){  $current_user = wp_get_current_user(); echo 'Welcome Back, ' . strtoupper($current_user->user_login) . '!'; }else{ echo "<b>Welcome, " . $_COOKIE['name'] . "!</b>";}  ?></b></h4>
                                        				<?php
                                        				
                                        			}
                                        		?>
                                        		</center>
                                        </div> 
                                </div> 
                </div> 
                
                <?php } ?>
                <div class="clearfix mb-5"></div>
                
                
<div class="container-fluid text-center bg-blue header">
	<div class="col-xs-4 col-sm-2 col-sm-offset-1">
		<a target="_blank" href="/" class="white">
			<span class="glyphicon glyphicon-home" aria-hidden="true"></span>
			<br>
			Home
		</a>
	</div>
	<div class="col-xs-4 col-sm-2">
		<a target="_blank" href="/mailbox" class="white">
			<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
			<br>
			Inbox
		</a>
	</div>
	<div class="col-md-2 hidden-xs 1hidden-sm">
		<a target="_blank" href="/photos" class="white">
			<span class="glyphicon glyphicon-camera" aria-hidden="true"></span>
			<br>
			Photos
		</a>


	</div>
	<div class=" col-sm-2 hidden-xs">
		<a target="_blank" href="/videos" class="white">
			<span class="glyphicon glyphicon-play" aria-hidden="true"></span>
			<br>
			Videos
		</a>
		
	</div>
	<div class="col-xs-4 col-sm-2 col-xs-offset-0 col-sm-offset-0">
		
		<a target="_blank" href="/dashmaster" class="white">
			<span class="glyphicon glyphicon-transfer" aria-hidden="true"></span>
			<br>
			Dash
		</a>
	</div>

	<div class="clearfix mb-10"></div>
</div>
