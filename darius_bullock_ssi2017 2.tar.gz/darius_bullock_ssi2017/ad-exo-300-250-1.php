<center>
<script type="text/javascript">
var ad_idzone = "2993126",
	 ad_width = "300",
	 ad_height = "250";
</script>
<script type="text/javascript" src="https://ads.exosrv.com/ads.js"></script>
<noscript><a href="https://main.exosrv.com/img-click.php?idzone=2993126" target="_blank"><img src="https://syndication.exosrv.com/ads-iframe-display.php?idzone=2993126&output=img&type=300x250" width="300" height="250"></a></noscript></center>