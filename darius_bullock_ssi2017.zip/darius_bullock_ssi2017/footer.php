<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

		</div><!-- .site-content -->
		
		
		
		
		
		
		
			<div class="clearfix mb-0"></div>
	<div class="1container-fluid text-center bg-blue header mb-0 hidden1">
	<div class="clearfix mb-0"></div>
	
	
	
	
	      
            
	<div class="col-sm-3 col-xs-3 hidden">
		<a href="/" class="white">
			<span class="glyphicon glyphicon-home" aria-hidden="true"></span>
			<br>
			HOME
		</a>
	</div>
	<div class="col-md-3 col-sm-3 col-xs-3 1col-md-offset-1 col-sm-offset-0">
		<a href="/profile" class="white">
			<span class="glyphicon glyphicon-user" aria-hidden="true"></span>
			<br>
			PROFILE
		</a>
	</div>
	<div class="col-md-3 col-sm-3 col-xs-3 1hidden-xs 1hidden-sm">
		<a href="/photos" class="white">
			<span class="glyphicon glyphicon-camera" aria-hidden="true"></span>
			<br>
			PHOTOS
		</a>


	</div>
	<div class="col-md-3 col-sm-3 col-xs-3 1hidden-xs">
		<a href="/videos" class="white">
			<span class="glyphicon glyphicon-play" aria-hidden="true"></span>
			<br>
			VIDEOS
		</a>
		
	</div>
	<div class=" col-md-3 col-sm-3 col-xs-3 ">
		<a type="button" class="white" id="myBtn2" data-toggle="modal" data-target="#myModal2-menu" data-show="true">
			<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span>
			<br>
			MENU
		</a>
		
	</div>
	<br>
		
		<div class="clearfix mb-10"></div>
	</div>

        	
     <div id='add-menu' style='display: none;'  class='1well 1green'>
		<div class='clearfix'></div>		
			<div class="1col-md-10 1col-md-offset-1  home-beta">
			 <div class='clearfix mb-0'></div>
		
			
		
				 <div class="btn-group btn-group-justified">

	<a href="/groups/" class="btn btn-default"> <small>GROUPS</small> </a>
	<a href="/forums/" class="btn btn-default"> <small>FORUMS</small> </a>
	<a href="/events/" class="btn btn-default"> <small>EVENTS</small> </a>
	<a href="/search/" class="btn btn-default"> <small>SEARCH</small> </a>

</div>
			<div class='clear'></div>	
			<button id='add-menu' class='hidden hidden-print 1btn  text-center 1btn-default 1btn-sm'>x close</button>
			<div class='clearfix'></div>	
		 <div class='clearfix mb-0'></div>
			</div>
			
			<div class='clear'></div>
		</div>
<div class='clearfix'></div>
	<?php if( !is_user_logged_in() ){ ?>


 <div class='container-fluid clearfix 1col-md-2 1col-md-offset-5 p-0 footer-login well yellow mb-0 align-center'>
     <div class="clearfix mb-0"></div>
     
     
     
     
     
     <div class="col-md-6 col-md-offset-3">
         
          <div class="clearfix 1mb-10"></div>
        <center>
            <h3 class=" entry-title "><a><u>Member Login</u></a></h3>
            <?php //do_action('oa_social_login'); 
            ?>
            
            <?php //echo do_shortcode("[wpmem_form login redirect_to='/members']"); 
            
            
            get_template_part('content', 'header-login');
            
            ?>
             <div class="clearfix mb-10"></div>
        </center>
        <div class="clearfix mb-5"></div>
     </div>
    <div class="clearfix mb-0"></div>
</div>
<div class="clearfix mb-0"></div>
<?php }else{ ?>
     <div class='container-fluid hidden clearfix 1col-md-2 1col-md-offset-5 p-0 footer-login well yellow mb-0 align-center'>
         
 

	 <div class="btn-group btn-group-justified">

	<a href="/groups/" class="btn btn-default"> <small>GROUPS</small> </a>
	<a href="/forums/" class="btn btn-default"> <small>FORUMS</small> </a>
	<a href="/events/" class="btn btn-default"> <small>EVENTS</small> </a>
	<a href="/search/" class="btn btn-default"> <small>SEARCH</small> </a>

</div>
         	
   <div class='clearfix'></div>      
     <div class="col-md-6 col-md-offset-3">
         
          <div class="clearfix mb-0"></div>

     </div>
    <div class="clearfix mb-0"></div>
</div>
<div class="clearfix mb-0"></div>
<?php } ?>
	<div class='text-center footer-bottom'>
		 
         
			   <div class='clearfix'></div>
			 <div class='clearfix col-md-2 col-md-offset-5 align-center hidden1'>
			      <div class='clearfix'></div>
					        <center>
					            <?php get_template_part('ad', 'flag-counter'); ?>
					            <?php //do_action('oa_social_login'); 
					            ?>
					            
					            
					        </center>
					        <div class='clearfix'></div>
					    </div>
		<div class='clearfix'></div>
		<div class="clearfix mb-10"></div>
		
		<?php 
		
		    if( is_user_logged_in() ){
		     //echo do_shortcode("[wpmem_form login redirect_to='/members']"); 
		     get_template_part('content', 'header-login');
		    }else{

		     ?>
		
		Thanks For Visiting!
		   <?php } ?>
		   
		  
	</div>		
	
	
	
	
	
	

		<footer id="colophon" class="site-footer">
			<?php if ( has_nav_menu( 'primary' ) ) : ?>
				<nav class="main-navigation" aria-label="<?php esc_attr_e( 'Footer Primary Menu', 'twentysixteen' ); ?>">
					<?php
						wp_nav_menu(
							array(
								'theme_location' => 'primary',
								'menu_class'     => 'primary-menu',
							)
						);
					?>
				</nav><!-- .main-navigation -->
			<?php endif; ?>

			<?php if ( has_nav_menu( 'social' ) ) : ?>
				<nav class="social-navigation" aria-label="<?php esc_attr_e( 'Footer Social Links Menu', 'twentysixteen' ); ?>">
					<?php
						wp_nav_menu(
							array(
								'theme_location' => 'social',
								'menu_class'     => 'social-links-menu',
								'depth'          => 1,
								'link_before'    => '<span class="screen-reader-text">',
								'link_after'     => '</span>',
							)
						);
					?>
				</nav><!-- .social-navigation -->
			<?php endif; ?>

			<div class="site-info">
				<?php
					/**
					 * Fires before the twentysixteen footer text for footer customization.
					 *
					 * @since Twenty Sixteen 1.0
					 */
					do_action( 'twentysixteen_credits' );
				?>
				<span class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></span>
				<?php
				if ( function_exists( 'the_privacy_policy_link' ) ) {
					the_privacy_policy_link( '', '<span role="separator" aria-hidden="true"></span>' );
				}
				?>
				<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'twentysixteen' ) ); ?>" class="imprint">
					<?php
					/* translators: %s: WordPress */
					printf( __( 'Proudly powered by %s', 'twentysixteen' ), 'WordPress' );
					?>
				</a>
			</div><!-- .site-info -->
		</footer><!-- .site-footer -->
	</div><!-- .site-inner -->
</div><!-- .site -->

<?php wp_footer(); ?>
</body>



<script>

jQuery(document).ready(function(){
   jQuery( "button" ).click(function() {
	var id = this.id;
	jQuery("div#" + id ).slideToggle();
	
   });
});
</script>

<script>
jQuery(function($) {
    var page = 1;
    var loading = false;
    var $loadMoreButton = $('#load-more-button');
    var $postContainer = $('#post-container');

    $loadMoreButton.on('click', function() {
        if (!loading) {
            loading = true;
            $loadMoreButton.text('Loading...');

            var data = {
                action: 'load_more_posts',
                query: '<?php echo json_encode($args); ?>', // Pass the query parameters to the AJAX handler
                page: page
            };

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // URL to the AJAX handler
                data: data,
                type: 'POST',
                success: function(response) {
                    if (response) {
                        $postContainer.append(response);
                        page++;
                        loading = false;
                        $loadMoreButton.html('<small>MORE</small> <br> 	<span class="glyphicon glyphicon-chevron-down"></span>');
                    } else {
                        $loadMoreButton.text('No more posts');
                    }
                }
            });
        }
    });
});
</script>
</html>
