<?php 
global $post;

?>
    


<div id='video-choice'></div>
    <div class="col-md-12 1col-md-offset-1 ">
		<?php 
		
/*		   $args = array(
                        //'role' => 'subscriber',
						'meta_key' => 'when_last_login',
						'orderby'  => 'meta_value_num',
						'order'  => 'desc',
        'number' => $no, 'offset' => $offset,
                            'meta_query' => array(
                                array(
                                    'key' => $filter,
                                    'value' => $_GET['filter'],
                                    'compare' => 'LIKE'
                                )
                            ));
							
			 $user_query = new WP_User_Query( $args );				
							
			$total_user = $user_query->total_users;  	*/
			 $index = 0;
			 
			$metaKEY = 'MX_user_twitter';
			$post_slug = 'twitter';
			$website_link = '//twitter.com/';
			 
			// echo "META=" . $metaKEY;
			 			
			$args = array(
				
				'meta_key' => $metaKEY,
				//'meta_key' => 'when_last_login',
				//'orderby'  => 'meta_value_num',
			);

			// The Query
			$user_query = new WP_User_Query( $args );


			    if ( !empty( $user_query->results ) ) {
        foreach ( $user_query->results as $user ) {
             
		
				
			 //FOREACH User
			
			
							if( get_user_meta($user->ID, $metaKEY , 1)
				|| get_user_meta($user->ID, $post_slug . "_link"  , 1)
			
			 ){   /* echo "Has Tumblr!<br>"; */  $index++; }else{ continue; }

							//update_user_meta( $user->ID, 'wp-last-login', time() );

									if( (!isset($username) || $username == "") ||  preg_match("/" . $username . "/i", $user->display_name) ){

								
								
						?>		
						
						
	<div id="<?php echo $tumblr_name;  ?>" class="1col-xs-12 person text-center  1img-thumbnail 1cashapp 1ad-shift">
	
	
				
	
						<?php 
								if( get_user_meta($user->ID, $metaKEY , 1)){ $tumblr_name = get_user_meta($user->ID, $metaKEY , 1); }
								if( get_user_meta($user->ID, $post_slug . "_link" , 1)){ $tumblr_name = get_user_meta($user->ID, $metaKEY , 1); }
								
								
								
						?>
						
						<div class="col-xs-12 img-thumbnail">
									 
									 <div class=" porn col-md-5">
									 <div class="clearfix mb-10"></div>
									 <span class="text-left small"><?php echo ++$cnt; ?></span>
									
										<center> 
											
											<a target='_blank' href="/user-profile/?ID=<?php echo $user->ID; ?>" target="_blank">

												<?php echo get_avatar($user->ID, 75); ?> 
											</a>
										</center>
										<div class="clearfix"></div>
									</div>
									<div class="col-sm-7">
									
									<div class="clearfix mb-15"></div>
											<h5 class="walls"><a target='_blank' href="/user-profile/?ID=<?php echo $user->ID; ?>" target="_blank"><?php echo substr($user->display_name, 0, 10); ?></a> </h5>
											<div class="clearfix mb-10"></div>
						
						<div id="user-mini">
							<div class=" upper bold">
								
								
								<span class='hidden' style='float:right; background: #ffffff; padding: 0 2px; color: #ff0000; '>S: <?php echo $social; ?></span>
							</div>
	
<center>
<?php	

		if( get_user_meta($user->ID, 'MX_user_age' , 1) ){
					echo get_user_meta($user->ID, 'MX_user_age' , 1) . ' | ';
		}else{
					echo '- | ';
		}
		if( get_user_meta($user->ID, 'MX_user_height_ft' , 1) ){
					echo get_user_meta($user->ID, 'MX_user_height_ft' , 1) . "' " . get_user_meta($user->ID, 'MX_user_height_in' , 1) . '" | ' ;
		}else{
					echo '- | ' ;
		}
		if( get_user_meta($user->ID, 'MX_user_weight' , 1) ){
					echo get_user_meta($user->ID, 'MX_user_weight' , 1) . "<br>";
		}else{
					echo '- <br>';
		}
			?>
</center>
<?php									

						echo '<div class="mini-left">';
						//userphoto($user->ID, '<div class="photo porn">', '</div>', array(style => '') ) ;
				?> 
					<!--<small>			
				<?php		
						if( get_user_meta($user->ID, 'MX_user_position' , 1) ){
							
							echo get_user_meta($user->ID, 'MX_user_position' , 1);
						}else{
							echo "-";
						}
								
					?>
					</small>-->
					<br>
<?php					
										//mt_profile_img();
										
											if ( !function_exists( 'bp_core_fetch_avatar' ) ) { 
											require_once '/bp-core/bp-core-avatars.php'; 
										} 
										  
										// An array of arguments. All arguments are technically optional; some will, if not provided, be auto-detected by bp_core_fetch_avatar(). This auto-detection is described more below, when discussing specific arguments. 
										$args = array( 
											'item_id' =>  $user->ID, 
											'object' => '', 
											'type' => '' 
										); 
									  
									// NOTICE! Understand what this does before running. 
									$result = bp_core_fetch_avatar($args);

											//print_r($result);
										echo "</div>";
										
										$closet = 0;
				
								
		?>
				<div class='clear full-login upper bold text-left hidden'>
		<?php
			
								$last_login = (int) get_user_meta( $user->ID, 'when_last_login' , true );
											if ( $last_login ) {
												$format = apply_filters( 'wpll_date_format', get_option( 'date_format' ) );
												$value  = date_i18n( $format, $last_login );
												echo "<br>Last Here <span style='float: right;'>" . $value . "</span>";
											}else{
												echo "<br>Joined <span style='float: right;'>" . mysql2date($format, $user->user_registered ) . "</span>";
											}
					
					
					
					?>
					
					</div>
					
					
					
					<div class='clearfix mx-15'></div>
					
					
					<div class='clear full upper bold '>
					<?php
				
										
								$closet = 0;
								if ( get_user_meta($user->ID, 'MX_user_city', 1 ) && get_user_meta($user->ID, 'MX_user_state', 1) ){

																		echo ' <span style="text-transform: capitalize;">' . get_user_meta($user->ID, 'MX_user_city', 1 ) . '</span>, ';
																		echo get_user_meta($user->ID, 'MX_user_state', 1) ;

								}
								else if ( get_user_meta($user->ID, 'MX_user_state', 1) ){
									echo  get_user_meta($user->ID, 'MX_user_state', 1);
								}
								else{
									$closet = 1;
									echo '-';
								}				
	

									?>
									<br></div>
									</div>
									
									</div>
									
									 
										
									 
									<div class="clearfix mb-15"></div>
									 
									 <a target='_blank' href='/user-profile/?ID=<?php echo $user->ID; ?>' class='btn  btn-default btn-block'> View Profile </a>
									<div class="clearfix mb-10"></div>
								</div>

								 <?php 

									
									$fansKEY = 'MX_user_onlyfans';
									$fans_slug = 'onlyfans';
									$fans_link = '//onlyfans.com/';
									$fans_name = "Add Username";
									
									if( get_user_meta($user->ID, $fansKEY , 1)){ $fans_name = get_user_meta($user->ID, $fansKEY , 1); }
			
								 ?>
								 
								 <div class="col-xs-4 img-thumbnail">
									<br>
									 <a target='_blank' href="<?php echo $fans_link;  ?><?php echo $fans_name;  ?>" target="_blank"><img class='img-thumbnail' src='<?php echo get_stylesheet_directory_uri(); ?>/images/icons/icon-<?php echo $fans_slug;  ?>.png' width='65' height='65'>
									 </a>
									 
									 <div class="clearfix mb-5"></div>
										<h5 id='<?php echo $fans_name;  ?>' class='walls'><a target='_blank' href="<?php echo $fans_link;  ?><?php echo $fans_name;  ?>" target="_blank"><?php echo $fans_name;  ?></a> </h5>
									 
										<div class="clearfix mb-15"></div>
									 
									
									<a target='_blank' href='<?php echo $fans_link;  ?><?php echo $fans_name;  ?>' class='btn btn-block  btn-success'> Send / Request &raquo; </a>
									<div class="clearfix mb-10"></div>
								</div>


						
									 <?php 

									
									$cashKEY = 'MX_user_cashapp';
									$cash_slug = 'cashapp';
									$cash_link = '//cash.app/';
									$cash_name = "Add Username";
									
									if( get_user_meta($user->ID, $cashKEY , 1)){ $cash_name = get_user_meta($user->ID, $cashKEY , 1); }
			
								 ?>
								 
								 <div class="col-xs-4 img-thumbnail">
									<br>
									 <a target='_blank' href="<?php echo $cash_link;  ?><?php echo $cash_name;  ?>" target="_blank"><img class='img-thumbnail' src='<?php echo get_stylesheet_directory_uri(); ?>/images/icons/icon-<?php echo $cash_slug;  ?>.png' width='65' height='65'>
									 </a>
									 
									 <div class="clearfix mb-5"></div>
										<h5 id='<?php echo $cash_name;  ?>' class='walls'><a target='_blank' href="<?php echo $cash_link;  ?><?php echo $cash_name;  ?>" target="_blank"><?php echo $cash_name;  ?></a> </h5>
									 
										<div class="clearfix mb-15"></div>
									 
									
									<a target='_blank' href='<?php echo $cash_link;  ?><?php echo $cash_name;  ?>' class='btn btn-block  btn-success'> Send / Request &raquo; </a>
									<div class="clearfix mb-10"></div>
								</div>
									
									
									<?php 
								if( get_user_meta($user->ID, $metaKEY , 1)){ $tumblr_name = get_user_meta($user->ID, $metaKEY , 1); }
								if( get_user_meta($user->ID, $post_slug . "_link" , 1)){ $tumblr_name = get_user_meta($user->ID, $metaKEY , 1); }
								
								
								if( get_user_meta($user->ID, $metaKEY , 1)
									|| get_user_meta($user->ID, $post_slug . "_link"  , 1)
								
								 ){  
								 
								 // echo $tumblr_name; 
								$tumblr_name =  str_replace(".","",$tumblr_name);
								 $tumblr_name =  str_replace("tumblr","",$tumblr_name);
								 $tumblr_name =  str_replace("com","",$tumblr_name);
								 
								//echo '<hr>';
								
								 // echo $tumblr_name; 
								 
								 
								 ?>
								 
								 <div class="col-xs-4 img-thumbnail">
									<br>
									 <a target='_blank' href="<?php echo $website_link;  ?><?php echo $tumblr_name;  ?>" target="_blank"><img class='img-thumbnail' src='<?php echo get_stylesheet_directory_uri(); ?>/images/icons/icon-<?php echo $post_slug;  ?>.png' width='65' height='65'>
									 </a>
										<div class="clearfix mb-5"></div>
										<h5 id='<?php echo $tumblr_name;  ?>' class='walls'><a target='_blank' href="<?php echo $website_link;  ?><?php echo $tumblr_name;  ?>" target="_blank"><?php echo $tumblr_name;  ?></a> </h5>
									 
										<div class="clearfix mb-15"></div>
									 
									
									<a target='_blank' href='<?php echo $website_link;  ?><?php echo $tumblr_name;  ?>' class='btn btn-block  btn-primary'> Visit Twitter &raquo; </a>
									<div class="clearfix mb-10"></div>
								</div>
								 
								
								 <?php
								 }else{ continue; }
						?>
									<div class='clearfix'></div>
						
									</div>
									
									
									<div class='clearfix'></div><br>
									<?php
									$count++;
									if( ($count % 2) == 0 ){ 
						?>					
				
								<div class='visible-xs'></div>

						<?php		}else if( ($count % 4) == 0 ){ 
						?>					
				
								<div class='clear'></div>

						<?php		}else{
							
							?> 
							
							<?php
									}
								}// END STATE IF
			 
			 
        }
    }
else {
 echo '<h4>No agents found.</h4>';
}

//echo $index; 

		
	
			
		?>
		<div class='clearfix'></div>
  </div>   
    <div class='clearfix'></div>
