<center>
<div class='clearfix'></div>
		
	<?php
	//get_template_part('content', 'random-post');
	
	get_template_part('ad-partner', 'ssixxx');
	
	?>
	<center>
	<?php
	get_template_part('ad', '300-250-1');
	
	?>
    </center>
    
    <div class='clearfix mb-15'></div>
	<div class="1col-sm-offset-1 1col-sm-10 img-thumbnail btn-block hidden-xs  ads ad-shift"> 
				    	        <div class='clearfix mb-5'></div>	
    	<center>
    	    <b> Featured Partner </b>
	<div class='clearfix mb-5'></div>
    		<a target="_blank" href="//ssixxx.com"><img src="http://dlfreakfest.org/wp-content/uploads/2017/12/ssiprojects-ssixxx-site-sm.jpg" width="325"></a>
    	        <div class='clearfix mb-10'></div>
    	</center>
	</div>
	<div class='clearfix mb-15'></div>



	<?php //get_template_part('ad', '300-250-2'); 
?>

<!--<div class='clearfix mb-15'></div>-->
</center>