	
							
							<div class='1hidden video-set col-md-12 well1'>
			<div class='col-md-12'>

				
			<?php 
				
				
    $lead = $post;	
				
				
				echo "<div class='' >";
			//	echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>";
				
					if ( has_post_thumbnail( $lead->ID ) ) {
    			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $lead->ID ), array(30,30) );	
						
   						if ( ! empty( $large_image_url[0] ) ) {
        						echo '<a href="' . esc_url( $large_image_url[0] ) . '" title="' . the_title_attribute( array( 'echo' => 0 ) ) . '">';
        						//echo get_the_post_thumbnail( $lead->ID, array(50,50) ); 
        						echo '</a>';

   					 	}
					}
				echo "</div>";
				?>
				<a href='/?p=<?php echo $lead->ID; ?>'> <img src='<?php echo esc_url( $large_image_url[0] ); ?>' class='circle pull-left hidden'></a>
				
			</div>

			<div class='col-md-4 hidden'>
					<div class='visible-xs'><br><br></div>
					<h4>Photo Set</h4>
					<hr>
					
				<?php
						$shortcode = get_field( 'gallery_shortcode', $lead->ID );
						echo do_shortcode($shortcode);

				 ?>
				<div class='clear'></div><br><br>

				<p class="btn btn-block btn-lg hidden" style="text-align: center;"><a href="<?php echo $lead->guid; ?>">View Preview</a></p>
				<p class="btn btn-block btn-lg hidden" style="text-align: center;"><a href="/subscribe/">Subscribe Now!</a></p>
			</div>
			<div class='clearfix'></div>
			
			<h4 class="well"> <a href='/?p=<?php echo $lead->ID; ?>'> <img src='<?php echo esc_url( $large_image_url[0] ); ?>' class='img-thumbnail circle alignleft'></a><a href='/photo/<?php echo $lead->post_name; ?>'> <?php echo $lead->post_title; ?> </a> <small>  -- <?php echo get_the_date( 'F d - h:i A' , $lead->ID ); ?> </small></h4>
		</div>