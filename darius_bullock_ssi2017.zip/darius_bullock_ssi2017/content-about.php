<div class='clearfix'></div>


<section id='about' class='about <?php if( !is_front_page() ){ ?> page-pad <?php } ?>'>
		
		<div class=''>
			<br>
			<div class="col-md-6 hidden">
				<a href='/my-life/'><div class='btn col-xs-12 hidden'>My BackGround</div></a>
				
				<a href='/brands' target='_blank'><div class='btn col-xs-12 hidden'>My Brand</div></a>
				
				<a href='/lifestyle/'><div class='btn col-xs-12 hidden'>My LifeStyle</div></a>
			</div>
			
			<div class="col-md-6 ">
				<a href='/my-life/'><div class='btn col-xs-12 '>The Owner</div></a>
				
				<a href='/inc/' target='_blank'><div class='btn col-xs-12 '>The Brand</div></a>
				
				<a href='/mission/'><div class='btn col-xs-12 '>The Mission</div></a>
				<div class='clearfix'></div><br>
			</div>
			<div class='clear visible-xs visible-sm'></div>
			<div class="col-md-6">
			
			
			
			
				
				<?php the_post_thumbnail(); ?>
				
				
				<img class='img-responsive aligncenter' src='/wp-content/uploads/2015/09/Be-the-best-you-9-5-15.jpg'>
			</div>
		</div>
	<div class='clearfix'></div>
	</section>

