<div class='clearfix'></div>

<?php
	if ( !is_user_logged_in()  ) {
		 
 ?>

				<div class='well mb-0'>
							
					<div id='join' style='display: block;' class='text-center'>
					<h4>Join Today - 100% FREE!</h4><hr>
					<a href='/register' class='btn btn-success btn-lg btn-block hidden1'>Join Now</a>
					</div>
					
					<br>

					<div id='login' style='display: block;' class='text-center'>
						<center><h4>Already A Member?</h4></center><hr>
						<a href='/login' class='btn btn-success btn-lg btn-block hidden'>Login Here</a>
						<a href='/profile' class='btn btn-success btn-lg btn-block hidden1'>Enter Here &raquo;</a>
					</div>
					
					<div class='clearfix'></div>
				</div>
			
			
		<div class='clearfix'></div>
		
<?php

	}else{
			$current_user = wp_get_current_user();
		?>	
		
		
	

		
		
		
		
		
		
		
		
		
		
		
		
			<div class='well yellow mb-0 ' style='padding: 20px 5px 0;'>
			
				<div class='container-fluid'>
					<div class='row'>
							<?php 
					
					get_template_part('content', 'welcome-rsvp');
					//get_template_part('content', 'dashboard-member'); 
					
					?>
					</div>
				</div>
				<div class='hidden1 well yellow mb-0'>
				
					<center>Members Area</center>
					<div class='clearfix'></div><hr><br>
					
						
					
		<div class='col-sm-5 '>
							
							
							
							
							
								
				<div class='clear'></div>
		<?php if( is_user_logged_in() ){ ?>
		<div class="  text-center well">

			<!-- <h3>Member <?php if( is_user_logged_in() ){ echo "Profile"; }else{ echo "Spotlight"; } ?></h3> -->
			<?php

				if( is_user_logged_in() ){
				    $current_user = wp_get_current_user();
				 /**
				     * @example Safe usage: $current_user = wp_get_current_user();
				     * if ( !($current_user instanceof WP_User) )
				     *     return;
				     */

				?>
			
			<div class=" ">
			
			
			
			
			
			
			
				<div class=" row">
			
				<div class="col-xs-5 col-md-4">
				
				
					<a target='_blank' href='/members-list/<?php echo $current_user->user_nicename; ?>/profile/change-avatar/' class=' '>
						<?php //echo do_shortcode("[bp_profile_gravatar]"); 
						
						
						
						?>
						
						
								<?php 
				
				echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>";
				
				
				
					if (  get_avatar($current_user->ID)  ) {
						$avatar_URL  = get_avatar_url($current_user->ID);
						
    
						?>
						
							<?php echo get_avatar($current_user->ID, 150); ?>
						
						<?php 
					}else{
						?>
						<img src='http://ssixxx.com/wp-content/uploads/2016/08/man-blank-profile.png' class='img-responsive aligncenter' width='150'>
					
						<?php 
						
					}
		
				?>
				
				
						<br>
						edit
					</a>
				
				
						<br>
					<a target='_blank' href='/members-list/<?php echo $current_user->user_nicename; ?>/profile/change-avatar/' class=' '>
					
				
						<?php //echo do_shortcode("[bp_profile_gravatar]");
								//bp_member_avatar('type=full&width=100&height=100');
						?>
						<br>
						
					</a>
					
						

				</div>
				<div class="col-xs-7 col-md-8 text-center report">
				
					<b><?php echo '<h4><b>' . $current_user->display_name . '</b></h4>' ?></b>
					<hr>
					
					<center>
					<?php	

							if( get_user_meta($current_user->ID, 'MX_user_age' , 1) ){
										echo get_user_meta($current_user->ID, 'MX_user_age' , 1) . ' | ';
							}else{
										echo '- | ';
							}
							if( get_user_meta($current_user->ID, 'MX_user_height_ft' , 1) ){
										echo get_user_meta($current_user->ID, 'MX_user_height_ft' , 1) . "' " . get_user_meta($current_user->ID, 'MX_user_height_in' , 1) . '" | ' ;
							}else{
										echo '- | ' ;
							}
							if( get_user_meta($current_user->ID, 'MX_user_weight' , 1) ){
										echo get_user_meta($current_user->ID, 'MX_user_weight' , 1) . "<br>";
							}else{
										echo '- <br>';
							}
								?>
					</center>
					
					<div class='clearfix'></div><br>
			
				<div class='text-center small'>
				Location<br>
				<b><?php 
				
					$closet = 0;
								if ( get_user_meta($current_user->ID, 'MX_user_city', 1 ) && get_user_meta($current_user->ID, 'MX_user_state', 1) ){

																		echo ' <span style="text-transform: capitalize;">' . get_user_meta($current_user->ID, 'MX_user_city', 1 ) . '</span>, ';
																		echo get_user_meta($current_user->ID, 'MX_user_state', 1) ;

								}
								else if ( get_user_meta($current_user->ID, 'MX_user_state', 1) ){
									echo  get_user_meta($current_user->ID, 'MX_user_state', 1);
								}
								else{
									$closet = 1;
									echo '-';
								}				
								
			?></b>
			</div>
			
			
			
			

				</div>
					
				
			
			
			
							
						
					<div class="btn-group btn-group-justified1 text-center col-md-8 col-xs-12">
					<div class='clearfix'></div><hr class="mb-5">
					<center>
						<a href="/edit-profile/?ID=<?php echo  $current_user->ID; ?>" class="btn btn-default">Edit Profile</a>
						<a  href="/user-profile/?ID=<?php echo  $current_user->ID; ?>" class="btn btn-info">View Profile</a>
					</center>
					<div class='clearfix mb-5'></div>
					</div>
				
				
							
	
				<div class='clearfix'></div>	
		<div class='well green hidden'>
					<h4>YungDADDY Requests<hr></h4>		
								
		<a  target='_blank' href='/cash' class='btn btn-success btn-block hidden1'> REQUEST Money >> </a>
		
		<a target='_blank' href='/bae?ID=<?php echo $Model_ID; ?>' class='btn btn-info btn-block hidden1'> REQUEST a DATE >> </a>
		
		<a target='_blank' href='/request' class='btn btn-info btn-block hidden1'> REQUEST a Meeting >> </a>
		
		
		
		</div>
				
					
					<?php //echo do_shortcode("[wpmem_form login]"); ?>
				
				
				
				
				
				

			</div>

			<?php } ?>
			<div class='clearfix'></div>	
			<div class="text-left hidden1 well green mb-0">
			<hr class="mb-5 hidden1">
			
					<?php	//bp_activity_latest_update($current_user->ID);
					  ?>

					<a href='/activity' class='status btn btn-default btn-sm pull-right'>Update</a>
			</div>
		</div>
		
		
		
		
		<?php } ?>

							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							

				<div class=' text-center'>
					
					<?php  echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>"; ?>
				
				</div>
	
					<div class='clearfix'></div>
				
		
			</div>
		</div>		
		<div class='col-sm-7 text-center'>
		
				
		
				<?php 
					get_template_part('content' , 'member-quicknav');
				?>
				<br>
			<a href='/' class='btn btn-primary hidden1 btn-block'>Home</a>
			
			<a href='/events' class='btn btn-warning btn-block'>Events</a>
			<a href='/groups/' class='btn hidden1 btn-warning btn-block'>Groups</a>
			
			<a href='/members-list/' class='btn hidden1 btn-warning btn-block'>My Friends</a>
			<a href='/members' class='btn btn-primary btn-block'>All Members</a>
			<!--<a href='/photos' class='btn btn-default btn-block'>Photos</a>-->

		<div class='clearfix'></div><br>	
				
					
					<?php echo do_shortcode("[wpmem_form login]"); ?>
		</div>		
		<div class='clearfix'></div>
		</div>	
				<div class='clearfix'></div>
				</div>
			<div class='clearfix'></div>
			</div>
		<div class='clearfix'></div>
		
		<?php
	}
 ?>	

<div class='clearfix'></div>