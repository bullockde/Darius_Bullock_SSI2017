 <div class="clearfix mb-20"></div><br>
<h1 class="entry-title text-center">Category: <?php single_cat_title( $prefix = '', $display = true ); ?></h1>
<div class="clearfix mb-0"></div>

<?php get_header('preview');   ?>
    
  <br>

            <div class="porn posts">

			
		
<?php if(/*$paged == */1){ ?>
<div class='spotlight col-xs-12 col-lg-8 col-lg-offset-2 col-sm-12 col-sm-offset-0 hidden1 well yellow'>
	<div class='col-xs-6'>
		<?php
				$categories =  get_categories('child_of=545&hide_empty=1');
									//$categories =  get_the_category('pornstars');
						shuffle( $categories );
						//print_r($categories[0]);
						$spot = $categories[0]->name;
						
						echo "<h2>Star Spotlight: " . $spot . "</h2>";
		?>
		
				<div class='col-xs-6 pic '>
					<?php

						if( z_taxonomy_image_url($categories[0]->term_id) ){
							echo "<img class='floatl margin10' width='175' src=" . z_taxonomy_image_url($categories[0]->term_id) . " />";
						}else{
							echo "Suggest A Photo! --> <a href='#'>Here</a>";
						}
					?>
				</div>
				
				<div class='col-xs-6 bio pad10 '>
						
					
						<b>Age:</b> <?php echo get_field('cat_age', 'category_' .  $categories[0]->term_id ); ?><br><br>
						<b>Height:</b> <?php echo get_field('cat_height', 'category_' .  $categories[0]->term_id ); ?><br><br>
						<b>Weight:</b> <?php echo get_field('cat_weight', 'category_' .  $categories[0]->term_id ); ?><br><br>
						<b>Ethnicity:</b> <?php echo get_field('cat_ethnicity', 'category_' .  $categories[0]->term_id ); ?><br><br>
						<b>Cock Size:</b> <?php echo get_field('cat_size', 'category_' .  $categories[0]->term_id ); ?><br><br>
						<a target='_blank' href='http://twitter.com/<?php echo get_field('cat_twitter', 'category_' .  $categories[0]->term_id ); ?>'>Follow</a> him on Twitter<br><br>
					
				</div>
				

				<div class='clearfix'></div>
				
				
</div>
<div class='col-xs-6 '>
					
					
										<?php
						
							$movies = get_posts( array( 'post_type'     => 'ssi_porn', 'category_name' =>  $categories[0]->name , 'orderby' => 'rand', 'posts_per_page' => 4  ) );
							//print_r( $music );
							echo "<h2>Featured Movies</h2>";

		echo "<div id='mid'>";
							foreach($movies as $post){ ?>
							
							
							<div class='hit '>
								<a href='<?php echo home_url() . "/gay/" . $post->post_name; ?>'>
									<div class='col-md-2'>
									<?php
										
										echo get_the_post_thumbnail( $post->ID , array(50,50) );
									?>
									</div>
									<div class='col-md-10 info floatl'>
										<div class='artist'>
											<?php echo $post->post_title; ?>
										</div>
										<button type="button" class=" pull-right btn btn-default btn-sm">
										  <span class="glyphicon glyphicon-play"></span> Play
										</button>
									</div>
							
									
									</a>
									<div class='clearfix'></div><hr>
							</div>
								
							<?php
							}
		echo "</div>";
						?>
					
					
				</div>
				
				 <div class="clear"></div>
			</div>
<?php } ?>




<?php  

  wp_reset_query();
  
  
	$number = 12;
	if( 0 ){ $number = $number+2; }
	
	
	$current_page = get_queried_object();
	
	
    $category     = $current_page->slug;
	$paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;  
	//$paged = get_query_var('paged');
?>


    <?php
        

      //  wp_reset_query();
        $query = new WP_Query( 
            array(
                'paged'         => $paged, 
                'category_name' => 'gay',
				'orderby'		=> 'modified',
                'order'         => 'desc',
                'post_type'     => 'ssi_porn',
                'post_status'   => 'publish',
				'posts_per_page'   => $number
            )
        );

        if ($query->have_posts()) {
               while ($query->have_posts()) { 
               $query->the_post(); ?>
			   
			   <div class='col-sm-4 col-md-3'>
			   <?php get_template_part('content' , 'post'); ?>
				</div>
                
                <?php
            }

           
        }
        ?>

				
            </div>

   
  
	<div class="clear"></div><br>
            <div class="paginator container">
						
                        <?php if (function_exists("pagination")) {
    
                               pagination($additional_loop->max_num_pages);
                            
                            } ?>
						

                    </div>
                    
                    <div class="clear"></div>
    
<?php get_footer("kik"); ?>
