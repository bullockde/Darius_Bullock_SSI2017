<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

if ( !function_exists( 'chld_thm_cfg_parent_css' ) ):
    function chld_thm_cfg_parent_css() {
        wp_enqueue_style( 'chld_thm_cfg_parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array( 'twentysixteen-fonts','genericons' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10 );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_separate', trailingslashit( get_stylesheet_directory_uri() ) . 'ctc-style.css', array( 'chld_thm_cfg_parent','twentysixteen-style','twentysixteen-block-style' ) );
        
        ?>
        
	<link href="https://fonts.googleapis.com/css?family=Amita|Boogaloo|Bowlby+One+SC|Bungee|Bungee+Inline|Calligraffitti|Cedarville+Cursive|Ceviche+One|Contrail+One|Damion|Faster+One|Fredoka+One|Give+You+Glory|Holtwood+One+SC|Kalam|Kaushan+Script|Knewave|Londrina+Solid|Marck+Script|Merienda+One|Montserrat+Subrayada|Patrick+Hand+SC|Permanent+Marker|Rye|Trirong&display=swap" rel="stylesheet">


	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<?php
           // wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
      //  wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/dash-css.css' );
        
        
       // wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/gq_style.css' );
        
       // wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css' );
        

    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

// END ENQUEUE PARENT ACTION


function na_get_gallery_image_urls( $post_id, $number = false ) {

    $post = get_post($post_id);
    $count = 0;

    // Make sure the post has a gallery in it
    if( ! has_shortcode( $post->post_content, 'gallery' ) )
        return;

    // Retrieve all galleries of this post
    $galleries = get_post_galleries_images( $post );

    // Loop through all galleries found
    foreach( $galleries as $gallery ) {

        // Loop through each image in each gallery
        foreach( $gallery as $image ) {

            if ( $number == $count )
            return;

            echo '<img src="'.$image.'">';
            $count++;

        }

    }

 }




function load_more_posts() {
    $args = json_decode(stripslashes($_POST['query']), true); // Retrieve the query parameters sent via AJAX
    $args['paged'] = $_POST['page'] + 1; // Increment the page number
     $args['post_status'] = 'publish'; 
	
    // Perform your custom query to fetch the additional posts
    $query = new WP_Query($args);

    // Loop through the posts and generate the HTML markup
    if ($query->have_posts()) {
        while ($query->have_posts()) {
           $nxt_post = $query->the_post();
            // Generate the HTML markup for each post
            //echo '<div>' . get_the_title() . '</div>';
            
            //if( $nxt_post->post_type === "post" ) get_template_part( "template-parts/content" );
            //else echo '<div>' . get_the_title() . '</div>';
			
			get_template_part( "template-parts/content", "post"  );
			
            
        }
    }
    
    wp_die(); // Always include this to terminate the AJAX request properly
}
add_action('wp_ajax_load_more_posts', 'load_more_posts');
add_action('wp_ajax_nopriv_load_more_posts', 'load_more_posts');




function display_theme_files(){
   $theme = wp_get_theme();
   $files = $theme->get_files();

   echo '<h2>All Theme Files</h2>';
   echo '<ul>';
   foreach ($files as $file => $path) {
      echo '<li><strong>' . $file . '</strong>: ' . $path . '</li>';
      
    //  $file = $file; // Replace $file with the variable containing the file name

if (strpos($file, 'page-') !== false) {
    $page_slug = str_replace(array('page-', '.php'), '', $file);
    
    // Check if the page exists by slug
    $existing_page = get_page_by_path($page_slug);

    if (!$existing_page) {
        // Create the page if it doesn't exist
        $page_args = array(
            'post_title' => ucwords(str_replace('-', ' ', $page_slug)), // Generate a title based on the slug
            'post_name' => $page_slug,
            'post_status' => 'publish',
            'post_type' => 'page',
        );

    //    $new_page_id = wp_insert_post($page_args);

        if ($new_page_id !== 0) {
            // Page created successfully
            echo 'Page created with ID: ' . $new_page_id;
        } else {
            // Failed to create the page
            echo 'Failed to create the page.';
        }
    } else {
        // Page already exists
        $existing_page_url = get_permalink($existing_page->ID);
        //echo 'Page already exists with slug: ' . $page_slug;
        echo 'Page already exists with slug: ' . $page_slug . '. <a href="' . $existing_page_url . '">View the page</a>';
    }
} else {
    // File name doesn't contain "page-"
    echo 'File name does not contain "page-".';
}

   }
   echo '</ul>';
}

//add_shortcode('theme_files', 'display_theme_files');

function display_theme_files_dropdown(){
   $theme = wp_get_theme();
   $files = $theme->get_files();

   echo '<h2>Select a Theme File</h2>';
   echo '<select id="theme_files_dropdown">';
   foreach ($files as $file => $path) {
      echo '<option name="filename" value="' . $path . '">' . $file . '</option>';
   }
   echo '</select>';
}

//add_shortcode('theme_files_dropdown', 'display_theme_files_dropdown');



if( isset( $_GET['update_post'] ) ){ 
	
	$ID = $post;
	$ID = get_post( $_GET['ID'] );
	
	wp_update_post($ID); 
}
if( isset( $_GET['make_draft'] )){
	
	$ID = $post->ID;
	$ID = $_GET['ID'];
	
	 $my_post = array(
      'ID'           => $ID,
      'post_title'   => get_the_title($ID),
     'post_content' => get_the_content($ID),
	  'post_status' => 'draft'
  );

// Update the post into the database
  wp_update_post( $my_post );
	
}

function count_user_posts_by_type( $userid, $post_type ) 
{
    $args = array(
        'numberposts'   => -1,
        'post_type'     => $post_type,
        'post_status'   => array( 'publish'),
        'author'        => $userid
    );
    $count_posts = count( get_posts( $args ) ); 
    return $count_posts;
}



function dispMailbox()
    {
     /* global $user_ID, $user_login;

	  
	 function my_getAnnouncementsNum()
    {
      global $wpdb; //message_read = 12 indicates that the msg is an announcement :)
	  global $table_prefix;
	  $tableMsgs = $table_prefix."cartpauj_pm_messages";
      $results = $wpdb->get_results("SELECT * FROM {$tableMsgs} WHERE message_read = 12 ORDER BY `id` DESC");
      return $wpdb->num_rows;
    }
	function my_getNewMsgs()
    {
		//echo "Get Messages!";
      global $wpdb, $user_ID;
	  global $table_prefix;
		$tableMsgs = $table_prefix."cartpauj_pm_messages";
		$user_ID = get_current_user_id();
      $get_pms = $wpdb->get_results($wpdb->prepare("SELECT id FROM {$tableMsgs} WHERE (to_user = %d AND parent_id = 0 AND to_del <> 1 AND message_read = 0 AND last_sender <> %d) OR (from_user = %d AND parent_id = 0 AND from_del <> 1 AND message_read = 0 AND last_sender <> %d)", $user_ID, $user_ID, $user_ID, $user_ID));
   // print_r( $get_pms ); 
	 return $wpdb->num_rows;
	
    }
	
		$numAnn = my_getAnnouncementsNum();
	 // $numNew = 'test';
	  $numNew = my_getNewMsgs();
	   
		if( $numNew == 0 ){
			echo "<center><div class='alert-warning text-center mb-0 hidden'><a href='/mailbox/'>No Messages</a></div></center>";
			unset($_COOKIE['message_sound']);
			//setcookie( 'message_sound' , 'Yes' , time() - 3600, "/");
			
		} else if( $numNew > 0 ){
		
		  ?>
		  <div class='alert-success text-center mb-0'><a href='/mailbox/'>You Have (<?php echo $numNew; ?>) Message<?php if( $numNew > 1 ) echo "s"; ?>!</a></div>
		  <?php
			if( (!empty( $_COOKIE["message_sound"] )) || ( $_COOKIE["message_sound"] == "No") ){
				?>
		  <audio controls autoplay class='hidden'>
			<!--  <source src="horse.ogg" type="audio/ogg"> -->
			
			<!-- 
			
				AOL - Got Mail : http://dlfreakfest.org/wp-content/uploads/2020/01/aol-got-mail.mp3
				Bull Whip: /wp-content/uploads/2018/03/Whip-SoundBible.com-1988767601.mp3
			
			
			
			  <source src="/wp-content/uploads/2020/01/aol-got-mail.mp3" type="audio/mpeg">-->
		
			  <source src="/wp-content/uploads/2018/03/Whip-SoundBible.com-1988767601.mp3" type="audio/mpeg">
			  Your browser does not support the audio element.
			</audio>
		  <?php
		  
		  
		 // setcookie( "message_sound" , "Yes" , time() + 900, "/");
		  if( !empty($_COOKIE["message_sound"]) ){ setcookie( "message_sound" , "Yes" , time() + 900, "/"); }
		  
		  }
	  }else{
		   
		  //setcookie( 'message_sound' , 'No' , time() + 1600, "/");
	  }
	  
	    if( $numAnn > 0 ){
		
		  ?>
		  <div class='alert-warning text-center well yellow alert mb-0'><a href='/mailbox/'>New Alert!</a></div><br>
		  
		  <!--  
		  <audio controls autoplay class='hidden'>
			<source src="horse.ogg" type="audio/ogg"> 
			  <source src="/wp-content/uploads/2018/03/Whip-SoundBible.com-1988767601.mp3" type="audio/mpeg">
			  Your browser does not support the audio element.
			</audio>-->
		<!--  <audio autoplay id="myaudio">
			  <source src="http://www.zapsplat.com/wp-content/uploads/2015/sound-effects-four/animal_dog_panting_fast_short_recording.mp3">
			</audio>

			<script>
			  var audio = document.getElementById("myaudio");
			  audio.volume = 0.025;
			</script>-->
		  <?php
	  }
	  
	  
	  $header = "<div class='clear'></div><a href='/mailbox/'><div class='mail-box'><div class='mail-text col-xs-12'><center><img width='30' src='http://dlfreakfest.org/wp-content/uploads/2017/12/mailbox-512-e1512839799342.png' class='pell-left'> (<font color='red'>". $numAnn."</font>) Alerts - (<font color='red'>".$numNew."</font>) ".__("New Messages", "cartpaujpm")."</center></div></div></a>";
	  
	  */

		//return $header;
    }
    
    
    
    
    


function format_telephone($phone_number)
{
    $cleaned = preg_replace('/[^[:digit:]]/', '', $phone_number);
    preg_match('/(\d{3})(\d{3})(\d{4})/', $cleaned, $matches);
    return "1-{$matches[1]}-{$matches[2]}-{$matches[3]}";
}

function ssi_add_user(){
	
	$lead = get_post( $_POST['ID'] ); 
	
	//print_r($lead);
	
	if( get_field( "area_code", $lead->ID ) == '215' ){ $role = 'contact_215'; }
	else if( get_field( "area_code", $lead->ID ) == '717' ){ $role = 'contact_717'; }
	else if( get_field( "area_code", $lead->ID ) == '804' ){ $role = 'contact_804'; }
	else if( get_field( "area_code", $lead->ID ) == '202' ){ $role = 'contact_202'; }
	else if( get_field( "area_code", $lead->ID ) == '404' ){ $role = 'contact_404'; }
	else if( get_field( "area_code", $lead->ID ) == '757' ){ $role = 'contact_757'; }
	else if( get_field( "area_code", $lead->ID ) == '856' ){ $role = 'contact_856'; }
	else{ $role = 'contact'; }
	
	
		$username = explode(' ', $lead->post_title);
		$email = get_field( "lead_email", $lead->ID );
		
		if( count($username) == 1 ){ $first_name = $username[0]; $last_name = ''; }
		else if( count($username) == 2 ){ $first_name = $username[0]; $last_name = $username[1]; }
		else if( count($username) == 3 ){ $first_name = $username[0]; $last_name = $username[2]; }
		else{ $first_name = ''; $last_name = ''; }
		
		
		if( get_user_by('login', $username[0] ) ){ $name = $username[0] . "_" . get_field( "area_code", $lead->ID ); }
		else{  $name = $username[0]; }
			
			$userdata = array(
				'user_login'  =>  $name,
				'role'    =>  $role,
				'user_email' => $email,
				'user_pass'   =>  NULL,  // When creating an user, `user_pass` is expected.
				
				'first_name' => $first_name,
				'last_name' => $last_name,
			);
			
		$user_id = wp_insert_user( $userdata ) ;
				

			//On success
			if ( ! is_wp_error( $user_id ) ) {
				echo "<br>User created : ". $user_id;
			}else{
				echo "<br>User Add FAILED!! ";
			}
	
	
} /** Add Users **/


function post_to_draft() 
   {
      
		$postID = $_POST['ID'];
		$postURI = $_POST['URI'];
		
		//$header_loc = "Location:" + $postURI;

		  $my_post = array(
      			'ID'           => $postID,
     			 'post_status'   => 'draft',
			'URI' => $postURI
      			
 		 );

		// Update the post into the database
  		wp_update_post( $my_post );
		
		//echo "URL-----" . $postURI;

		//wp_redirect( $postURI );
		exit;
	
 }//end post_to_draft

 function ssi_update_user_role( $user_ID ) 
{
		$postID = $_POST['ID'];
		$postURI = $_POST['URI'];
		
		// NOTE: Of course change 3 to the appropriate user ID
		$u = new WP_User( $user_ID );
		
	if( $u->has_cap('subscriber') ){ 
		
		// Remove role
		$u->remove_role( 'subscriber' );

		// Add role
		$u->add_role( 'contributor' );
		
		echo "<center>Your Membership has Upgraded to: <u>Premium</u></center>" ;
	}else{
		echo "<center>Your Membership Level: <u>" . $u->get('roles') . "</u></center>" ;
	}
}
function post_updater() 
   {
      
		$postID = $_POST['ID'];
		$client_id = $_POST['client_id'];

		update_field( 'client_id', $client_id, $postID );
		
		// Update the post into the database
  		wp_update_post( $my_post );
		
		wp_redirect( $postURI );
		exit;
	
 }//end post_updater

function move_out(){

		//echo "<BR><BR><BR>Move Out Function";


		$post_id = $_POST['ID'];

		//echo "--->" . $post_id;

		$date_added = $_POST['move_out_date'];

		//echo "--->" . $date_added;

		update_field( "field_56946535d781c", $date_added , $post_id );
}

function insert_client() 
   {
      
		//echo "<BR><BR><BR>Insert Client";

		$postID = $_POST['ID'];
		$client_id = $_POST['client_id'];

		$date_added = $_POST['date_added'];

		$trans_date = $_POST['trans_date'];
		$trans_amount = $_POST['trans_amount'];
		$trans_time = $_POST['trans_time'];
		$trans_service = $_POST['trans_service'];
		$trans_location = $_POST['trans_location'];

		$notes = $_POST['notes'];

		$postURI = $_POST['URI'];


		// Create post object
		$my_post = array(

		'ID' => '',		
		 'post_date'	=> $date_added,
		 'post_title' => $_POST['client_name'] ,
		 'post_content' => $notes . "--" . get_post_field('post_content', $postID) . ' <br>--This post was added from ' . $_POST['cur_post_type'] . ' Page.',
		 'post_status' => 'publish'

		);

		// Insert the post into the database
		$post_id = wp_insert_post( $my_post );

		set_post_type( $post_id, $_POST['cur_post_type'] );

	if( $_POST['cur_post_type'] == 'trips'){

		update_field( "field_565e6b9158aa5", $_POST['start_date'] , $post_id );
		update_field( "field_565e6bab58aa6", $_POST['end_date'] , $post_id );
		update_field( "field_5665daffed560", $_POST['trip_state'] , $post_id );
		update_field( "field_5714c1226836d", $_POST['trip_area_code'] , $post_id );
		

		//header( $postURI );
		//exit;
		
	}
		
		//echo "New Client ID: " . $post_id;
		// Add field value
		update_field( "field_56120eb91c6ab", $_POST['client_email'] , $post_id );
		update_field( "field_561246bdee4a8", $_POST['client_phone'] , $post_id );
		update_field( "field_56120ea81c6aa", $_POST['client_city'] , $post_id );
		update_field( "field_56120e8a1c6a9", $_POST['client_state'] , $post_id );
		update_field( "field_5620520a18334", $_POST['trans_amount'] , $post_id );
		update_field( "field_567d5212671f3", $_POST['area_code'] , $post_id ); 


	$new_post = get_post( $post_id );
	$last_date = date("m/d/y", strtotime($new_post->post_date) );

	//echo "-->" . $last_date;
	
	if( $_POST['last_seen'] != '' ){
		update_field( "field_5656666d84821", $_POST['last_seen'] , $post_id );
	}else{
		update_field( "field_5656666d84821", $last_date , $post_id );
	}

	if( $_POST['last_contacted'] != '' ){
		update_field( "field_5656669d84822", $_POST['last_contacted'] , $post_id );
	}else{
		update_field( "field_5656669d84822", $last_date , $post_id );
	}

	if( $trans_date != '' ){
		$field_key = "field_56415f3cbceaf";
		$value = get_field( $field_key, $post_id );
		$value[] = array("date" => $trans_date , "location" => $trans_location , "time" => $trans_time , "service" => $trans_service , "trans_id" => $postID ,"rate" => $trans_amount );
		update_field( $field_key, $value, $post_id );

		
	}

		
		//echo "THIS POST ID: " . $postID;
		update_field( "field_56512b1afcceb", $post_id , $postID );

		wp_reset_query();
		
		//wp_redirect( $postURI );
		//exit;
	
 }//end insert_client

function insert_task() 
   {
      
		//echo "<br><br><br><br>-->INSERT TASK<br><br>";

		wp_reset_query();
		// Update post 37
		$postID = $_POST['ID'];
		$client_id = $_POST['client_id'];


		$date_added = $_POST['trans_date'];

		//echo "DATE-->" . $date_added;

		$date_added = date('Y-m-d H:i:s', strtotime($date_added) );

		//echo "DATE-->" . $date_added;

//exit;
		$trans_amount = $_POST['trans_amount'];
		$trans_time = $_POST['trans_time'];
		$trans_service = $_POST['trans_service'];
		$trans_location = $_POST['task_details'];

		$postURI = $_POST['URI'];

		//echo "Post URI-->" . $postURI;

		// Create post object
		$my_post = array(
		  
		  'ID' => '',
		 'post_date'	=> $date_added,
		 'post_title' => $_POST['trans_service'] ,
		 'post_content' => ' <br>--' . $_POST['task_details'] ,
		 'post_status' => 'publish'

		);
		

		// Insert the post into the database
		$post_id = wp_insert_post( $my_post );
		
		set_post_type( $post_id, 'to_do' );

		//echo "--->New Transaction ID: " . $post_id;
		// Add field value
		update_field( "field_56202cbadb9a0", $_POST['client_phone'] , $post_id );
		update_field( "field_56202ce4db9a1", $_POST['client_city'] , $post_id );
		update_field( "field_56202cf5db9a2", $_POST['client_state'] , $post_id );
		update_field( "field_56202d2fdb9a4", $trans_amount , $post_id );
		update_field( "field_563b012c7be2a", $_POST['income_expense'] , $post_id );
		update_field( "field_56549946e545f", $trans_service , $post_id );
		update_field( "field_56549914e545d", $trans_time , $post_id );
		update_field( "field_56549930e545e", $trans_location , $post_id );
		update_field( "field_577e669017e48", $_POST['assigned_to'] , $post_id );
		
		$field_key = "field_56415f3cbceaf";
		$value = get_field( $field_key, $postID);

		
		$value[] = array("date" => date("m-d-Y", strtotime($date_added) ) , "location" => $trans_location , "time" => $trans_time , "service" => $trans_service, "trans_id" => $post_id , "rate" => $trans_amount );
		update_field( $field_key, $value, $postID );

		//echo "THIS POST ID: " . $postID;
		update_field( "field_56512b1afcceb", $post_id , $postID );


		update_field( "field_56512b1afcceb", $client_id , $post_id );
		//update_field( "last_contacted", $date_added , $post_id );

		
		//echo "<br><br><br><br>-->INSERT TRANSACTION DONE<br><br>";


		wp_reset_query();
		
		//header( $postURI );
		//exit;
	
 }//end insert_transaction

function insert_transaction() 
   {
      
		//echo "<br><br><br><br>-->INSERT TRANSACTION<br><br>";

		wp_reset_query();
		// Update post 37
		$postID = $_POST['ID'];
		$client_id = $_POST['client_id'];


		$date_added = $_POST['trans_date'];

		//echo "DATE-->" . $date_added;

		$date_added = date('Y-m-d H:i:s', strtotime($date_added) );

		//echo "DATE-->" . $date_added;

//exit;
		$trans_amount = $_POST['trans_amount'];
		$trans_time = $_POST['trans_time'];
		$trans_service = $_POST['trans_service'];
		$trans_location = $_POST['trans_location'];

		$postURI = $_POST['URI'];

		//echo "Post URI-->" . $postURI;

		// Create post object
		$my_post = array(
		  
		  'ID' => '',
		 'post_date'	=> $date_added,
		 'post_title' => $_POST['client_name'] ,
		 'post_content' => get_post_field('post_content', $postID) . ' <br>--This post was added from Client Page.',
		 'post_status' => 'publish'

		);
		

		// Insert the post into the database
		$post_id = wp_insert_post( $my_post );
		
		set_post_type( $post_id, 'transactions' );

		//echo "--->New Transaction ID: " . $post_id;
		// Add field value
		update_field( "field_56202cbadb9a0", $_POST['client_phone'] , $post_id );
		update_field( "field_56202ce4db9a1", $_POST['client_city'] , $post_id );
		update_field( "field_56202cf5db9a2", $_POST['client_state'] , $post_id );
		update_field( "field_56202d2fdb9a4", $trans_amount , $post_id );
		update_field( "field_563b012c7be2a", $_POST['income_expense'] , $post_id );
		update_field( "field_56549946e545f", $trans_service , $post_id );
		update_field( "field_56549914e545d", $trans_time , $post_id );
		update_field( "field_56549930e545e", $trans_location , $post_id );
		update_field( "field_57467e24917c2", $_POST['meeting_place'] , $post_id );
		
		if( $_POST['trans_amount'] != '' ){
		
			$field_key = "field_56415f3cbceaf";
			$value = get_field( $field_key, $postID);

		
			$value[] = array("date" => date("m-d-Y", strtotime($date_added) ) , "location" => $trans_location , "time" => $trans_time , "service" => $trans_service, "trans_id" => $post_id , "rate" => $trans_amount );
			update_field( $field_key, $value, $postID );
	
		}

		//echo "THIS POST ID: " . $postID;
		update_field( "field_56512b1afcceb", $post_id , $postID );


		update_field( "field_56512b1afcceb", $client_id , $post_id );
		//update_field( "last_contacted", $date_added , $post_id );

		
		//echo "<br><br><br><br>-->INSERT TRANSACTION DONE<br><br>";


		wp_reset_query();
		
		//header( $postURI );
		//exit;
	
 }//end insert_transaction

function insert_song() 
   {
      
		echo "<BR><BR><BR>Insert Song";

		$postID = $_POST['ID'];
		$postURI = $_POST['URI'];

		// Create post object
		$my_post = array(

		 'ID' => '',		
		 'post_date'	=> $_POST['date_added'] ,
		 'post_title' => $_POST['song_name'] ,
		 'post_content' => 'This post was Added to Music.',
		 'post_status' => 'publish'

		);

		// Insert the post into the database
		$post_id = wp_insert_post( $my_post );

		if( $_POST['cur_post_type'] == 'video') { set_post_type( $post_id, 'video' ); }
		else{ set_post_type( $post_id, 'music' ); }
		

		set_post_format( $post_id , 'video' );

		// Add field value
		update_field( "field_56059e2a326c2", $_POST['youtube_id'] , $post_id );
	

		wp_reset_query();
		
		//wp_redirect( $postURI );
		//exit;
	
 }//end insert_song

function checkVideoExists( $videoId ) {
        $headers = get_headers('http://img.youtube.com/vi/' . $videoId . '/default.jpg');
        if (!strpos($headers[0], '200')) {
           // echo "The YouTube video you entered does not exist";

	  $my_post = array(
      			'ID'           => $videoId,
     			 'post_status'   => 'draft',
			'URI' => $postURI
      			
 		 );

		// Update the post into the database
  		wp_update_post( $my_post );
            return false;

        }
	return true;
}


  function ssi_update_cf() {
	 

		foreach ($_POST as $param_name => $param_val) {
			
			update_post_meta( $_POST['ID'], $param_name, $param_val  );

		}
	
	$my_post = get_post( $_POST['ID']  );

		// Update the post into the database
  	wp_update_post( $my_post );

	
 }//end ssi_update_cf
 
 //add_action( 'save_post', 'ssi_new_contact', 10, 3 );
 function ssi_new_contact() {
	 

      echo "New Contact Adding!!!";

		$my_post = array(

			'ID' =>  '',	
			'post_title' => $_POST['post_title'],
			'post_status' => 'publish',
			'post_type' => 'ssi_contacts'
			);
			 
			// Update the post into the database
		$_POST['ID'] = wp_insert_post( $my_post );
		
		echo "Added!!! --> " . $_POST['ID'] ;
	
	 
	 
	foreach ($_POST as $param_name => $param_val) {
			add_post_meta($_POST['ID'], $param_name, $param_val, true);
			update_post_meta( $_POST['ID'], $param_name, $param_val  );

		}
	 
	echo "<br> --- ENTER ADD SOCIAL ---";
	
	echo "<br> ---" . $_POST['site'] . "<br> ---" . $_POST['username'] . "<br> ---" . $_POST['ID'] ;
	
    update_field( $_POST['site'], $_POST['username'] , $_POST['ID'] ) ;
	
	echo "Added Social!!!";

	
	$my_post = array(

			'ID' =>  $_POST['ID'],
			'post_content' => 'added'
			
			);
			
	$my_post = get_post( $_POST['ID'] );		

	//echo "<br> New Contact Added!!!";
	
	echo "<br> THE-POST--> " ;
	print_r($my_post);
	
	echo "<br> THE-CAT--> " ;
	
	$category = get_term_by('slug', $_POST['contact_type'], 'category');
		
		print_r($category);
		wp_set_post_categories( $_POST['ID'] , $category->term_id  );

		// Update the post into the database
  	wp_update_post( $_POST['ID'] );
	
	$return_page = $_POST['URI'];
	
	echo " <br>THE-PAGE--> " ;
	print_r($return_page);
	
	
	// Update the post into the database
  	
	wp_publish_post( $_POST['ID'] );
	//wp_update_post( $my_post );
	
	//wp_redirect( $return_page );
	
	//wp_redirect( $_POST['URI'] );
	//exit;
	
	//add_social();
	
 }//end ssi_new_contact
 
 
if( isset($_POST['new_post']) ){
	
	//$date_added = date('Y-m-d H:i:s', strtotime($_POST['date_added']) );
// Create post object

		//$post_status = $_POST['post_status']
		
		$my_post = array(
		  
		  'ID' => '',
		// 'post_date'	=> $date_added,
		 'post_type' => $_POST['post_type'] ,
		 'post_title' => $_POST['post_title'] ,
		'post_content' => $_POST['post_content'] . '',
		 'post_status' => 'publish'

		);
		

		// Insert the post into the database
		$post_id = wp_insert_post( $my_post );
		
		foreach ($_POST as $param_name => $param_val) {
			add_post_meta($post_id, $param_name, $param_val, true);
			update_post_meta( $post_id, $param_name, $param_val  );

		}
		
		//set_post_type( $post_id, 'ssi_staff' );
		
} 
 
 
 
 
 
 
 
 