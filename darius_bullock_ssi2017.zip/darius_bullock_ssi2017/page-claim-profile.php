<?php 
 if( is_user_logged_in() ){
	$user = $current_user = wp_get_current_user();
	$pg = '/edit-profile/?ID=' . $user->ID;
	//wp_redirect( $pg );
}

get_header('no-login'); ?>
<br>
    
    <div class="claim-profile container ">
		
            <?php if(have_posts()) { ?>
   
                <?php while (have_posts()) : the_post(); ?>                    
                
                <div class="single-post" id="post-<?php the_ID(); ?>">
					
                    <div class='col-md-8 text-center well'>
						<h3>Are you <?php echo get_the_title($_GET['ID']); ?>?</h3><br>
						
						<?php get_template_part( 'content', 'add-profile' ); ?>
						<?php 
						
							if( get_the_post_thumbnail( $_GET['ID'], 'medium' ) ){
								echo get_the_post_thumbnail( $_GET['ID'], 'medium' );
							}else{
								echo get_avatar();
							}
							 
						
						
						?>
						<div class='clearfix'></div><br>
						<button id='claim'>Claim Ad >></button>
					</div>
					<div class='col-md-4 '>
					
						<div id='claim'  class='well' style='display: none;'>
					
							<?php the_content(); ?>
						</div>
						
					<div class='clearfix mb-15 visible-xs'></div>
					<center>			
						<?php get_template_part( 'ad', '300-250-1' ); ?>
					</center>		
					</div>
					
					<div class='clearfix'></div>
					 

                </div>
                    
                <?php endwhile; ?>
                  <?php } ?>	  
                <div class="clear"></div>

        
    </div>
    
<?php get_footer('preview'); ?>
