<?php
/*
Template Name: Ajax Posts Template
*/

get_header();

// Set the initial query parameters
$args = array(
    'posts_per_page' => 4, // Number of posts to display initially
    'post_type' => 'post', // Change 'post' to your desired post type
    'post_status' => 'publish'
);

$query = new WP_Query($args);
?>

<div id="post-container">
    <?php
    // Start the main loop
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            // Display the post content as desired
            echo '<div>' . get_the_title() . '</div>';
        }
    }
    ?>
</div>

<button id="load-more-button">Load More</button>

<script>
jQuery(function($) {
    var page = 1;
    var loading = false;
    var $loadMoreButton = $('#load-more-button');
    var $postContainer = $('#post-container');

    $loadMoreButton.on('click', function() {
        if (!loading) {
            loading = true;
            $loadMoreButton.text('Loading...');

            var data = {
                action: 'load_more_posts',
                query: '<?php echo json_encode($args); ?>', // Pass the query parameters to the AJAX handler
                page: page
            };

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // URL to the AJAX handler
                data: data,
                type: 'POST',
                success: function(response) {
                    if (response) {
                        $postContainer.append(response);
                        page++;
                        loading = false;
                        $loadMoreButton.text('Load More');
                    } else {
                        $loadMoreButton.text('No more posts');
                    }
                }
            });
        }
    });
});
</script>

<?php get_footer(); ?>
