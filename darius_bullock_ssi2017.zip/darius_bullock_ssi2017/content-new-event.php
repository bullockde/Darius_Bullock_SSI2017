
	
	
<div class=' text-center hidden1'>

	
	<div class="clear"></div><br>
				
				<button id='newparty' class=' text-center hidden1'>New Event</button>
				
				<div class="clear"></div><br>

	<div id='newparty' style='display: none;'>
			
			<hr>
	<div class='col-sm-10 col-sm-offset-1 text-center hidden1 well'>	


		<?php if( is_user_logged_in() ){  ?>
		
		
		
		
		<div class="well yellow stats text-center">
				<?php 
					//echo $event->post_title; 
				?>
				<h2>North PHILLY Playroom</h2>
				<?php date_default_timezone_set("America/New_York"); 

					echo date("M jS, Y", strtotime(get_field('event_date', $event->ID)));
					?>
				
				<br><a href="/?p=<?php echo $event->ID; ?>" class="h4">[ <?php echo get_field('event_time', $event->ID); ?> ]</a>
				
				
				
				<br>
				
					<div class='clear'></div>
				<?php $rsvps = get_field( 'event_rsvps', $event->ID ); 
						$max_guests = get_field( 'event_max_guests', $event->ID );
						$seats = $max_guests - $rsvps;
					
					?>
					<small>( <u><?php echo $seats; ?></u> Slots Left ) </small><br>
					
						
						
						<div class='clearfix'></div>
						
						
		</div>
		<form method='post'>
				<h3><input type='text' name='post_title' placeholder='Event Title'  value='North PHILLY Playroom' required><hr></h3>
				
				<div class='col-sm-6 '>	
				<?php 
					if( has_post_thumbnail($lead->ID) ){
						
						echo get_the_post_thumbnail($lead->ID);
					}else{
						
						twentysixteen_the_custom_logo(); 
					}
				 ?>
			
					
				<div class="event-info h4">
					<div class='clear'></div><br>
						<div class="col-xs-6">
							<b>Members Only?</b>
						</div>
						<div class="col-xs-6">
							<?php 
							
								$att = get_user_meta($userid, 'event_members_only', 1);
								$options = array( 'No', 'Yes' );

							?>
							<select name="event_members_only" >
							<?php 
								foreach($options as $option){
									
									?>
									<option value="<?php echo $option;?>" <?php if ($att == $option) echo "selected='selected'";?>><?php echo $option;?></option>
									<?php
								}
							?>
							</select>

						</div>
						
						<div class='clear'></div><br>
						<div class="col-xs-6">
							<b>Max Guests?</b>
						</div>
						<div class="col-xs-6">
							
							<input type='number' name='event_max_guests' maxlength='3' max='99' value='6' required>

						</div>
						<div class="clear"></div><br>
						
						
					</div>
				</div>
				<div class='col-sm-6 '>			
					<div class='clear'></div>
					<div class='col-xs-12 '>
						<h3><u>Date</u></h3><h4 class='orange'> <?php date_default_timezone_set("America/New_York"); 

						?> <input id='today' type='date' name='event_date' placeholder='Event Date' required></h4>
														
														
					</div>
					<div class='clear '></div>
					<h3><u>Time</u></h3>
					<div class='col-xs-6 '>
						<b><u>Start</u></b><h4 class='orange'>  <input type='time' name='event_start' placeholder='Event Time' required></h4>
					</div>
					<div class='col-xs-6 '>
						<b><u>End</u></b><h4 class='orange'>  <input type='time' name='event_end' value='<?php echo date('H',strtotime('now') ); ?>' step="900" required></h4>
					</div>
					<div class='clear '></div>
						
						<h3><u>Location</u> <br> <input type='text' name='event_location' placeholder='Event Location' value="North Philly" required><hr>
						
					
				<h4>Event Price<br><input type='text' name='event_price' placeholder='Event Price' value="10" required></h4>

				</div>
						<div class='clear'></div>
			
			<input type='hidden' name='new_event' value='true'>
			<input type='submit' value='Submit' class='btn btn-lg btn-success btn-block' style='padding: 1em; '>
								
								
				<img src='<?php echo get_field( 'event_flyer', $lead->ID ); ?>' class=' img-responsive'>	
			</form>		
		<?php } else {
			
				echo "- Please Login Below to Add New Events! -";
				
				 echo do_shortcode("[wpmem_form login]");
		}  ?>
		</div>	
	</div>
</div>
<script>
	let today = new Date().toISOString().substr(0, 10);
	document.querySelector("#today").value = today;

	//document.querySelector("#today2").valueAsDate = new Date();
</script>