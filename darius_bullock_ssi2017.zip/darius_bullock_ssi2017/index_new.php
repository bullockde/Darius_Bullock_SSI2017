<?php 
/*
Template Name: New Home Layout

*/



get_header(); ?>
  
<div id='video-choice'></div>
  
    <div class="main home-beta">
	
		<div class='site-container'>

<div class='alert hide'><img width='30' src='http://instaflixxx.com/wp-content/uploads/2014/01/index.jpg'><b></b> Pardon the Dust - New and Improved Layout In Progress </div>
	
  
        
<?php //get_sidebar('left'); ?>

			<div class='home-beta column left'>

				<?php include('new-left-sidebar.php'); ?>

			</div>
			<div class='home-beta column middle'>
			
					<div class='mission'>
						
						<div class='banner-img porn'><a href='http://instaflixxx.com/tumblr-sex-walls/#post-4940'><img src='http://instaflixxx.com/wp-content/uploads/2013/09/link.png'></a></div>
						</div>
					<div class='clear'></div>
					<div class="posts">
					<!--<a href='http://instaflixxx.com/member-sign-up/'><div class=' porn red-alert signup'><b>>Sign Up<</b></div></a>-->
					<a ><div class="family-filter porn" >Family Filter</div> </a>
					<a onclick="document.querySelector('.mission-statement').classList.toggle('hide');"><div class="sexyButtonleft porn" >View Our Mission</div> </a>
						<div class='mission-statement hide'>InstaFliXXX strives to be the largest social network where members communicate with different ages, races, shapes and sizes. As the well rounded individuals we are, we should be able to come to one place and do everything from laugh, to meet and chat, to some more naughtier things #IstaFliXXXafterDark ;). With that being said we are all One Big Family. Anyone who thinks otherwise does not belong here. -#InstaFliXXX</div>
					
					
		
		 <div class='porn recent-flixxx'>
					<h2> Recent FliXXX </h2>
					<?php 
						query_posts( array ( 'category_name' => 'gay', 'posts_per_page' => 4 ) );
						if(have_posts()) { ?>
							
							<?php while (have_posts()) : the_post(); ?>   
							
							<div class="post index drop-shadow curved curved-vt-2" id="post-<?php the_ID();  ?>" >
							
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">

						<?php if(get_post_custom_values('hover_photo',$post->ID)){ ?>


						<div class="hover-img" style="background-image: url( <?php $keys = get_post_custom_values('hover_photo',$post->ID);  echo $keys[0]; ?> ); 
								background-size: 300px auto;
								height: 185px;
								margin: 0 0 2px;
								width: 250px;">
								
						<?php }else if (get_field('hover_image', $post->ID )){ ?>

						<div class="hover-img" style="background-image: url( <?php  echo get_field('hover_image', $post->ID ); ?> ); 
								background-size: 255px 188px;
								height: 185px;
								margin: 0 0 2px;
								width: 250px;">

						<?php }else{ ?>
						<div class="hover-img" style="
								//background-position: -25px -25px;
								background-size: 255px 188px;
								height: 185px;
								margin: 0 0 2px;
								width: 250px;">
								
						<?php } ?>

								 <?php the_post_thumbnail(array(240,180), array('alt' => get_the_title(), 'title' => '')); ?>

						</div>


				</a>

								
				<?php if ( get_post_meta($post->ID, 'duration', true) ) : ?><div class="duration"><?php echo get_post_meta($post->ID, 'duration', true) ?></div><?php endif; ?>

				<div class="link"><a href="<?php the_permalink() ?>"><?php short_title('..', '25'); ?></a></div>

								
							   
								
							  <!--  <span><?php the_tags('Tags: ', ', ', ''); ?></span>-->
							
							</div>
				   



		<?php $count = $count+1; 

		if ( $count % 6 == 0 ) {  ?>
		<div style='height: 65px; clear: both;'>
		<!--JuicyAds v2.0-->
					<iframe border="0" frameborder="0" marginheight="0" marginwidth="0" width="476" height="68" scrolling="no" allowtransparency="true" src="http://adserver.juicyads.com/adshow.php?adzone=188534"></iframe>
				<!--JuicyAds END-->
		</div>
		<?php }?>


				 
							<?php endwhile; ?>

			
							
							
							
							
		<!--<a target='_blank' href="http://www.exoclick.com/?login=pussynomo"><img src="http://www.exoclick.com/banners/728x90.gif" border="0"></a>-->
							<div class="clear"></div>

							
							
			</div><!-- PORN RECENT FLIXXX -->					
							
							
							
			<h2> Recent Music </h2>			
					
			<?php	wp_reset_query(); ?>
			
			
			<?php
					query_posts( array ( 'category_name' => 'music-videos' , 'posts_per_page' => 4  ) );

					// The Loop
					while ( have_posts() ) : the_post();?>
					
					<div class="post index drop-shadow curved curved-vt-2" id="post-<?php the_ID();  ?>" >
							
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">

						<?php if(get_post_custom_values('hover_photo',$post->ID)){ ?>


						<div class="hover-img" style="background-image: url( <?php $keys = get_post_custom_values('hover_photo',$post->ID);  echo $keys[0]; ?> ); 
								background-size: 300px auto;
								height: 185px;
								margin: 0 0 2px;
								width: 250px;">
								
						<?php }else if (get_field('hover_image', $post->ID )){ ?>

						<div class="hover-img" style="background-image: url( <?php  echo get_field('hover_image', $post->ID ); ?> ); 
								background-size: 255px 188px;
								height: 185px;
								margin: 0 0 2px;
								width: 250px;">

						<?php }else{ ?>
						<div class="hover-img" style="
								//background-position: -25px -25px;
								background-size: 255px 188px;
								height: 185px;
								margin: 0 0 2px;
								width: 250px;">
								
						<?php } ?>

								 <?php the_post_thumbnail(array(240,180), array('alt' => get_the_title(), 'title' => '')); ?>

						</div>


				</a>

								
				<?php if ( get_post_meta($post->ID, 'duration', true) ) : ?><div class="duration"><?php echo get_post_meta($post->ID, 'duration', true) ?></div><?php endif; ?>

				<div class="link"><a href="<?php the_permalink() ?>"><?php short_title('..', '25'); ?></a></div>

								
							   
								
							  <!--  <span><?php the_tags('Tags: ', ', ', ''); ?></span>-->
							
							</div>
				   



		<?php $count = $count+1; 

		if ( $count % 8 == 0 ) {  ?>
		<div style='height: 65px; clear: both;'>
		<!--JuicyAds v2.0-->
					<iframe border="0" frameborder="0" marginheight="0" marginwidth="0" width="476" height="68" scrolling="no" allowtransparency="true" src="http://adserver.juicyads.com/adshow.php?adzone=188534"></iframe>
				<!--JuicyAds END-->
		</div>
		<?php }?>

<?php
					endwhile;
										
			?>			
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
						<!--	<div class="paginator">
							
								<?php if (function_exists("pagination")) {
			
										pagination($additional_loop->max_num_pages);
									
									} ?>

							</div>-->
							
							<div class="clear"></div>
							
						<?php }
				
						else { ?>
				
							<h2>Sorry, no posts matched your criteria</h2>
				
						<?php } ?>
				
					</div> <!-- Posts index-->
					
					<h2 class='porn'>Recent Tumblr Fun-Walls</h2>
					
					<div class='timblrs-home porn'>
							<h1 class="walls"><a href="http://spanishhotboy.tumblr.com/" target="_blank"><img src="http://api.tumblr.com/v2/blog/spanishhotboy.tumblr.com/avatar/24">Spanish Boy's Wall</a> / <a href="http://instaflixxx.com/user-profile/?ID=869" target="_blank">View Profile <img src="http://api.tumblr.com/v2/blog/spanishhotboy.tumblr.com/avatar/24"></a></h1>
							<h1 class="walls"><a href="http://bi-is-a-lifestyle.tumblr.com/" target="_blank"><img src="http://api.tumblr.com/v2/blog/bi-is-a-lifestyle.tumblr.com/avatar/24">Mr. TooDamnGood's Wall</a> / <a href="http://instaflixxx.com/user-profile/?ID=791" target="_blank">View Profile <img src="http://api.tumblr.com/v2/blog/bi-is-a-lifestyle.tumblr.com/avatar/24"></a></h1>
							<h1 class="walls"><a href="http://spinx-06.tumblr.com/" target="_blank"><img src="http://api.tumblr.com/v2/blog/spinx-06.tumblr.com/avatar/24">Haitiano906's Wall</a> / <a href="http://instaflixxx.com/user-profile/?ID=1175" target="_blank">View Profile <img src="http://api.tumblr.com/v2/blog/spinx-06.tumblr.com/avatar/24"></a></h1>
							<h1 class="walls"><a href="http://sexxxiest69.tumblr.com/" target="_blank"><img src="http://api.tumblr.com/v2/blog/sexxxiest69.tumblr.com/avatar/24">Sexxxiest69's Wall</a> / <a href="http://instaflixxx.com/user-profile/?ID=633" target="_blank">View Profile <img src="http://api.tumblr.com/v2/blog/sexxxiest69.tumblr.com/avatar/24"></a></h1>
							<h1 class="walls"><a href="http://ohmyjorjor.tumblr.com/" target="_blank"><img src="http://api.tumblr.com/v2/blog/ohmyjorjor.tumblr.com/avatar/24">Ohmyjorjor's Wall</a> / <a href="http://instaflixxx.com/user-profile/?ID=1078" target="_blank">View Profile <img src="http://api.tumblr.com/v2/blog/ohmyjorjor.tumblr.com/avatar/24"></a></h1>
					
				

					</div>
					<a ><div class="family-filter friendly hide" >Family Filter</div> </a>
				</div><!-- Posts -->
				<div class='home-beta column right'>
					<?php the_widget('visitor_maps_widget'); ?>
					 
					 <?php get_sidebar('right'); ?>
					<div class='adsbar porn'>
					 <?php dynamic_sidebar("Third Sidebar"); ?>
					 </div>
				<!--	<a href="#" onClick="jkpopimage('http://instaflixxx.com/wp-content/uploads/2014/01/Beyonce-Partition1.jpg', 325, 445, 'Served!'); return false">Breakfast pancakes</a>
				-->
				</div>
		
		</div>
		
        
        <?php //get_sidebar('right'); ?>
        
        <div class="clear"></div>
        
    </div>
	
</div><!-- Site Container -->

<?php get_footer(); ?>