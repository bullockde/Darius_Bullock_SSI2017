<?php

 
 if( !isset($_COOKIE["site_entered"]) ){ setcookie( 'site_entered' , 'Yes' , time() + (86400 * 30), "/"); }

get_header(); ?> 




<?php get_template_part( 'content', 'welcome' ); ?>



<section id='welcome1' class='welcome' style='display:block;'>

<div class="spotlight col-md-4  col-md-offset-2 pad0 text-center hidden ">

		
				<div class="col-xs-12 ">
				
				
			<h4>
				<?php 
				
				if( is_user_logged_in() ){  
				
					echo 'Hello, ' . $current_user->user_login . '!'; 
					
				}else if( $_COOKIE['name'] != ''){ 
				
					echo "<b>Welcome, " . $_COOKIE['name'] . "!</b>"; 
				
				}else{ echo "<b>Welcome, Guest!</b>";}

				?>
			</h4>
				
				
				</div>
				
				<div class='clearfix'></div>  <hr style='margin: .5em 0 0;'> 
				
				<div class=' col-xs-12'>
					<div class=' col-xs-5'>		


						
			<?php 
				
				echo "<center>" . get_field( 'member_level', $lead->ID ) . "</center>";
				
				
				
					if (  get_avatar_url()  ) {
						$avatar_URL  = get_avatar_url();
						
    
						?>
						<a target='_blank' href='/?p=<?php echo $current_user->ID; ?>'>
							<?php echo get_avatar($current_user->ID, 150); ?>
						</a>
						<?php 
					}else{
						?>
						<a target='_blank' href='/?p=<?php echo $current_user->ID; ?>'>	<img src='http://ssixxx.com/wp-content/uploads/2016/08/man-blank-profile.png' class='img-responsive aligncenter' width='150'>
						</a>
						<?php 
						
					}
		
				?>
					</div>
					<div class=' col-xs-7 text-left '>
												
						<?php 
							
						echo "<br><b>I am a: </b>" ;	
	
				if( get_user_meta($current_user->ID, 'MX_user_gender', "user_" . $user->ID) ){  
				
					echo get_user_meta($current_user->ID, 'MX_user_gender', "user_" . $user->ID);
					
				}else if( $_COOKIE['gender'] != ''){ 
				
					echo $_COOKIE['gender']; 
				
				}else{ echo " Guest ";}

							
							echo "<br><b>Seeking: </b>" ;
							
				if( get_user_meta($current_user->ID, 'MX_user_seeking', "user_" . $user->ID) ){  
				
					echo get_user_meta($current_user->ID, 'MX_user_seeking', "user_" . $user->ID);
					
				}else if( $_COOKIE['seeking'] != ''){ 
				
					echo $_COOKIE['seeking']; 
				
				}else{ echo " Fun ";}
				
							
							echo "<br><b>I Prefer: </b>" ;
				
				if( get_user_meta($current_user->ID, 'MX_user_prefers', "user_" . $user->ID) ){  
				
					echo get_user_meta($current_user->ID, 'MX_user_prefers', "user_" . $user->ID);
					
				}else if( $_COOKIE['person'] != ''){ 
				
					echo $_COOKIE['person']; 
				
				}else{ echo " Vids ";}				
							
						
							echo "<br>" ;
							
						?>
						<a href='/edit-profile/?ID=<?php echo $current_user->ID; ?>' class='btn btn-default btn-sm btn-block'>Edit Profile</a>
						
					
					</div>
				
					<div class='clearfix'></div>
					<a href='/user-profile/?ID=<?php echo $current_user->ID; ?>' class='btn btn-info btn-block'>View Profile</a> 
				</div>
					<div class='clearfix'></div>  <hr style='margin: .6em 0;'> 
			<div class='col-xs-12 text-left'> 		
					<b>Current Status:</b><br>
				<?php	if(bp_activity_latest_update($current_user->ID)){ bp_activity_latest_update($current_user->ID); }else{ echo " - no status updates - "; }  ?>

					<a href='/members/<?php $current_user = wp_get_current_user(); echo  $current_user->user_login;  ?>/#subnav' class='status btn btn-default btn-sm pull-right hidden1'>Update</a>
					
			</div>
			<div class='clearfix'></div> 
				
					<div class='clearfix'></div>
				

			
			

			 <div class='clearfix'></div>
				<div class='col-xs-12'>
				
					<button id='whatsnew' class='random btn btn-lg btn-danger btn-block hidden'>Random Button</button>
					<div class='clearfix'></div>
				</div>
				
				
				<button id='profilemenu' class='btn btn-info btn-block hidden'>Profile Menu</button>
				
				

				<div id='profilemenu' class="profilemenu " style="display: none;">

					
						<a href='/members/<?php $current_user = wp_get_current_user(); echo  $current_user->user_login;  ?>/profile/edit/' class='btn btn-lg btn-info btn-block hidden'>Edit My Profile</a>


				</div>
				

				<button id='whatsnew' class='explode btn btn-danger btn-lg btn-block hidden'>Random Button</button>
				

		</div>
	
	<div class="col-sm-5 hidden">
		<div class="text-center">
		
				<br><br>
		
			<?php //get_template_part( 'ad' , '300-250-1' ); ?>
				
			
			<div class="clear"></div>
				
		</div>
		
	 </div>
	 
	 
	 
	 
	 
<section>	 
<div class="clear"></div>
<?php

			
		//echo "<hr>";
			if( get_field( "display_title", $post->ID ) == "No" ){   }else{ 
			
				//echo "<h4><center>- New Updates -</center></h4>";
				//the_title( '<h1 class="entry-title text-center">', '</h1>' ); 

			}
			
		//echo "<hr>";
			
	//get_template_part( 'content', 'projects-grid' );
	
	 ?>

<div id="" class="">


<div class="clear"></div>
		<section id='subscribe' class='tagline hidden1 '>
			
				<div class="container text-center">	
				
				<div class=' col-md-4 text-center'>
						
						<div class='clear '></div>
						<div class='hidden-xs'></div>
				
				  
		<center> <br>

				<!-- JuicyAds v3.0 -->
				<script async src="//adserver.juicyads.com/js/jads.js"></script>
				<ins id="498543" data-width="300" data-height="262"></ins>
				<script>(adsbyjuicy = window.adsbyjuicy || []).push({'adzone':498543});</script>
				<!--JuicyAds END-->
		</center>


				
				</div>
				
				<div class=' col-md-8'>
				<div class='visible-xs'></div>
					<h2 style='color: #EC2828; text-decoration: underline;'>Explore our Sexy Companions!!</h2>

						<h3>Massage & Manscaping Services</h3>

						<h3>Dinner & Movie Dates</h3>
						
						<h3>Live-In Home Keepers</h3>
						
						<h3>Upscale Companions</h3>

	<br>
				<div class="btn-group ">
					<a href="/companions" class="btn btn-lg btn-default">View Ads</a>
					<a target='_blank' href="/apply" class="btn btn-lg btn-danger">Post Ad</a>
					
				</div>
				
				</div>	
				
			<div class="clear"></div><br>

				</div><!-- // container -->
			
</section><!-- // tagline -->

<div class="clear"></div><hr>

<div class="text-center">
			<h2>Online Members</h2>
			<?php if ( bp_has_members( 'type=online&max=12' ) ) : ?>         
								<?php while ( bp_members() ) : bp_the_member(); ?>                      
									<a href="/user-profile/?ID=<?php echo bp_get_member_user_id(); ?>"><?php bp_member_avatar('type=full&width=125&height=125') ?>

				
									</a>
									
								<?php endwhile; ?>
			<?php endif; ?>

			<div class="clear"></div><br>

				<a href='/members'>View All >></a>

		
		</div>

<div class="clear"></div><hr>


</div>

<?php //get_sidebar(); ?>
<?php get_footer(); ?>