<div class='clearfix'></div>

<section id='about' class='about <?php if( !is_front_page() ){ ?> page-pad <?php } ?>'>
		
		<div class='container'>
		<br><br>
			<div class="col-md-6">
				
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/06/11391216_577961622346797_4435540621815338615_n-480x372.jpg'>
			</div>
			<div class='clear visible-xs'></div>
			<div class="col-md-6">
				
				<a href='/mission/'><div class='btn col-xs-12'>My Mission</div></a>
				<a href='/journey/'><div class='btn col-xs-12'>My Journey</div></a>
				
				<a href='/ventures'><div class='btn col-xs-12'>My Ventures</div></a>				
									
				
			</div>
			
			
		</div>
	
	</section>

<div class='clearfix'></div>