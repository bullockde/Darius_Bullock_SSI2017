<?php get_header(); ?>
<?php 
$user = wp_get_current_user();

	if($_GET['update_post']){ 
	
	$ID = $post;
	$ID = get_post( $_GET['ID'] );
	
	
	//print_r($user);
	$postID = $_GET['ID'];
	add_post_meta($postID, 'MX_modified_user', $user->display_name) ;
	update_post_meta($postID, 'MX_modified_user', $user->display_name) ;
	
	wp_update_post($ID); 
}
if($_GET['make_draft']){
	
	$ID = $post->ID;
	$ID = $_GET['ID'];
	
	 $my_post = array(
      'ID'           => $ID,
      'post_title'   => get_the_title($ID),
     'post_content' => get_the_content($ID),
	  'post_status' => 'draft'
  );
  
	add_post_meta($_GET['ID'], 'MX_modified_user', $user->display_name) ;
	update_post_meta($_GET['ID'], 'MX_modified_user', $user->display_name) ;

// Update the post into the database
  wp_update_post( $my_post );
	
}
?>

		
	
	<div class="row new-header">
		<div class='container'>
		
		


			<div class='col-left'>
					
				<!--<a href='/'>   
					<div><img class='porn ' src='http://instaflixxx.com/wp-content/uploads/2014/01/InstaFliXXX-Logo-transparent.png'></div>     

				</a> -->
			</div>
			<div class='col-mid'>
			
					
		
				<!--<form method="post" action="<?php bloginfo('url'); ?>/">
					
					<input type="text" class="search-form" name="s"  value="Search" onblur="javascript: if(this.value == '') { this.value = 'Search';}" onfocus="javascript: if(this.value == 'Search') this.value = '';"/>
					<input type="submit" class="search-button" value="Search" />
				
				</form>-->
			
			</div>    	
			<div class='col-right'>	
				<?php //echo dispMailbox(); ?>
				
				<!--	<div class='filters-new porn '>

					<a href='http://instaflixxx.com/category/straight-porn/'><div class='filter'>
					Str8</div></a>
					<a  href='http://instaflixxx.com/category/gay/'><div class='filter'>
					Gay</div></a>
					<a  href='http://instaflixxx.com/category/bisexual/'><div class='filter'>
					Bi</div></a>
					<a  href='http://instaflixxx.com/category/transexual-porn/'><div class='filter'>
					Trans</div></a>
					</div>
				
						<div class='tagline porn'>Connecting <b>People</b> and <b>Porn</b> to Keep You <em>Cumming</em> Back!</div>
				-->		

			</div>   

		</div>
    
    </div>
	

	<div class="clear"></div><br><br>

    <div class="main admin">
    
        <div class="site-container">
			<div class='home-beta column left'>
			
				<?php include('admin-sidebar.php'); ?>
				
			</div>
			
			
			
            <div class="main-content h5">
			
					<div class='well '>
						<div class="clear"></div><br>
						
						<h3>Instructions:</h3>
							-- some videos get removed from the Original sites they are embedded from.. so this checker makes sure the video is still there and working.. 
						<hr>
				
								1. Check to ensure Video Works
							<br><br>2. It Works? ..  Click "Update Post"
							<br><br>3. Doesnt Work? .. Click "Delete";
							
						<div class="clear"></div><br>
					</div>
				<div class="clear"></div>
				<?php 	$user = wp_get_current_user();
		$allowed_roles = array('editor', 'administrator');
	if ( is_user_logged_in() && array_intersect($allowed_roles, $user->roles ) ) { ?>
	
	
	<div class="admin ">	
				<?php 
						
						
						wp_reset_query();
	
					$gay_vids = get_posts( array (  'posts_per_page' => 5 , 'orderby' => 'modified' , 'order' => 'asc') );

					// The Loop
				foreach( $gay_vids as $post ): setup_postdata($post); 
		
						if( 1 ) $mobile = 1; 		
					?>
					<div class="clear"></div>
					<div class="posts col-md-offset-2 col-md-8">
					<?php //get_template_part( 'content', 'post' ); ?>

					<div class="clear"></div><br>
					<center> <?php echo get_the_content($post->ID); ?> </center>
				<div class='clear'></div>	
				<?php get_template_part( 'content', 'under-video' ); ?>
				
		<div class="admin well">
				<br>
				
				
				<div class="col-xs-3">
				Posted: 
				</div>
				<div class="col-xs-3">
				<?php the_time('m-d-y');  ?> 
				</div>
				<div class="col-xs-3">
				By
				</div>
				<div class="col-xs-3">
				 - <?php the_author();  ?>
				</div>
				<div class='clear'></div>	<br>
				<div class="col-xs-3">
				Updated: 
				</div>
				<div class="col-xs-3">
				<?php echo get_the_modified_date( $d , $post ); ?>
				</div>
				
				<div class="col-xs-3">
				By
				</div>
				<div class="col-xs-3">
				 - <?php echo get_post_meta( $post->ID, 'MX_modified_user', 1); ?>
				</div>
				
				
				
				<center>
		
				<div class="clear"></div><br>
				<a target='' href='?update_post=1&ID=<?php echo $post->ID; ?>' class='btn btn-info btn-lg'>Update Post</a>
				<a target=''  href='?make_draft=1&ID=<?php echo $post->ID; ?>' class='btn btn-info btn-lg'>Delete</a>
				</center>
		
		
				
				<div class='clear'></div>	<br>
		</div>
					
					</div><br>
	<div class='clear'></div><br>
			<?php  endforeach; //end FOR EACH ?>
			
			<div class="clear"></div>
			<br><hr>
			<?php
						
						$posts = get_posts( array(
							
							'post_per_page' => -1,
							//'orderby' => 'modified',
							//'order' => 'asc'
						) );
						
						$cnt = 0;
						
						echo "<h3>Total Left</h3>";
						print_r( count($posts) );
						echo "<br><br>";
						
						
						foreach( $posts as $post ){
							/*
							if( in_category('mobile') || in_category('not-mobile') ){
									// Do Nothing
							}else if( in_category('new') ){
									echo "<a target='_blank' href='" . $post->guid . "'>" . $post->post_title . "</a><--UNCATEGORIZED<br>"; 
									$cnt++;
							}else{
									
							}*/
							echo "<a target='_blank' href='" . $post->guid . "'>" . $post->post_title . "</a><br>"; 
									$cnt++;
						}
						
						echo "COUNT->" . $cnt;
						
						echo "<h3>Posts Today</h3>";
						$today = date("Y-m-d H:i:s"); //Today's date
						$daysago = date("Y-m-d H:i:s",strtotime(date('Y-m-j H:i:s')) - (1 * 24 * 60 * 60)); //Today - 1 day

						$numposts = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post' AND post_date BETWEEN '$daysago' AND '$today'");

						if ($numposts > 0) {
						echo $numposts;
						} else {
						echo "0";
						}
						
						
						$args = array(
							
							'post_type' => 'post',
							
						);
						
						
						//$all_posts = new WP_Query();
						//$all_posts->query($args);
						
						//print_r($all_posts);
				wp_reset_query();
				?>

</div>		
	<?php }else{
		
		//get_template_part('content', 'member-area');
	} ?>

            </div>
	
	
        </div>
		

		

        <?php //get_sidebar('right'); ?>
        
        <div class="clear"></div>
        
    </div>
    
<?php get_footer(); ?>
