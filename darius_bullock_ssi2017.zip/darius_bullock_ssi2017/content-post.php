<div class="post  index drop-shadow curved curved-vt-2" id="post-{{$post->ID}}" >
	
	<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
		<div class='well 1blue img-thumbnail col-xs-12'>					
				

						
			<div class="hover-img">
				<center>
					<a target="_blank" href="/?p=<?php the_ID();  ?>" >
						<div class='col-xs-12 text-center'>
							<?php
								if(get_field('youtube_id', $post->ID)){
									?>
										<center>
											<img src="http://img.youtube.com/vi/<?php echo get_field('youtube_id', $post->ID); ?>/0.jpg" alt="Youtube Image"  class="1circle img-thumbnail img-responsive" width="100%">
										</center>
									<?php
								}else if( has_post_thumbnail() ) { //the post does not have featured image, use a default image
									$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );
									?>
									<img src='<?php echo esc_attr( $thumbnail_src[0] ) ; ?>' alt='Youtube Image'  class='1circle img-responsive' width='100%'>
									<?php
									echo '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
								}else{
									// echo "NO Pic!";
									?>

									<img src="http://instaflixxx.com/wp-content/uploads/2013/12/play.jpg" class="img-fluid" width="100%" >
									<?php
								}
							?>
						</div>
					</a>
				</center>	
			</div>
						
				

			

				<div class="link hidden1">
				
				<div class='col-xs-8'><?php
				$title = get_the_title($post->ID);
				
				//echo "..";
				//substr($title ,  17); 
				echo $title;
				?></div>
				
				<div class='col-xs-4'>
		
					<?php if ( get_post_meta($post->ID, 'video_length', true) ) : ?><div class="duration"><?php echo get_post_meta($post->ID, 'video_length', true) ?></div><?php endif; ?>

				</div>
				
				</div>
		<div class="clear"></div>
		</div>
	
	</a>
	<div class="clear"></div>
</div>		
		<div class="clear"></div>
		
		
		
		
		
		


<!-- Add the following code to your WordPress index template -->

<!-- CSS Styles -->
<style>
    /* Button Styles */
    .preview-button {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
    }

    /* Popup Styles */
    .preview-popup {
        display: none;
        position: fixed;
        z-index: 9999;
        padding: 20px;
        background-color: #f1f1f1;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
</style>

<!-- Button and Popup Markup -->
<a class="preview-button">Preview</a>
<div id="preview-popup" class="preview-popup">
    <h2>Preview Content</h2>
    <p>This is the content you want to show in the preview popup.</p>
    <!-- Add your desired preview content here -->
    <button onclick="closePreview()">Close</button>
</div>

<!-- JavaScript Code -->
<script>
    // Function to open the preview popup
    function openPreview() {
        document.getElementById("preview-popup").style.display = "block";
    }

    // Function to close the preview popup
    function closePreview() {
        document.getElementById("preview-popup").style.display = "none";
    }

    // Add event listener to the preview button
    document.getElementsByClassName("preview-button")[0].addEventListener("click", openPreview);
</script>