<div class='clear'></div>

<section id='massage' class='massage'>
		
		<div class='container'>
		<h2>Treat YourSelf Massage & Wellnes</h2><hr>
			<div class="col-md-6">
				
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/09/2015-05-04-13.37.16.jpg'>

				
			</div>
			<div class="col-md-6">
				
				<strong> Specializing in: </strong>
				<ul>
					<li> Deep Tissue </li>
					<li> Sports Massage </li>
					<li> Myofascial Techniques</li>
					<li> Pregnancy Massage </li>
					<li> Relaxation Services </li>
					<li> Swedish Massage & More </li>
					<br>
					<a target='_blank' href='http://treatyourselfmassage.com' class='btn btn-default'>Visit Treat Yourself Massage</a>
					
				</ul>
			</div>
		</div>
	
	</section>

<div class='clear'></div>