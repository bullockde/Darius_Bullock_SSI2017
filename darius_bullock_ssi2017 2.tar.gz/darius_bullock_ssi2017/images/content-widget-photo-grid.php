<section id='blog' class=' hidden1 visible-xs1 visible-md1'>
	<div class='container'>
			
			
			
			<div class="well text-center">
					<h2>Recent Photos</h2><hr>
					<?php
$args = array( 'posts_per_page' => 6, 'post_type' => 'ssi_photos' , 'orderby' => 'rand' );

		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
			
			
				<a href="<?php the_permalink(); ?>">
					<div class='col-xs-6 col-md-2 blog-post'>
						<?php 

							if ( has_post_thumbnail() ) {
								the_post_thumbnail('thumbnail', array( 'style' => ' ' ,'class' => ' img-responsive img-thumbnail','alt' => get_the_title(), 'title' => ''));
							}else{
								?>
									<img src="http://www.gravatar.com/avatar/23aaf70341a81b1cba173f16b3e28098?s=75&r=x&d=http%3A%2F%2Fdlfreakfest.org%2Fwp-content%2Fuploads%2F2019%2F11%2F5dde1c7720197-bpfull.jpg" alt="User Image" class="img-thumbnail img-responsive">
								<?php
							}
						  	
						
						?>
						<br>
						<?php
						the_title(); ?>
						
						<div class='visible-xs visible-sm'><hr></div>
					</div>
				</a>
			
		<?php endforeach; 
		wp_reset_postdata();?>
		<div class='clearfix'></div><hr>
			<div class='blog-post'>
				<a href='/photos/' class='btn btn-lg btn-primary btn-block'>Photos &raquo;</a>
			</div>
			
		</div>
	</div><!-- // container -->		
</section><!-- // Blog SPace -->