<div class='clear'></div>
	
	<section class='deals'>
		
		<div class='container'>
		

	
		<div class='row'>
			<div class='col-xs-6'>
				<h2>#SSIDeals</h2>
			</div>	
			<div class='col-xs-6'>
				<button id='deals' class='btn btn-lg btn-default btn-section'>View / Hide</button>
			</div><div class='clear'></div>
			<hr>
		</div>
			
			
	<div id='deals' style=' display: block;'>
			<div class="col-md-4 groupon pad0 text-center">Groupon Shopping Deals
<div class="aligncenter" style="height: 250px; width: 300px;"><iframe src='//www.groupon.com/content-assembly/render/223c7ea0-8d0d-11e6-ad01-43d3e8a24c9f' width='300' height ='250' frameBorder='0' scrolling='no'></iframe></div>
</div>
			<div class="col-md-4 groupon pad0 text-center">
				Advertisement
				<div class="aligncenter" style="height: 250px; width: 300px;">
				<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- shaman_shawn_responsive_300_250 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-3813829909026031"
     data-ad-slot="3794576183"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
			</div>
			</div>
			<div class="col-md-4 groupon pad0 text-center">Groupon Food Deals
<div class="aligncenter" style="height: 250px; width: 300px;"><iframe src="//ad.groupon.com/runs/112/201476/?i_width=300&amp;i_height=250&amp;variation=1HC&amp;category=restaurants&amp;cachedOnly=true" width="300" height="250" frameborder="0" scrolling="no"></iframe></div>
</div>

			</div><!-- #deals -->
		</div><!-- #container -->
	
	</section>
		
	<div class='clear'></div>