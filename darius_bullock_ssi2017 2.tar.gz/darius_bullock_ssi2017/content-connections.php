<div class='clearfix'></div>
<section class='connections'>
		
		<div class='container'>
		

		<div class='row'>
			<div class='col-xs-6'>
				<h3>#SSIConnect</h3>
			</div>	
			<div class='col-xs-6'>
				<button id='connections' class='btn btn-default btn-section'>View / Hide</button>
			</div><div class='clearfix'></div>
			<hr>
		</div> 
			
			
	<div id='connections' style=' display: none;'>		
			<div class="col-md-6">
				
				
			<p>We believe in being very good at what we do. If you want to build a thriving business or get a simple project completed you’ve come to the right place. When it’s not our specialty, we partner with those that are very good at what they do. Luckily, we found the best.<br><br>

Our partners and alliances are top-notch industry experts. They are independently owned and run  but often act as an extended arm and work as part of our team. Together, we provide our clients with the valuable expertise needed to accomplish goals and deliver excellence.</p>
			</div>
			<div class="col-md-6">
				

				
				<img class='img-responsive aligncenter' src='http://shamanshawn.com/wp-content/uploads/2015/09/SSIConnections.png'>

				<h5 style="text-align: center;">"Make a Request, Any Request!"</h5>
<div class="job-search well">
<strong>#SSI Request Desk:</strong><div class="clear"></div>
<div class="col-sm-6"><a class="btn btn-default" href="/connect/#post">Post Request</a></div>
<div class="col-sm-6"><br class="visible-xs" /><a class="btn btn-default" href="/connect/#latest">View Requests</a></div>
<div class="clear"></div>
</div>

		
				
			</div>
		</div><!-- #connections -->
	</div><!-- #container -->
	</section>
<div class='clearfix'></div>