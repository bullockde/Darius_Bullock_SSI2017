<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 

get_header('profile'); ?>
 <style>

	hr{
		margin: 10px 0;
	}
	.well {
		min-height: 20px;
		padding: 15px;
		margin-bottom: 20px;
		background-color: #fff;
		border: 1px solid #eee;
		border-radius: 4px;
		-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
		box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
	}
	.splash{
	    background-color: #fff;
	}
	

 </style>

<section class='splash'>

	<div class=" text-center">
	<img class='hidden' src='http://dlfreakfest.org/wp-content/uploads/2018/08/DLFreakFest-Splash-2018-free.png
	'>
	<img class='hidden' src='http://dlfreakfest.org/wp-content/uploads/2020/01/dlfreakfest-2020.png'>
	    <img class='hidden' src='http://dlfreakfest.org/wp-content/uploads/2020/07/image-1024x394-1-e1595567916610.png' width='100%'>
	<a href="/join">
	    
	    <img class='hidden1' src='https://dlfreakfest.org/wp-content/uploads/2021/04/dlff-chat-meet-freak.png'>
	    
	</a>
	
	
		<?php // echo do_shortcode('[wpmem_form login]'); ?>
		<?php //echo do_shortcode('[wpmem_form register]'); ?>
		
		<?php 
			
			if(is_user_logged_in()){
				?>
				
				<?php
				
				
			}else{
				?>
				<div class='well  hidden yellow1 mb-0 container-fluid'>
					<a href='/' class='btn btn-sm btn-default'>Home</a> | 
					<a href='/members' class='btn btn-sm btn-default'>Members</a> | 
					<a href='/events' class='btn btn-sm btn-default'>Events</a> |
					<a href='/freak-now' class='btn btn-sm btn-default pulse' style='min-width: 120px;'>Freak Now &raquo;</a>
				</div>
				<!--
				
				 |
				<a href='/blog'>FliXXX</a> | 		
				<a href='/freak-now'>Freak Now!</a>
				-->
				<?php
				
			}
		
			
		
		
		?>
	
		
		<?php 
			
			if(is_user_logged_in()){
				
				get_template_part( 'content' , 'members' ); 
				
			}else{
				
				//get_template_part( 'content' , 'welcome-profile' ); 
			}
		
			
		
		
		?>
	</div>
	<div class='clearfix'></div>
</section>

<div class='clearfix mb-0'></div>




<?php get_footer('members'); ?>
