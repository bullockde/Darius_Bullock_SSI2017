<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header('profile'); ?> 
<style>
	hr {
		margin: 15px 0 0;
	}
	#pm-content textarea {
		width: 100%;
		height: 200px;
		font-size: 16px;
	}
	#pm-wrapper {
		margin: 0 0 1em;
		position: relative;
		/* background-color: white; */
	}
	#pm-header {
		border: 1px solid #333;
		height: auto;
		width: 100%;
		color: white;
		display: none;
	}
	#pm-menu {
		color: #333;
		width: 100%;
		font-size: 14px;
		font-weight: bold;
		margin: 0;
		clear: both !Important;
	}
</style>


<div id="" class="container-fluid ">
	<br>

		<?php

		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 
				<header class="entry-header">
					
					<?php 

					$thumb_id = get_post_thumbnail_id();
					$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail-size', true);
					$thumb_url = $thumb_url_array[0];

						
					
					
					 if( is_page( array('resume', 'contact', 'gallery', 'subscribe') ) ){

					 }else if ( (get_post_type( $post ) == 'ssi_gallery') && (is_user_logged_in()) ){


					} else if ( $thumb_url == 'http://shamanshawn.com/wp-content/uploads/Home2016-featured.png' ){


					}else if( get_field( "display_image", $post->ID ) == "No" ){   
					
							//Nothing
					}else{ 

						twentysixteen_post_thumbnail(); 

					}
				
				 ?>
					
				</header><!-- .entry-header -->

	
<div class='clearfix'> </div>
	<div class="col-md-8 well yellow">
		<?php

		if( !is_user_logged_in() ){ 
		?>
	
		
		
					
			<div class="well yellow">		
		<?php
			echo "<h3>Login to View Mailbox!</h3>";
			//get_template_part( 'content', 'member-area' );
			
			
			 echo do_shortcode("[wpmem_form login]"); 

		?>
		</div>
			<a href='/wp-login.php?action=lostpassword' class='btn btn-lg btn-default'> I forgot my Password &rarr; </a>
			
		<?php
		
		}

		?>
		
        
        		<div class='clear'></div>
			<!-- #START Playlist-->
            
            <?php  
            
                the_content();
            
            
            // if( !isset($_GET['pmaction']) || ($_GET['pmaction'] == ("viewmessage" || "checkmessage")) ){ 
            
             ?>
            
            
           
            <div class='clear mb-10'></div>
            
			<div class='playlist well green'>
				`<h3 class="text-center">Recent Posts</h3>	<br>

				<?php
	//	wp_reset_postdata();

		$args = array(  'post_type' => 'ssi_requests' , 'posts_per_page' => 4, 'orderby' => 'rand');

		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); 
		
		//print_r($post);
		//if(get_field('youtube_id', $post->ID)){
		
	?>
	
		<div class='col-xs-12 '>
			
			
			
			
			<div class='clear'></div>
			
			<h4> <a href='/requests/<?php echo $post->post_name; ?>'> <?php echo $post->post_title; ?> </a> <small>  ( <?php echo get_post_meta($post->ID, 'MX_user_city', true); ?>, <?php echo get_post_meta($post->ID, 'MX_user_state', true); ?> ) -- <?php echo get_the_date( 'F d - h:i A' , $post->ID ); ?> </small></h4>
			
			
			
			<br>
			
			<a href='/requests/<?php echo $post->post_name; ?>'>
			
			
		<?php 
			if ( has_post_thumbnail( $post->ID ) ) {
    			$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'thumbnail' );	

				}
				
		?>
				
				 <img src='<?php echo esc_url( $large_image_url[0] ); ?>' class='img-responsive  hidden aligncenter'></a>
		</div>
				
		
		
	<?php 
		
		//}
		endforeach; 
//		wp_reset_postdata();

		
	?>
	<div class='clear'></div>
	</div>



	

			
			
<!-- #END Playlist-->

<div class='clear'></div>

<a class="btn btn-primary btn-block btn-lg" href="/members"><br>« Return Home<br><br></a>
	<?php //}
	?>
		
		
		<?php
		
		

		wp_link_pages( array(
			'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
			'after'       => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
			'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
			'separator'   => '<span class="screen-reader-text">, </span>',
		) );
		?>
	</div><!-- .entry-content -->
	<div class="col-md-4 text-center">
	
		
		
		<div class="1img-thumbnail">
		    <center>
			    <?php get_template_part( 'content' , 'sidebar-ads' ); ?>
			</center>
		</div>
		
	</div><!-- .entry-content -->
	
	
	<div class='clearfix'></div>
	<?php
		edit_post_link(
			sprintf(
				/* translators: %s: Name of current post */
				__( 'Edit<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
				get_the_title()
			),
			'<footer class="entry-footer"><span class="edit-link">',
			'</span></footer><!-- .entry-footer -->'
		);
	?>

</article><!-- #post-## -->
			
			<?php



			// End of the loop.
		endwhile;
		?>
		
		



</div><!-- .content-area -->

<div class='clearfix'></div>
<?php get_footer('preview'); ?>